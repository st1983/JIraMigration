# Properties File Usage Guide

## 📋 Overview

The `config.properties` file contains all configuration including:
- **URLs** - Application URLs
- **Login Credentials** - Username and passwords
- **Test Data** - Form data, messages, expected values
- **Environment Configuration** - QA, Dev, Prod URLs
- **File Paths** - Upload/download/screenshot paths

## 📁 File Location

```
src/test/resources/config/config.properties
```

## 🔧 Usage Examples

### 1. Using URL Configuration

```java
import com.nammnet.utils.ConfigReader;

// Get main URL
String url = ConfigReader.getUrl();

// Get specific URLs
String loginUrl = ConfigReader.getLoginUrl();
String homeUrl = ConfigReader.getHomeUrl();
String dashboardUrl = ConfigReader.getDashboardUrl();
```

### 2. Using Login Credentials

```java
// Get login credentials
String username = ConfigReader.getLoginUsername();
String password = ConfigReader.getLoginPassword();

// Use in login
loginPage.login(username, password);

// Invalid credentials for negative testing
String invalidUser = ConfigReader.getInvalidUsername();
String invalidPass = ConfigReader.getInvalidPassword();
```

### 3. Using Test Data - User Credentials

```java
// Test User 1
String user1 = ConfigReader.getTestUser1Username();
String pass1 = ConfigReader.getTestUser1Password();
String email1 = ConfigReader.getTestUser1Email();

// Test User 2
String user2 = ConfigReader.getTestUser2Username();
String pass2 = ConfigReader.getTestUser2Password();

// Admin User
String admin = ConfigReader.getTestAdminUsername();
String adminPass = ConfigReader.getTestAdminPassword();
```

### 4. Using Test Data - Form Data

```java
// Fill form with test data
formPage.enterFirstName(ConfigReader.getFormFirstName());
formPage.enterLastName(ConfigReader.getFormLastName());
formPage.enterEmail(ConfigReader.getFormEmail());
formPage.enterPhone(ConfigReader.getFormPhone());
formPage.enterAddress(ConfigReader.getFormAddress());
formPage.enterCity(ConfigReader.getFormCity());
formPage.enterState(ConfigReader.getFormState());
formPage.enterZipcode(ConfigReader.getFormZipcode());
formPage.selectCountry(ConfigReader.getFormCountry());
```

### 5. Using Expected Messages

```java
// Verify success message
String expectedMessage = ConfigReader.getLoginSuccessMessage();
Assert.assertEquals(expectedMessage, actualMessage);

// Verify error message
String expectedError = ConfigReader.getLoginFailureMessage();
Assert.assertTrue(errorMessage.contains(expectedError));
```

### 6. Using Expected Values

```java
// Verify page title
String expectedTitle = ConfigReader.getExpectedPageTitle();
Assert.assertEquals(expectedTitle, driver.getTitle());

// Verify welcome message
String expectedWelcome = ConfigReader.getExpectedWelcomeMessage();
Assert.assertTrue(welcomeText.contains(expectedWelcome));
```

### 7. Using Environment Configuration

```java
// Get current environment
String env = ConfigReader.getEnvironment(); // Returns "qa", "dev", or "prod"

// Get environment-specific URL
String envUrl = ConfigReader.getEnvironmentUrl();
driver.get(envUrl);
```

### 8. Using Search/Filter Data

```java
// Search functionality
searchPage.enterSearchTerm(ConfigReader.getSearchTerm());
searchPage.selectCategory(ConfigReader.getSearchCategory());

// Filter functionality
filterPage.selectStatus(ConfigReader.getFilterStatus());
filterPage.selectPriority(ConfigReader.getFilterPriority());
```

### 9. Using File Paths

```java
// Upload file
String uploadPath = ConfigReader.getFileUploadPath() + "testfile.pdf";
uploadPage.uploadFile(uploadPath);

// Download file location
String downloadPath = ConfigReader.getFileDownloadPath();

// Screenshot path
String screenshotPath = ConfigReader.getScreenshotPath();
```

### 10. Using Wait Timeouts

```java
// Get wait timeouts
int implicitWait = ConfigReader.getImplicitWait();
int explicitWait = ConfigReader.getExplicitWait();
int pageLoadTimeout = ConfigReader.getPageLoadTimeout();
```

## 📝 Complete Example in Step Definitions

```java
package com.nammnet.stepdefinitions;

import com.nammnet.pages.LoginPage;
import com.nammnet.utils.ConfigReader;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.junit.Assert;

public class LoginStepDefinitions {
    private LoginPage loginPage;

    public LoginStepDefinitions() {
        this.loginPage = new LoginPage();
    }

    @Given("I am on the login page")
    public void i_am_on_the_login_page() {
        // URL from config
        DriverManager.getDriver().get(ConfigReader.getLoginUrl());
    }

    @When("I login with valid credentials")
    public void i_login_with_valid_credentials() {
        // Credentials from config
        String username = ConfigReader.getLoginUsername();
        String password = ConfigReader.getLoginPassword();
        loginPage.login(username, password);
    }

    @When("I login with invalid credentials")
    public void i_login_with_invalid_credentials() {
        // Invalid credentials from config
        String username = ConfigReader.getInvalidUsername();
        String password = ConfigReader.getInvalidPassword();
        loginPage.login(username, password);
    }

    @Then("I should see login success message")
    public void i_should_see_login_success_message() {
        // Expected message from config
        String expectedMessage = ConfigReader.getLoginSuccessMessage();
        String actualMessage = loginPage.getSuccessMessage();
        Assert.assertEquals(expectedMessage, actualMessage);
    }

    @Then("I should see login failure message")
    public void i_should_see_login_failure_message() {
        // Expected error message from config
        String expectedError = ConfigReader.getLoginFailureMessage();
        String actualError = loginPage.getErrorMessage();
        Assert.assertTrue(actualError.contains(expectedError));
    }
}
```

## 🔐 Security Best Practices

1. **Never commit real credentials** to version control
2. **Use config.properties.example** as a template
3. **Add config.properties to .gitignore**
4. **Use environment variables** for sensitive data in CI/CD
5. **Rotate credentials** regularly

## 📋 Properties File Structure

```
config.properties
├── Application Configuration
│   ├── url
│   ├── browser
│   └── wait timeouts
├── Login Credentials
│   ├── login.username
│   ├── login.password
│   └── invalid credentials
├── Test Data
│   ├── User credentials (user1, user2, admin)
│   ├── Form data (name, email, address, etc.)
│   ├── Messages (success, error, validation)
│   ├── Expected values (title, welcome message)
│   └── Search/Filter data
├── Environment Configuration
│   ├── environment
│   └── environment URLs (qa, dev, prod)
└── File Paths
    ├── Upload path
    ├── Download path
    └── Screenshot path
```

## 🎯 Quick Reference

### Get URL
```java
ConfigReader.getUrl()
ConfigReader.getLoginUrl()
ConfigReader.getHomeUrl()
```

### Get Credentials
```java
ConfigReader.getLoginUsername()
ConfigReader.getLoginPassword()
```

### Get Test Data
```java
ConfigReader.getFormFirstName()
ConfigReader.getFormEmail()
ConfigReader.getTestUser1Username()
```

### Get Messages
```java
ConfigReader.getLoginSuccessMessage()
ConfigReader.getLoginFailureMessage()
```

### Get Expected Values
```java
ConfigReader.getExpectedPageTitle()
ConfigReader.getExpectedWelcomeMessage()
```

## ✅ Benefits

1. **Centralized Configuration** - All data in one place
2. **Easy Maintenance** - Update values without code changes
3. **Environment Support** - Switch between QA/Dev/Prod easily
4. **Security** - Keep credentials separate from code
5. **Reusability** - Use same data across multiple tests

