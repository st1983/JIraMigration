# Windows Import Guide - Bulk Test Case Import

This guide explains how to import bulk test cases from Jira and Azure DevOps on Windows and automatically create feature files.

## Quick Start

### Method 1: Interactive Menu (Recommended)

1. **Double-click** `run-bulk-import.bat`
2. Follow the interactive menu prompts
3. Enter your credentials when prompted
4. Feature files will be created automatically

### Method 2: Quick Script (Jira)

1. Edit `run-jira-bulk-import.bat`
2. Update the variables at the top:
   ```batch
   set JIRA_URL=https://yourcompany.atlassian.net
   set JIRA_USERNAME=your-email@company.com
   set JIRA_API_TOKEN=your-api-token
   set JQL_QUERY=project = TEST AND type = Test
   set OUTPUT_FILE=JiraBulkImport
   set SINGLE_FILE=false
   ```
3. **Double-click** `run-jira-bulk-import.bat`

### Method 3: Command Line

Open Command Prompt or PowerShell in the project directory:

```batch
# Interactive menu
run-bulk-import.bat

# Or compile and run manually
mvn clean compile
mvn exec:java -Dexec.mainClass="com.nammnet.integration.BulkImportRunner"
```

## Detailed Instructions

### Prerequisites

1. **Java 1.8+** installed
   - Check: `java -version`
   - Download: https://www.oracle.com/java/technologies/downloads/

2. **Maven 3.6+** installed
   - Check: `mvn -version`
   - Download: https://maven.apache.org/download.cgi
   - Add to PATH environment variable

3. **Jira API Token** (for Jira import)
   - Go to: https://id.atlassian.com/manage-profile/security/api-tokens
   - Click "Create API token"
   - Copy the token

4. **Azure DevOps PAT** (for ADO import)
   - Go to: Azure DevOps → User Settings → Personal Access Tokens
   - Create new token with "Work Items (Read)" permission
   - Copy the token

### Step-by-Step: Import from Jira

#### Option A: Using Interactive Menu

1. Run `run-bulk-import.bat`
2. Select option `2` (Import Bulk Test Cases from Jira)
3. Enter:
   - Jira URL: `https://yourcompany.atlassian.net`
   - Username: `your-email@company.com`
   - API Token: `your-api-token`
   - JQL Query: `project = TEST AND type = Test`
   - Base Filename: `JiraBulkImport`
   - Single File: `n` (for separate files) or `y` (for one file)

4. Wait for import to complete
5. Check `src\test\resources\features\imported\` for feature files

#### Option B: Using Quick Script

1. Open `run-jira-bulk-import.bat` in Notepad
2. Edit the variables:
   ```batch
   set JIRA_URL=https://yourcompany.atlassian.net
   set JIRA_USERNAME=your-email@company.com
   set JIRA_API_TOKEN=your-api-token-here
   set JQL_QUERY=project = TEST AND type = Test AND status = 'To Do'
   set OUTPUT_FILE=JiraBulkImport
   set SINGLE_FILE=false
   ```
3. Save and double-click the file
4. Feature files will be created automatically

#### Option C: Using Configuration File

1. Copy `src\test\resources\config\integration.properties.example` to `integration.properties`
2. Edit `integration.properties`:
   ```properties
   jira.url=https://yourcompany.atlassian.net
   jira.username=your-email@company.com
   jira.api.token=your-api-token
   ```
3. Run `run-bulk-import.bat`
4. Select option `7` (Quick Import using Configuration File)
5. Select option `2` (Jira - Bulk)
6. Enter JQL query and filename

### Step-by-Step: Import from Azure DevOps

1. Run `run-bulk-import.bat`
2. Select option `5` (Import Bulk Test Cases from Azure DevOps)
3. Enter:
   - Organization: `your-organization`
   - Project: `your-project`
   - Personal Access Token: `your-pat-token`
   - WIQL Query: `SELECT [System.Id] FROM WorkItems WHERE [System.WorkItemType] = 'Test Case'`
   - Base Filename: `ADOBulkImport`
   - Single File: `n` or `y`

4. Wait for import to complete
5. Check `src\test\resources\features\imported\` for feature files

## JQL Query Examples

### Import all test cases from a project
```
project = TEST AND type = Test
```

### Import test cases with specific status
```
project = TEST AND type = Test AND status = 'To Do'
```

### Import test cases with specific priority
```
project = TEST AND type = Test AND priority = High
```

### Import test cases with labels
```
project = TEST AND type = Test AND labels = automation
```

### Import test cases created in last 30 days
```
project = TEST AND type = Test AND created >= -30d
```

## WIQL Query Examples

### Import all test cases
```
SELECT [System.Id] FROM WorkItems WHERE [System.WorkItemType] = 'Test Case'
```

### Import test cases from specific area
```
SELECT [System.Id] FROM WorkItems 
WHERE [System.WorkItemType] = 'Test Case' 
AND [System.AreaPath] = 'Project\\Area'
```

### Import test cases with specific state
```
SELECT [System.Id] FROM WorkItems 
WHERE [System.WorkItemType] = 'Test Case' 
AND [System.State] = 'Active'
```

## Output Files

### Separate Files (singleFile = false)
- `JiraBulkImport_1_TEST-123.feature`
- `JiraBulkImport_2_TEST-124.feature`
- `JiraBulkImport_3_TEST-125.feature`
- etc.

### Single File (singleFile = true)
- `JiraBulkImport.feature` (contains all scenarios)

**Location**: `src\test\resources\features\imported\`

## Troubleshooting

### Error: Maven not found
**Solution**: Install Maven and add to PATH
1. Download from https://maven.apache.org/download.cgi
2. Extract to `C:\Program Files\Apache\maven`
3. Add to PATH: `C:\Program Files\Apache\maven\bin`

### Error: Java not found
**Solution**: Install Java and add to PATH
1. Download Java 1.8+ from Oracle
2. Install to default location
3. Add to PATH: `C:\Program Files\Java\jdk1.8.0_xxx\bin`

### Error: 401 Unauthorized
**Solution**: Check your credentials
- Verify Jira URL is correct
- Verify username/email is correct
- Verify API token is valid (not expired)
- For ADO: Check PAT has correct permissions

### Error: 404 Not Found
**Solution**: Check your query
- Verify project key exists
- Verify issue keys are correct
- For ADO: Verify organization and project names

### Error: Connection timeout
**Solution**: Check network/firewall
- Verify internet connection
- Check if firewall is blocking
- Try from different network

### No feature files created
**Solution**: Check output directory
- Verify `src\test\resources\features\imported\` exists
- Check if import completed successfully
- Look for error messages in console

## Advanced Usage

### Using Command Line Arguments

```batch
# Jira bulk import
mvn exec:java -Dexec.mainClass="com.nammnet.integration.QuickJiraBulkImport" -Dexec.args="https://company.atlassian.net user@company.com token \"project = TEST\" BulkImport false"

# ADO bulk import
mvn exec:java -Dexec.mainClass="com.nammnet.integration.QuickADOBulkImport" -Dexec.args="org project pat \"SELECT [System.Id] FROM WorkItems\" BulkImport false"
```

### Creating Custom Batch Scripts

Create your own `.bat` file:

```batch
@echo off
set JIRA_URL=https://yourcompany.atlassian.net
set JIRA_USERNAME=your-email@company.com
set JIRA_API_TOKEN=your-token
set JQL_QUERY=project = TEST AND type = Test
set OUTPUT_FILE=MyImport
set SINGLE_FILE=false

mvn clean compile -q
mvn exec:java -Dexec.mainClass="com.nammnet.integration.QuickJiraBulkImport" -Dexec.args="%JIRA_URL% %JIRA_USERNAME% %JIRA_API_TOKEN% %JQL_QUERY% %OUTPUT_FILE% %SINGLE_FILE%"
pause
```

## Tips

1. **Test with single file first**: Use `singleFile = true` to see all scenarios in one file
2. **Use specific JQL/WIQL**: Narrow down queries to import only what you need
3. **Review generated files**: Always review feature files before running tests
4. **Backup existing files**: Feature files in `imported\` folder may be overwritten
5. **Use tags**: Generated feature files include tags for easy filtering

## Next Steps

After importing:
1. Review generated feature files in `src\test\resources\features\imported\`
2. Move or copy files to `src\test\resources\features\` if needed
3. Update step definitions if required
4. Run tests: `mvn test`

## Support

For issues or questions:
- Check [IMPORT_GUIDE.md](IMPORT_GUIDE.md) for detailed documentation
- Check [FEATURES_SUMMARY.md](FEATURES_SUMMARY.md) for feature overview
- Review console output for error messages

