package com.nammnet.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Configuration reader for integration settings
 */
public class IntegrationConfigReader {
    private static Properties properties;

    static {
        try {
            String configPath = System.getProperty("user.dir") + 
                              "/src/test/resources/config/integration.properties";
            FileInputStream fileInputStream = new FileInputStream(configPath);
            properties = new Properties();
            properties.load(fileInputStream);
            fileInputStream.close();
        } catch (IOException e) {
            // Use environment variables or defaults if file not found
            properties = new Properties();
        }
    }

    // Jira Configuration
    public static String getJiraUrl() {
        return getProperty("jira.url", System.getenv("JIRA_URL"));
    }

    public static String getJiraUsername() {
        return getProperty("jira.username", System.getenv("JIRA_USERNAME"));
    }

    public static String getJiraApiToken() {
        return getProperty("jira.api.token", System.getenv("JIRA_API_TOKEN"));
    }

    // Azure DevOps Configuration
    public static String getADOOrganization() {
        return getProperty("ado.organization", System.getenv("ADO_ORGANIZATION"));
    }

    public static String getADOProject() {
        return getProperty("ado.project", System.getenv("ADO_PROJECT"));
    }

    public static String getADOPersonalAccessToken() {
        return getProperty("ado.personal.access.token", System.getenv("ADO_PAT"));
    }

    // Import Settings
    public static String getImportOutputDirectory() {
        return getProperty("import.output.directory", 
                          "src/test/resources/features/imported");
    }

    public static boolean isSingleFileImport() {
        return Boolean.parseBoolean(getProperty("import.single.file", "false"));
    }

    // Auto-Healing Settings
    public static double getHealingSimilarityThreshold() {
        return Double.parseDouble(getProperty("healing.similarity.threshold", "0.7"));
    }

    public static boolean isHealingEnabled() {
        return Boolean.parseBoolean(getProperty("healing.enabled", "true"));
    }

    private static String getProperty(String key, String defaultValue) {
        String value = properties.getProperty(key);
        return value != null ? value : defaultValue;
    }

    private static String getProperty(String key) {
        return properties.getProperty(key);
    }
}

