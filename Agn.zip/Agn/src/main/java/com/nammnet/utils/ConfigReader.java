package com.nammnet.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Configuration Reader - Reads all properties from config.properties
 * Supports URL, login credentials, test data, and more
 */
public class ConfigReader {
    private static Properties properties;

    static {
        try {
            String configPath = System.getProperty("user.dir") + 
                              "/src/test/resources/config/config.properties";
            FileInputStream fileInputStream = new FileInputStream(configPath);
            properties = new Properties();
            properties.load(fileInputStream);
            fileInputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load config.properties file");
        }
    }

    public static String getProperty(String key) {
        return properties.getProperty(key);
    }

    public static String getProperty(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }

    // ============================================
    // Application Configuration
    // ============================================
    public static String getUrl() {
        return getProperty("url");
    }

    public static String getBrowser() {
        return getProperty("browser");
    }

    public static int getImplicitWait() {
        return Integer.parseInt(getProperty("implicit.wait", "10"));
    }

    public static int getExplicitWait() {
        return Integer.parseInt(getProperty("explicit.wait", "15"));
    }

    public static int getPageLoadTimeout() {
        return Integer.parseInt(getProperty("page.load.timeout", "30"));
    }

    // ============================================
    // Login Credentials
    // ============================================
    public static String getLoginUsername() {
        return getProperty("login.username");
    }

    public static String getLoginPassword() {
        return getProperty("login.password");
    }

    public static String getInvalidUsername() {
        return getProperty("login.invalid.username");
    }

    public static String getInvalidPassword() {
        return getProperty("login.invalid.password");
    }

    // ============================================
    // Test Data - User Credentials
    // ============================================
    public static String getTestUser1Username() {
        return getProperty("test.user1.username");
    }

    public static String getTestUser1Password() {
        return getProperty("test.user1.password");
    }

    public static String getTestUser1Email() {
        return getProperty("test.user1.email");
    }

    public static String getTestUser2Username() {
        return getProperty("test.user2.username");
    }

    public static String getTestUser2Password() {
        return getProperty("test.user2.password");
    }

    public static String getTestUser2Email() {
        return getProperty("test.user2.email");
    }

    public static String getTestAdminUsername() {
        return getProperty("test.admin.username");
    }

    public static String getTestAdminPassword() {
        return getProperty("test.admin.password");
    }

    public static String getTestAdminEmail() {
        return getProperty("test.admin.email");
    }

    // ============================================
    // Test Data - URLs
    // ============================================
    public static String getLoginUrl() {
        return getProperty("url.login");
    }

    public static String getHomeUrl() {
        return getProperty("url.home");
    }

    public static String getDashboardUrl() {
        return getProperty("url.dashboard");
    }

    public static String getLogoutUrl() {
        return getProperty("url.logout");
    }

    // ============================================
    // Test Data - Form Data
    // ============================================
    public static String getFormFirstName() {
        return getProperty("form.firstname");
    }

    public static String getFormLastName() {
        return getProperty("form.lastname");
    }

    public static String getFormEmail() {
        return getProperty("form.email");
    }

    public static String getFormPhone() {
        return getProperty("form.phone");
    }

    public static String getFormAddress() {
        return getProperty("form.address");
    }

    public static String getFormCity() {
        return getProperty("form.city");
    }

    public static String getFormState() {
        return getProperty("form.state");
    }

    public static String getFormZipcode() {
        return getProperty("form.zipcode");
    }

    public static String getFormCountry() {
        return getProperty("form.country");
    }

    // ============================================
    // Test Data - Messages
    // ============================================
    public static String getLoginSuccessMessage() {
        return getProperty("message.login.success");
    }

    public static String getLoginFailureMessage() {
        return getProperty("message.login.failure");
    }

    public static String getLogoutSuccessMessage() {
        return getProperty("message.logout.success");
    }

    public static String getValidationRequiredMessage() {
        return getProperty("message.validation.required");
    }

    public static String getValidationInvalidEmailMessage() {
        return getProperty("message.validation.invalid.email");
    }

    public static String getValidationPasswordLengthMessage() {
        return getProperty("message.validation.password.length");
    }

    // ============================================
    // Test Data - Expected Values
    // ============================================
    public static String getExpectedPageTitle() {
        return getProperty("expected.page.title");
    }

    public static String getExpectedWelcomeMessage() {
        return getProperty("expected.welcome.message");
    }

    public static String getExpectedErrorMessage() {
        return getProperty("expected.error.message");
    }

    public static String getExpectedSuccessMessage() {
        return getProperty("expected.success.message");
    }

    // ============================================
    // Test Data - Search/Filter
    // ============================================
    public static String getSearchTerm() {
        return getProperty("search.term");
    }

    public static String getSearchCategory() {
        return getProperty("search.category");
    }

    public static String getFilterStatus() {
        return getProperty("filter.status");
    }

    public static String getFilterPriority() {
        return getProperty("filter.priority");
    }

    // ============================================
    // Environment Configuration
    // ============================================
    public static String getEnvironment() {
        return getProperty("environment", "qa");
    }

    public static String getEnvironmentUrl() {
        String env = getEnvironment();
        return getProperty("environment." + env + ".url", getUrl());
    }

    // ============================================
    // File Paths
    // ============================================
    public static String getFileUploadPath() {
        return getProperty("file.upload.path");
    }

    public static String getFileDownloadPath() {
        return getProperty("file.download.path");
    }

    public static String getScreenshotPath() {
        return getProperty("file.screenshot.path");
    }

    // ============================================
    // Report Configuration
    // ============================================
    public static String getReportPath() {
        return getProperty("report.path", "test-output/ExtentReport");
    }

    public static String getReportName() {
        return getProperty("report.name", "Selenium Cucumber Test Report");
    }

    public static boolean isScreenshotOnFailure() {
        return Boolean.parseBoolean(getProperty("screenshot.on.failure", "true"));
    }

    public static boolean isScreenshotOnPass() {
        return Boolean.parseBoolean(getProperty("screenshot.on.pass", "false"));
    }
}

