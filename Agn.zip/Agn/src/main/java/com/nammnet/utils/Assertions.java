package com.nammnet.utils;

import org.junit.Assert;

public class Assertions {

    public static void assertTrue(String message, boolean condition) {
        try {
            Assert.assertTrue(message, condition);
            ExtentReportManager.getTest().pass(message);
        } catch (AssertionError e) {
            ExtentReportManager.getTest().fail(message + " - " + e.getMessage());
            throw e;
        }
    }

    public static void assertFalse(String message, boolean condition) {
        try {
            Assert.assertFalse(message, condition);
            ExtentReportManager.getTest().pass(message);
        } catch (AssertionError e) {
            ExtentReportManager.getTest().fail(message + " - " + e.getMessage());
            throw e;
        }
    }

    public static void assertEquals(String message, Object expected, Object actual) {
        try {
            Assert.assertEquals(message, expected, actual);
            ExtentReportManager.getTest().pass(message + " - Expected: " + expected + ", Actual: " + actual);
        } catch (AssertionError e) {
            ExtentReportManager.getTest().fail(message + " - Expected: " + expected + ", Actual: " + actual);
            throw e;
        }
    }

    public static void assertNotEquals(String message, Object unexpected, Object actual) {
        try {
            Assert.assertNotEquals(message, unexpected, actual);
            ExtentReportManager.getTest().pass(message);
        } catch (AssertionError e) {
            ExtentReportManager.getTest().fail(message + " - " + e.getMessage());
            throw e;
        }
    }

    public static void assertNotNull(String message, Object object) {
        try {
            Assert.assertNotNull(message, object);
            ExtentReportManager.getTest().pass(message);
        } catch (AssertionError e) {
            ExtentReportManager.getTest().fail(message + " - " + e.getMessage());
            throw e;
        }
    }

    public static void assertNull(String message, Object object) {
        try {
            Assert.assertNull(message, object);
            ExtentReportManager.getTest().pass(message);
        } catch (AssertionError e) {
            ExtentReportManager.getTest().fail(message + " - " + e.getMessage());
            throw e;
        }
    }

    public static void assertContains(String message, String container, String contained) {
        try {
            Assert.assertTrue(message, container.contains(contained));
            ExtentReportManager.getTest().pass(message + " - Container contains: " + contained);
        } catch (AssertionError e) {
            ExtentReportManager.getTest().fail(message + " - Container does not contain: " + contained);
            throw e;
        }
    }
}

