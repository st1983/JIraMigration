package com.nammnet.pages;

import com.nammnet.healing.LocatorHealer;
import com.nammnet.utils.DriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Base Page class with auto-healing locator support
 * Production-ready with clean code practices
 */
public class BasePage {
    protected WebDriver driver;
    protected WebDriverWait wait;
    protected LocatorHealer locatorHealer;

    public BasePage() {
        this.driver = DriverManager.getDriver();
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        this.locatorHealer = new LocatorHealer(driver);
        PageFactory.initElements(driver, this);
    }

    /**
     * Click element with auto-healing
     */
    protected void click(WebElement element) {
        click(element, null, null);
    }

    /**
     * Click element with auto-healing and element metadata
     */
    protected void click(WebElement element, String elementText, Map<String, String> attributes) {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(element));
            element.click();
        } catch (Exception e) {
            // Try healing if original click fails
            if (elementText != null || attributes != null) {
                By locator = getLocatorFromElement(element);
                WebElement healedElement = locatorHealer.findElementWithHealing(
                    locator, elementText, attributes);
                wait.until(ExpectedConditions.elementToBeClickable(healedElement));
                healedElement.click();
            } else {
                throw e;
            }
        }
    }

    /**
     * Send keys with auto-healing
     */
    protected void sendKeys(WebElement element, String text) {
        sendKeys(element, text, null, null);
    }

    /**
     * Send keys with auto-healing and element metadata
     */
    protected void sendKeys(WebElement element, String text, String elementText, 
                           Map<String, String> attributes) {
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            element.clear();
            element.sendKeys(text);
        } catch (Exception e) {
            // Try healing if original sendKeys fails
            if (elementText != null || attributes != null) {
                By locator = getLocatorFromElement(element);
                WebElement healedElement = locatorHealer.findElementWithHealing(
                    locator, elementText, attributes);
                wait.until(ExpectedConditions.visibilityOf(healedElement));
                healedElement.clear();
                healedElement.sendKeys(text);
            } else {
                throw e;
            }
        }
    }

    /**
     * Get text with auto-healing
     */
    protected String getText(WebElement element) {
        return getText(element, null, null);
    }

    /**
     * Get text with auto-healing and element metadata
     */
    protected String getText(WebElement element, String elementText, 
                            Map<String, String> attributes) {
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            return element.getText();
        } catch (Exception e) {
            // Try healing if original getText fails
            if (elementText != null || attributes != null) {
                By locator = getLocatorFromElement(element);
                WebElement healedElement = locatorHealer.findElementWithHealing(
                    locator, elementText, attributes);
                wait.until(ExpectedConditions.visibilityOf(healedElement));
                return healedElement.getText();
            } else {
                throw e;
            }
        }
    }

    /**
     * Check if element is displayed with auto-healing
     */
    protected boolean isDisplayed(WebElement element) {
        return isDisplayed(element, null, null);
    }

    /**
     * Check if element is displayed with auto-healing and element metadata
     */
    protected boolean isDisplayed(WebElement element, String elementText, 
                                 Map<String, String> attributes) {
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
            return element.isDisplayed();
        } catch (Exception e) {
            // Try healing if original isDisplayed fails
            if (elementText != null || attributes != null) {
                try {
                    By locator = getLocatorFromElement(element);
                    WebElement healedElement = locatorHealer.findElementWithHealing(
                        locator, elementText, attributes);
                    return healedElement.isDisplayed();
                } catch (Exception ex) {
                    return false;
                }
            }
            return false;
        }
    }

    /**
     * Wait for element with auto-healing
     */
    protected void waitForElement(WebElement element) {
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    /**
     * Wait for element to be clickable with auto-healing
     */
    protected void waitForElementToBeClickable(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    /**
     * Scroll to element
     */
    protected void scrollToElement(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element);
    }

    /**
     * Click using JavaScript
     */
    protected void clickByJavaScript(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", element);
    }

    /**
     * Find elements
     */
    protected List<WebElement> findElements(By locator) {
        return driver.findElements(locator);
    }

    /**
     * Find element
     */
    protected WebElement findElement(By locator) {
        return driver.findElement(locator);
    }

    /**
     * Get current URL
     */
    protected String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    /**
     * Get page title
     */
    protected String getPageTitle() {
        return driver.getTitle();
    }

    /**
     * Get locator from element (helper method)
     */
    private By getLocatorFromElement(WebElement element) {
        // This is a simplified implementation
        // In production, maintain a locator map
        try {
            String id = element.getAttribute("id");
            if (id != null && !id.isEmpty()) {
                return By.id(id);
            }
            String name = element.getAttribute("name");
            if (name != null && !name.isEmpty()) {
                return By.name(name);
            }
            return By.tagName(element.getTagName());
        } catch (Exception e) {
            return By.xpath("//*");
        }
    }

    /**
     * Create attributes map for healing
     */
    protected Map<String, String> createAttributesMap(String id, String name, 
                                                      String className, String type) {
        Map<String, String> attributes = new HashMap<>();
        if (id != null) attributes.put("id", id);
        if (name != null) attributes.put("name", name);
        if (className != null) attributes.put("class", className);
        if (type != null) attributes.put("type", type);
        return attributes;
    }
}
