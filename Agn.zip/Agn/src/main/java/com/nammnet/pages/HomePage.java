package com.nammnet.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage {

    @FindBy(className = "dashboard")
    private WebElement dashboard;

    @FindBy(linkText = "Logout")
    private WebElement logoutLink;

    @FindBy(className = "user-profile")
    private WebElement userProfile;

    @FindBy(className = "navigation-menu")
    private WebElement navigationMenu;

    public boolean isDashboardDisplayed() {
        return isDisplayed(dashboard);
    }

    public void clickLogout() {
        click(logoutLink);
    }

    public boolean isUserProfileDisplayed() {
        return isDisplayed(userProfile);
    }

    public boolean isNavigationMenuDisplayed() {
        return isDisplayed(navigationMenu);
    }

    public String getPageTitle() {
        return super.getPageTitle();
    }
}

