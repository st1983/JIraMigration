package com.nammnet.healing;

import info.debatty.java.stringsimilarity.Levenshtein;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.*;

/**
 * Auto-healing locator utility using similarity matching
 * Pure Java implementation without DB or Docker
 */
public class LocatorHealer {
    private static final Logger logger = LoggerFactory.getLogger(LocatorHealer.class);
    private final WebDriver driver;
    private final Levenshtein levenshtein;
    private final double similarityThreshold = 0.7;

    public LocatorHealer(WebDriver driver) {
        this.driver = driver;
        this.levenshtein = new Levenshtein();
    }

    /**
     * Find element with auto-healing - tries multiple locator strategies
     */
    public WebElement findElementWithHealing(By originalLocator, String elementText, 
                                             Map<String, String> attributes) {
        try {
            // First, try original locator
            return driver.findElement(originalLocator);
        } catch (Exception e) {
            logger.warn("Original locator failed: {}, attempting to heal...", originalLocator);
            return healLocator(originalLocator, elementText, attributes);
        }
    }

    /**
     * Heal locator by trying alternative strategies
     */
    private WebElement healLocator(By originalLocator, String elementText, 
                                   Map<String, String> attributes) {
        List<LocatorStrategy> strategies = generateAlternativeStrategies(elementText, attributes);
        
        for (LocatorStrategy strategy : strategies) {
            try {
                WebElement element = driver.findElement(strategy.getLocator());
                if (isElementSimilar(element, elementText, attributes)) {
                    logger.info("Healed locator found using strategy: {}", strategy.getType());
                    return element;
                }
            } catch (Exception e) {
                // Try next strategy
                continue;
            }
        }
        
        throw new RuntimeException("Could not heal locator: " + originalLocator);
    }

    /**
     * Generate alternative locator strategies
     */
    private List<LocatorStrategy> generateAlternativeStrategies(String elementText, 
                                                               Map<String, String> attributes) {
        List<LocatorStrategy> strategies = new ArrayList<>();

        // Strategy 1: Partial text match
        if (elementText != null && !elementText.isEmpty()) {
            strategies.add(new LocatorStrategy(
                By.partialLinkText(elementText), "partialLinkText"));
            strategies.add(new LocatorStrategy(
                By.xpath("//*[contains(text(), '" + elementText + "')]"), "xpathTextContains"));
        }

        // Strategy 2: Attribute-based locators
        if (attributes != null) {
            for (Map.Entry<String, String> attr : attributes.entrySet()) {
                if (attr.getValue() != null && !attr.getValue().isEmpty()) {
                    // Exact match
                    strategies.add(new LocatorStrategy(
                        By.xpath("//*[@" + attr.getKey() + "='" + attr.getValue() + "']"), 
                        "xpathAttrExact_" + attr.getKey()));
                    
                    // Partial match
                    strategies.add(new LocatorStrategy(
                        By.xpath("//*[contains(@" + attr.getKey() + ", '" + attr.getValue() + "')]"), 
                        "xpathAttrContains_" + attr.getKey()));
                }
            }
        }

        // Strategy 3: Similarity-based search
        if (elementText != null && !elementText.isEmpty()) {
            List<WebElement> allElements = driver.findElements(By.xpath("//*"));
            for (WebElement element : allElements) {
                try {
                    String elementTextContent = element.getText();
                    if (!elementTextContent.isEmpty()) {
                        double similarity = calculateSimilarity(elementText, elementTextContent);
                        if (similarity >= similarityThreshold) {
                            strategies.add(new LocatorStrategy(
                                By.xpath(getElementXPath(element)), "similarityMatch"));
                        }
                    }
                } catch (Exception e) {
                    continue;
                }
            }
        }

        // Strategy 4: Common attribute patterns
        if (attributes != null) {
            String id = attributes.get("id");
            String name = attributes.get("name");
            String className = attributes.get("class");
            
            if (id != null && !id.isEmpty()) {
                strategies.add(new LocatorStrategy(By.id(id), "id"));
            }
            if (name != null && !name.isEmpty()) {
                strategies.add(new LocatorStrategy(By.name(name), "name"));
            }
            if (className != null && !className.isEmpty()) {
                strategies.add(new LocatorStrategy(By.className(className), "className"));
            }
        }

        return strategies;
    }

    /**
     * Check if element is similar to expected element
     */
    private boolean isElementSimilar(WebElement element, String expectedText, 
                                    Map<String, String> expectedAttributes) {
        try {
            // Check text similarity
            if (expectedText != null && !expectedText.isEmpty()) {
                String actualText = element.getText();
                if (!actualText.isEmpty()) {
                    double textSimilarity = calculateSimilarity(expectedText, actualText);
                    if (textSimilarity >= similarityThreshold) {
                        return true;
                    }
                }
            }

            // Check attribute similarity
            if (expectedAttributes != null) {
                for (Map.Entry<String, String> expectedAttr : expectedAttributes.entrySet()) {
                    String actualValue = element.getAttribute(expectedAttr.getKey());
                    if (actualValue != null && !actualValue.isEmpty()) {
                        double attrSimilarity = calculateSimilarity(
                            expectedAttr.getValue(), actualValue);
                        if (attrSimilarity >= similarityThreshold) {
                            return true;
                        }
                    }
                }
            }

            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Calculate similarity between two strings
     */
    private double calculateSimilarity(String str1, String str2) {
        if (str1 == null || str2 == null) {
            return 0.0;
        }
        
        String normalized1 = str1.toLowerCase().trim();
        String normalized2 = str2.toLowerCase().trim();
        
        if (normalized1.equals(normalized2)) {
            return 1.0;
        }
        
        int maxLength = Math.max(normalized1.length(), normalized2.length());
        if (maxLength == 0) {
            return 1.0;
        }
        
        double distance = levenshtein.distance(normalized1, normalized2);
        return 1.0 - (distance / maxLength);
    }

    /**
     * Get XPath for an element (simplified version)
     */
    private String getElementXPath(WebElement element) {
        // This is a simplified implementation
        // In production, use a more robust XPath generator
        try {
            String tagName = element.getTagName();
            String id = element.getAttribute("id");
            if (id != null && !id.isEmpty()) {
                return "//" + tagName + "[@id='" + id + "']";
            }
            String className = element.getAttribute("class");
            if (className != null && !className.isEmpty()) {
                return "//" + tagName + "[@class='" + className + "']";
            }
            return "//" + tagName;
        } catch (Exception e) {
            return "//*";
        }
    }

    /**
     * Find all similar elements
     */
    public List<WebElement> findSimilarElements(String searchText, double minSimilarity) {
        List<WebElement> similarElements = new ArrayList<>();
        try {
            List<WebElement> allElements = driver.findElements(By.xpath("//*"));
            for (WebElement element : allElements) {
                try {
                    String elementText = element.getText();
                    if (!elementText.isEmpty()) {
                        double similarity = calculateSimilarity(searchText, elementText);
                        if (similarity >= minSimilarity) {
                            similarElements.add(element);
                        }
                    }
                } catch (Exception e) {
                    continue;
                }
            }
        } catch (Exception e) {
            logger.error("Error finding similar elements", e);
        }
        return similarElements;
    }

    /**
     * Wait for element with healing
     */
    public WebElement waitForElementWithHealing(By originalLocator, String elementText, 
                                               Map<String, String> attributes, int timeoutSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        
        try {
            return wait.until(driver -> {
                try {
                    return findElementWithHealing(originalLocator, elementText, attributes);
                } catch (Exception e) {
                    return null;
                }
            });
        } catch (Exception e) {
            logger.error("Element not found even after healing", e);
            throw new RuntimeException("Element not found: " + originalLocator);
        }
    }

    /**
     * Inner class for locator strategy
     */
    private static class LocatorStrategy {
        private final By locator;
        private final String type;

        public LocatorStrategy(By locator, String type) {
            this.locator = locator;
            this.type = type;
        }

        public By getLocator() {
            return locator;
        }

        public String getType() {
            return type;
        }
    }
}

