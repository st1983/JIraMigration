package com.nammnet.examples;

import com.nammnet.integration.TestCaseImporter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Complete example: Import test case from Jira and convert to feature file
 * 
 * This example demonstrates:
 * 1. Importing a single test case from Jira
 * 2. Importing bulk test cases from Jira
 * 3. Converting to Cucumber feature files automatically
 */
public class JiraImportExample {
    private static final Logger logger = LoggerFactory.getLogger(JiraImportExample.class);

    public static void main(String[] args) {
        System.out.println("==========================================");
        System.out.println("  Jira Test Case Import Example");
        System.out.println("==========================================");
        System.out.println();

        // Example 1: Import Single Test Case
        importSingleTestCaseExample();

        // Example 2: Import Bulk Test Cases
        importBulkTestCasesExample();

        // Example 3: Import by Project
        importByProjectExample();
    }

    /**
     * Example 1: Import a single test case from Jira
     * 
     * Steps:
     * 1. Connect to Jira with credentials
     * 2. Fetch test case by issue key (e.g., TEST-123)
     * 3. Convert to Cucumber feature file
     * 4. Save to src/test/resources/features/imported/
     */
    private static void importSingleTestCaseExample() {
        System.out.println("--- Example 1: Import Single Test Case ---");
        System.out.println();

        // Replace these with your actual Jira credentials
        String jiraUrl = "https://yourcompany.atlassian.net";
        String username = "your-email@company.com";
        String apiToken = "your-jira-api-token";
        String issueKey = "TEST-123";  // Replace with actual issue key
        String outputFileName = "ExampleSingleTestCase";

        System.out.println("Configuration:");
        System.out.println("  Jira URL: " + jiraUrl);
        System.out.println("  Username: " + username);
        System.out.println("  Issue Key: " + issueKey);
        System.out.println("  Output File: " + outputFileName + ".feature");
        System.out.println();

        try {
            System.out.println("Importing test case...");
            TestCaseImporter.importSingleTestCaseFromJira(
                jiraUrl,
                username,
                apiToken,
                issueKey,
                outputFileName
            );

            System.out.println("✓ Successfully imported test case!");
            System.out.println("Feature file created at:");
            System.out.println("  src/test/resources/features/imported/" + outputFileName + ".feature");
            System.out.println();

        } catch (Exception e) {
            System.err.println("✗ Error importing test case: " + e.getMessage());
            logger.error("Import failed", e);
            System.out.println();
            System.out.println("Note: This is a demo. Replace credentials with actual values.");
            System.out.println();
        }
    }

    /**
     * Example 2: Import bulk test cases from Jira using JQL query
     * 
     * Steps:
     * 1. Connect to Jira
     * 2. Execute JQL query to find test cases
     * 3. Convert each to feature file (or combine into one)
     * 4. Save to imported folder
     */
    private static void importBulkTestCasesExample() {
        System.out.println("--- Example 2: Import Bulk Test Cases ---");
        System.out.println();

        // Replace these with your actual Jira credentials
        String jiraUrl = "https://yourcompany.atlassian.net";
        String username = "your-email@company.com";
        String apiToken = "your-jira-api-token";
        
        // JQL Query Examples:
        // - All test cases: "project = TEST AND type = Test"
        // - High priority: "project = TEST AND type = Test AND priority = High"
        // - With label: "project = TEST AND type = Test AND labels = automation"
        String jqlQuery = "project = TEST AND type = Test AND status = 'To Do'";
        String baseFileName = "ExampleBulkImport";
        boolean singleFile = false;  // false = separate files, true = one file

        System.out.println("Configuration:");
        System.out.println("  Jira URL: " + jiraUrl);
        System.out.println("  Username: " + username);
        System.out.println("  JQL Query: " + jqlQuery);
        System.out.println("  Base File Name: " + baseFileName);
        System.out.println("  Single File: " + singleFile);
        System.out.println();

        try {
            System.out.println("Importing bulk test cases...");
            TestCaseImporter.importBulkTestCasesFromJira(
                jiraUrl,
                username,
                apiToken,
                jqlQuery,
                baseFileName,
                singleFile
            );

            System.out.println("✓ Successfully imported bulk test cases!");
            System.out.println("Feature files created at:");
            System.out.println("  src/test/resources/features/imported/");
            System.out.println();

        } catch (Exception e) {
            System.err.println("✗ Error importing bulk test cases: " + e.getMessage());
            logger.error("Bulk import failed", e);
            System.out.println();
            System.out.println("Note: This is a demo. Replace credentials with actual values.");
            System.out.println();
        }
    }

    /**
     * Example 3: Import all test cases from a Jira project
     * 
     * Steps:
     * 1. Connect to Jira
     * 2. Fetch all test cases from specified project
     * 3. Convert to feature files
     * 4. Save to imported folder
     */
    private static void importByProjectExample() {
        System.out.println("--- Example 3: Import by Project ---");
        System.out.println();

        // Replace these with your actual Jira credentials
        String jiraUrl = "https://yourcompany.atlassian.net";
        String username = "your-email@company.com";
        String apiToken = "your-jira-api-token";
        String projectKey = "TEST";  // Replace with your project key
        String baseFileName = "ExampleProjectImport";
        boolean singleFile = true;  // Combine all into one file

        System.out.println("Configuration:");
        System.out.println("  Jira URL: " + jiraUrl);
        System.out.println("  Username: " + username);
        System.out.println("  Project Key: " + projectKey);
        System.out.println("  Base File Name: " + baseFileName);
        System.out.println("  Single File: " + singleFile);
        System.out.println();

        try {
            System.out.println("Importing test cases from project...");
            TestCaseImporter.importTestCasesFromJiraProject(
                jiraUrl,
                username,
                apiToken,
                projectKey,
                baseFileName,
                singleFile
            );

            System.out.println("✓ Successfully imported test cases from project!");
            System.out.println("Feature file created at:");
            System.out.println("  src/test/resources/features/imported/" + baseFileName + ".feature");
            System.out.println();

        } catch (Exception e) {
            System.err.println("✗ Error importing from project: " + e.getMessage());
            logger.error("Project import failed", e);
            System.out.println();
            System.out.println("Note: This is a demo. Replace credentials with actual values.");
            System.out.println();
        }
    }

    /**
     * Helper method to show what a generated feature file looks like
     */
    public static void showExampleFeatureFile() {
        System.out.println("==========================================");
        System.out.println("  Example Generated Feature File");
        System.out.println("==========================================");
        System.out.println();
        System.out.println("@JiraImport @High");
        System.out.println("Feature: Login with Valid Credentials");
        System.out.println("  Jira Key: TEST-123");
        System.out.println("  Test case for validating user login functionality");
        System.out.println();
        System.out.println("  Scenario: Login with Valid Credentials");
        System.out.println("    Given I am on the login page");
        System.out.println("    When I enter username \"admin\"");
        System.out.println("    And I enter password \"password123\"");
        System.out.println("    And I click on login button");
        System.out.println("    Then I should be logged in successfully");
        System.out.println("    And I should see welcome message");
        System.out.println();
    }
}

