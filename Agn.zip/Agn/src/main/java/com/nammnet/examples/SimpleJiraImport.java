package com.nammnet.examples;

import com.nammnet.integration.TestCaseImporter;

/**
 * Simple Jira Import Example - Ready to Use
 * 
 * INSTRUCTIONS:
 * 1. Replace the values below with your actual Jira credentials
 * 2. Replace TEST-123 with your actual test case key
 * 3. Run this class (main method)
 * 4. Check src/test/resources/features/imported/ for the feature file
 */
public class SimpleJiraImport {
    
    public static void main(String[] args) {
        System.out.println("==========================================");
        System.out.println("  Simple Jira Import Example");
        System.out.println("==========================================");
        System.out.println();
        
        // ==========================================
        // EDIT THESE VALUES WITH YOUR CREDENTIALS
        // ==========================================
        String jiraUrl = "https://yourcompany.atlassian.net";      // Your Jira URL
        String username = "your-email@company.com";                  // Your Jira email
        String apiToken = "your-jira-api-token-here";                // Your API token
        String issueKey = "TEST-123";                                // Test case key to import
        String outputFileName = "ImportedTestCase";                 // Output filename
        // ==========================================
        
        System.out.println("Configuration:");
        System.out.println("  Jira URL: " + jiraUrl);
        System.out.println("  Username: " + username);
        System.out.println("  Issue Key: " + issueKey);
        System.out.println("  Output File: " + outputFileName + ".feature");
        System.out.println();
        
        // Validate configuration
        if (jiraUrl.contains("yourcompany") || 
            username.contains("your-email") || 
            apiToken.contains("your-jira-api-token")) {
            System.out.println("⚠️  WARNING: Please edit this file and set your actual credentials!");
            System.out.println();
            System.out.println("Steps to get API token:");
            System.out.println("  1. Go to: https://id.atlassian.com/manage-profile/security/api-tokens");
            System.out.println("  2. Click 'Create API token'");
            System.out.println("  3. Copy the token and paste it above");
            System.out.println();
            return;
        }
        
        try {
            System.out.println("Importing test case from Jira...");
            System.out.println();
            
            // Import the test case
            TestCaseImporter.importSingleTestCaseFromJira(
                jiraUrl,
                username,
                apiToken,
                issueKey,
                outputFileName
            );
            
            System.out.println();
            System.out.println("✓ SUCCESS! Test case imported successfully!");
            System.out.println();
            System.out.println("Feature file created at:");
            System.out.println("  src/test/resources/features/imported/" + outputFileName + ".feature");
            System.out.println();
            System.out.println("You can now:");
            System.out.println("  1. Review the feature file");
            System.out.println("  2. Move it to src/test/resources/features/ if needed");
            System.out.println("  3. Run tests with: mvn test");
            System.out.println();
            
        } catch (Exception e) {
            System.err.println();
            System.err.println("✗ ERROR: Failed to import test case");
            System.err.println("Error: " + e.getMessage());
            System.err.println();
            System.err.println("Troubleshooting:");
            System.err.println("  1. Verify Jira URL is correct");
            System.err.println("  2. Verify username is correct");
            System.err.println("  3. Verify API token is valid (not expired)");
            System.err.println("  4. Verify issue key exists and you have access");
            System.err.println("  5. Check internet connection");
            System.err.println();
            e.printStackTrace();
        }
    }
}

