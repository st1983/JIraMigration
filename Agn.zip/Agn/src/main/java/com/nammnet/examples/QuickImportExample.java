package com.nammnet.examples;

import com.nammnet.integration.TestCaseImporter;
import com.nammnet.utils.IntegrationConfigReader;

/**
 * Quick import examples using configuration file
 * Copy integration.properties.example to integration.properties and fill in your credentials
 */
public class QuickImportExample {

    public static void main(String[] args) {
        // Example 1: Quick Jira import using config
        quickJiraImport();
        
        // Example 2: Quick ADO import using config
        quickADOImport();
    }

    /**
     * Quick Jira import using configuration file
     */
    private static void quickJiraImport() {
        String jiraUrl = IntegrationConfigReader.getJiraUrl();
        String username = IntegrationConfigReader.getJiraUsername();
        String apiToken = IntegrationConfigReader.getJiraApiToken();
        
        if (jiraUrl != null && username != null && apiToken != null) {
            // Import single test case
            TestCaseImporter.importSingleTestCaseFromJira(
                jiraUrl, username, apiToken, "TEST-123", "QuickJiraImport");
            
            // Or import by project
            TestCaseImporter.importTestCasesFromJiraProject(
                jiraUrl, username, apiToken, "TEST", 
                "JiraProjectImport", 
                IntegrationConfigReader.isSingleFileImport());
        } else {
            System.out.println("Please configure Jira credentials in integration.properties");
        }
    }

    /**
     * Quick ADO import using configuration file
     */
    private static void quickADOImport() {
        String organization = IntegrationConfigReader.getADOOrganization();
        String project = IntegrationConfigReader.getADOProject();
        String pat = IntegrationConfigReader.getADOPersonalAccessToken();
        
        if (organization != null && project != null && pat != null) {
            // Import single test case
            TestCaseImporter.importSingleTestCaseFromADO(
                organization, project, pat, 12345, "QuickADOImport");
            
            // Or import by test plan
            TestCaseImporter.importTestCasesFromADOTestPlan(
                organization, project, pat, 123, 
                "ADOTestPlanImport",
                IntegrationConfigReader.isSingleFileImport());
        } else {
            System.out.println("Please configure Azure DevOps credentials in integration.properties");
        }
    }
}

