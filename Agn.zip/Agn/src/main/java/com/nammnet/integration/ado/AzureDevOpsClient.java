package com.nammnet.integration.ado;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * Azure DevOps Client for fetching test cases
 * Supports both single and bulk test case import
 */
public class AzureDevOpsClient {
    private static final Logger logger = LoggerFactory.getLogger(AzureDevOpsClient.class);
    private final String organization;
    private final String project;
    private final String personalAccessToken;
    private final CloseableHttpClient httpClient;

    public AzureDevOpsClient(String organization, String project, String personalAccessToken) {
        this.organization = organization;
        this.project = project;
        this.personalAccessToken = personalAccessToken;
        this.httpClient = HttpClients.createDefault();
    }

    /**
     * Fetch a single test case by work item ID
     */
    public AzureDevOpsTestCase fetchTestCase(int workItemId) {
        try {
            String url = String.format(
                "https://dev.azure.com/%s/%s/_apis/wit/workitems/%d?$expand=all&api-version=7.1",
                organization, project, workItemId
            );
            
            HttpGet request = new HttpGet(url);
            setAuthHeader(request);

            try (CloseableHttpResponse response = httpClient.execute(request)) {
                if (response.getStatusLine().getStatusCode() == 200) {
                    String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                    return parseTestCase(responseBody);
                } else {
                    logger.error("Failed to fetch test case: {} - Status: {}", 
                                workItemId, response.getStatusLine().getStatusCode());
                    return null;
                }
            }
        } catch (IOException e) {
            logger.error("Error fetching test case: {}", workItemId, e);
            return null;
        }
    }

    /**
     * Fetch bulk test cases using WIQL query
     */
    public List<AzureDevOpsTestCase> fetchBulkTestCases(String wiqlQuery) {
        List<AzureDevOpsTestCase> testCases = new ArrayList<>();
        try {
            // First, execute WIQL query to get work item IDs
            String queryUrl = String.format(
                "https://dev.azure.com/%s/%s/_apis/wit/wiql?api-version=7.1",
                organization, project
            );
            
            org.apache.http.client.methods.HttpPost queryRequest = 
                new org.apache.http.client.methods.HttpPost(queryUrl);
            setAuthHeader(queryRequest);
            queryRequest.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");

            JsonObject wiqlObject = new JsonObject();
            wiqlObject.addProperty("query", wiqlQuery);
            
            org.apache.http.entity.StringEntity entity = 
                new org.apache.http.entity.StringEntity(wiqlObject.toString(), StandardCharsets.UTF_8);
            queryRequest.setEntity(entity);

            try (CloseableHttpResponse queryResponse = httpClient.execute(queryRequest)) {
                if (queryResponse.getStatusLine().getStatusCode() == 200) {
                    String queryResponseBody = EntityUtils.toString(
                        queryResponse.getEntity(), StandardCharsets.UTF_8);
                    JsonObject queryResult = JsonParser.parseString(queryResponseBody).getAsJsonObject();
                    JsonArray workItems = queryResult.getAsJsonArray("workItems");

                    // Fetch details for each work item
                    if (workItems.size() > 0) {
                        List<Integer> workItemIds = new ArrayList<>();
                        for (JsonElement item : workItems) {
                            workItemIds.add(item.getAsJsonObject().get("id").getAsInt());
                        }
                        
                        // Fetch in batches
                        for (Integer workItemId : workItemIds) {
                            AzureDevOpsTestCase testCase = fetchTestCase(workItemId);
                            if (testCase != null) {
                                testCases.add(testCase);
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            logger.error("Error fetching bulk test cases", e);
        }
        return testCases;
    }

    /**
     * Fetch test cases by test plan
     */
    public List<AzureDevOpsTestCase> fetchTestCasesByTestPlan(int testPlanId) {
        try {
            String url = String.format(
                "https://dev.azure.com/%s/%s/_apis/testplan/Plans/%d/Suites?api-version=7.1",
                organization, project, testPlanId
            );
            
            HttpGet request = new HttpGet(url);
            setAuthHeader(request);

            List<AzureDevOpsTestCase> testCases = new ArrayList<>();
            try (CloseableHttpResponse response = httpClient.execute(request)) {
                if (response.getStatusLine().getStatusCode() == 200) {
                    String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                    JsonObject jsonResponse = JsonParser.parseString(responseBody).getAsJsonObject();
                    JsonArray suites = jsonResponse.getAsJsonArray("value");

                    for (JsonElement suiteElement : suites) {
                        JsonObject suite = suiteElement.getAsJsonObject();
                        if (suite.has("testCases")) {
                            JsonArray testCasesArray = suite.getAsJsonArray("testCases");
                            for (JsonElement testCaseElement : testCasesArray) {
                                JsonObject testCaseObj = testCaseElement.getAsJsonObject();
                                int workItemId = testCaseObj.get("workItem").getAsJsonObject()
                                    .get("id").getAsInt();
                                AzureDevOpsTestCase testCase = fetchTestCase(workItemId);
                                if (testCase != null) {
                                    testCases.add(testCase);
                                }
                            }
                        }
                    }
                }
            }
            return testCases;
        } catch (IOException e) {
            logger.error("Error fetching test cases by test plan", e);
            return new ArrayList<>();
        }
    }

    private AzureDevOpsTestCase parseTestCase(String jsonResponse) {
        try {
            JsonObject jsonObject = JsonParser.parseString(jsonResponse).getAsJsonObject();
            JsonObject fields = jsonObject.getAsJsonObject("fields");
            
            int id = jsonObject.get("id").getAsInt();
            String title = fields.has("System.Title") ? 
                fields.get("System.Title").getAsString() : "";
            String description = fields.has("System.Description") ? 
                extractTextFromHtml(fields.get("System.Description").getAsString()) : "";
            String state = fields.has("System.State") ? 
                fields.get("System.State").getAsString() : "";
            String priority = fields.has("Microsoft.VSTS.Common.Priority") ? 
                fields.get("Microsoft.VSTS.Common.Priority").getAsString() : "";

            // Extract test steps
            List<String> testSteps = new ArrayList<>();
            if (fields.has("Microsoft.VSTS.TCM.Steps")) {
                String stepsHtml = fields.get("Microsoft.VSTS.TCM.Steps").getAsString();
                testSteps = parseTestSteps(stepsHtml);
            }

            return new AzureDevOpsTestCase(id, title, description, state, priority, testSteps);
        } catch (Exception e) {
            logger.error("Error parsing test case", e);
            return null;
        }
    }

    private List<String> parseTestSteps(String stepsHtml) {
        List<String> steps = new ArrayList<>();
        // Simple HTML parsing - extract step text
        // In production, use a proper HTML parser
        String[] lines = stepsHtml.split("<div");
        for (String line : lines) {
            if (line.contains("Step:") || line.contains("Action:")) {
                String text = line.replaceAll("<[^>]+>", "").trim();
                if (!text.isEmpty()) {
                    steps.add(text);
                }
            }
        }
        return steps;
    }

    private String extractTextFromHtml(String html) {
        if (html == null || html.isEmpty()) {
            return "";
        }
        return html.replaceAll("<[^>]+>", "").trim();
    }

    private void setAuthHeader(org.apache.http.HttpRequest request) {
        String auth = ":" + personalAccessToken;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));
        request.setHeader(HttpHeaders.AUTHORIZATION, "Basic " + encodedAuth);
    }

    public void close() {
        try {
            httpClient.close();
        } catch (IOException e) {
            logger.error("Error closing HTTP client", e);
        }
    }
}

