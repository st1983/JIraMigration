package com.nammnet.integration;

/**
 * Quick command-line tool for Azure DevOps bulk import
 * Usage: java QuickADOBulkImport <organization> <project> <pat> <wiqlQuery> <outputFile> <singleFile>
 */
public class QuickADOBulkImport {
    public static void main(String[] args) {
        if (args.length < 5) {
            System.out.println("Usage: QuickADOBulkImport <organization> <project> <pat> <wiqlQuery> <outputFile> [singleFile]");
            System.out.println("Example: QuickADOBulkImport org project pat \"SELECT [System.Id] FROM WorkItems\" BulkImport false");
            System.exit(1);
        }

        String organization = args[0];
        String project = args[1];
        String pat = args[2];
        String wiqlQuery = args[3];
        String outputFile = args[4];
        boolean singleFile = args.length > 5 && args[5].equalsIgnoreCase("true");

        System.out.println("Importing test cases from Azure DevOps...");
        System.out.println("Organization: " + organization);
        System.out.println("Project: " + project);
        System.out.println("WIQL Query: " + wiqlQuery);
        System.out.println("Output File: " + outputFile);
        System.out.println("Single File: " + singleFile);
        System.out.println();

        try {
            TestCaseImporter.importBulkTestCasesFromADO(
                organization, project, pat, wiqlQuery, outputFile, singleFile);
            System.out.println("✓ Successfully imported test cases!");
            System.out.println("Feature files created at: src/test/resources/features/imported/");
        } catch (Exception e) {
            System.err.println("✗ Error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}

