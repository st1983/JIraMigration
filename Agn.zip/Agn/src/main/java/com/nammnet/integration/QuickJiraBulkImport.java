package com.nammnet.integration;

/**
 * Quick command-line tool for Jira bulk import
 * Usage: java QuickJiraBulkImport <jiraUrl> <username> <apiToken> <jqlQuery> <outputFile> <singleFile>
 */
public class QuickJiraBulkImport {
    public static void main(String[] args) {
        if (args.length < 5) {
            System.out.println("Usage: QuickJiraBulkImport <jiraUrl> <username> <apiToken> <jqlQuery> <outputFile> [singleFile]");
            System.out.println("Example: QuickJiraBulkImport https://company.atlassian.net user@company.com token \"project = TEST\" BulkImport false");
            System.exit(1);
        }

        String jiraUrl = args[0];
        String username = args[1];
        String apiToken = args[2];
        String jqlQuery = args[3];
        String outputFile = args[4];
        boolean singleFile = args.length > 5 && args[5].equalsIgnoreCase("true");

        System.out.println("Importing test cases from Jira...");
        System.out.println("Jira URL: " + jiraUrl);
        System.out.println("JQL Query: " + jqlQuery);
        System.out.println("Output File: " + outputFile);
        System.out.println("Single File: " + singleFile);
        System.out.println();

        try {
            TestCaseImporter.importBulkTestCasesFromJira(
                jiraUrl, username, apiToken, jqlQuery, outputFile, singleFile);
            System.out.println("✓ Successfully imported test cases!");
            System.out.println("Feature files created at: src/test/resources/features/imported/");
        } catch (Exception e) {
            System.err.println("✗ Error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}

