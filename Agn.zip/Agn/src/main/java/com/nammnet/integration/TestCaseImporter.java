package com.nammnet.integration;

import com.nammnet.integration.ado.ADOToFeatureConverter;
import com.nammnet.integration.ado.AzureDevOpsClient;
import com.nammnet.integration.ado.AzureDevOpsTestCase;
import com.nammnet.integration.jira.JiraClient;
import com.nammnet.integration.jira.JiraTestCase;
import com.nammnet.integration.jira.JiraToFeatureConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Main class for importing test cases from Jira and Azure DevOps
 * Production-ready utility class
 */
public class TestCaseImporter {
    private static final Logger logger = LoggerFactory.getLogger(TestCaseImporter.class);
    private static final String DEFAULT_OUTPUT_DIR = "src/test/resources/features/imported";

    /**
     * Import single test case from Jira
     */
    public static void importSingleTestCaseFromJira(String jiraUrl, String username, 
                                                    String apiToken, String issueKey, 
                                                    String outputFileName) {
        JiraClient jiraClient = new JiraClient(jiraUrl, username, apiToken);
        try {
            JiraTestCase testCase = jiraClient.fetchTestCase(issueKey);
            if (testCase != null) {
                JiraToFeatureConverter converter = new JiraToFeatureConverter(DEFAULT_OUTPUT_DIR);
                converter.convertSingleTestCase(testCase, outputFileName);
                logger.info("Successfully imported test case: {}", issueKey);
            } else {
                logger.error("Failed to fetch test case: {}", issueKey);
            }
        } finally {
            jiraClient.close();
        }
    }

    /**
     * Import bulk test cases from Jira
     */
    public static void importBulkTestCasesFromJira(String jiraUrl, String username, 
                                                  String apiToken, String jqlQuery, 
                                                  String baseFileName, boolean singleFile) {
        JiraClient jiraClient = new JiraClient(jiraUrl, username, apiToken);
        try {
            List<JiraTestCase> testCases = jiraClient.fetchBulkTestCases(jqlQuery);
            JiraToFeatureConverter converter = new JiraToFeatureConverter(DEFAULT_OUTPUT_DIR);
            
            if (singleFile) {
                converter.convertToSingleFeatureFile(testCases, baseFileName);
            } else {
                converter.convertBulkTestCases(testCases, baseFileName);
            }
            logger.info("Successfully imported {} test cases from Jira", testCases.size());
        } finally {
            jiraClient.close();
        }
    }

    /**
     * Import test cases from Jira by project
     */
    public static void importTestCasesFromJiraProject(String jiraUrl, String username, 
                                                      String apiToken, String projectKey, 
                                                      String baseFileName, boolean singleFile) {
        JiraClient jiraClient = new JiraClient(jiraUrl, username, apiToken);
        try {
            List<JiraTestCase> testCases = jiraClient.fetchTestCasesByProject(projectKey);
            JiraToFeatureConverter converter = new JiraToFeatureConverter(DEFAULT_OUTPUT_DIR);
            
            if (singleFile) {
                converter.convertToSingleFeatureFile(testCases, baseFileName);
            } else {
                converter.convertBulkTestCases(testCases, baseFileName);
            }
            logger.info("Successfully imported {} test cases from project: {}", 
                       testCases.size(), projectKey);
        } finally {
            jiraClient.close();
        }
    }

    /**
     * Import single test case from Azure DevOps
     */
    public static void importSingleTestCaseFromADO(String organization, String project, 
                                                   String personalAccessToken, int workItemId, 
                                                   String outputFileName) {
        AzureDevOpsClient adoClient = new AzureDevOpsClient(organization, project, personalAccessToken);
        try {
            AzureDevOpsTestCase testCase = adoClient.fetchTestCase(workItemId);
            if (testCase != null) {
                ADOToFeatureConverter converter = new ADOToFeatureConverter(DEFAULT_OUTPUT_DIR);
                converter.convertSingleTestCase(testCase, outputFileName);
                logger.info("Successfully imported test case: {}", workItemId);
            } else {
                logger.error("Failed to fetch test case: {}", workItemId);
            }
        } finally {
            adoClient.close();
        }
    }

    /**
     * Import bulk test cases from Azure DevOps
     */
    public static void importBulkTestCasesFromADO(String organization, String project, 
                                                  String personalAccessToken, String wiqlQuery, 
                                                  String baseFileName, boolean singleFile) {
        AzureDevOpsClient adoClient = new AzureDevOpsClient(organization, project, personalAccessToken);
        try {
            List<AzureDevOpsTestCase> testCases = adoClient.fetchBulkTestCases(wiqlQuery);
            ADOToFeatureConverter converter = new ADOToFeatureConverter(DEFAULT_OUTPUT_DIR);
            
            if (singleFile) {
                converter.convertToSingleFeatureFile(testCases, baseFileName);
            } else {
                converter.convertBulkTestCases(testCases, baseFileName);
            }
            logger.info("Successfully imported {} test cases from Azure DevOps", testCases.size());
        } finally {
            adoClient.close();
        }
    }

    /**
     * Import test cases from Azure DevOps by test plan
     */
    public static void importTestCasesFromADOTestPlan(String organization, String project, 
                                                      String personalAccessToken, int testPlanId, 
                                                      String baseFileName, boolean singleFile) {
        AzureDevOpsClient adoClient = new AzureDevOpsClient(organization, project, personalAccessToken);
        try {
            List<AzureDevOpsTestCase> testCases = adoClient.fetchTestCasesByTestPlan(testPlanId);
            ADOToFeatureConverter converter = new ADOToFeatureConverter(DEFAULT_OUTPUT_DIR);
            
            if (singleFile) {
                converter.convertToSingleFeatureFile(testCases, baseFileName);
            } else {
                converter.convertBulkTestCases(testCases, baseFileName);
            }
            logger.info("Successfully imported {} test cases from test plan: {}", 
                       testCases.size(), testPlanId);
        } finally {
            adoClient.close();
        }
    }
}

