package com.nammnet.integration.jira;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Converts Jira test cases to Cucumber feature files
 */
public class JiraToFeatureConverter {
    private static final Logger logger = LoggerFactory.getLogger(JiraToFeatureConverter.class);
    private final String outputDirectory;

    public JiraToFeatureConverter(String outputDirectory) {
        this.outputDirectory = outputDirectory;
        createOutputDirectory();
    }

    /**
     * Convert single test case to feature file
     */
    public void convertSingleTestCase(JiraTestCase testCase, String featureFileName) {
        try {
            String featureContent = generateFeatureContent(testCase);
            String filePath = outputDirectory + File.separator + featureFileName + ".feature";
            FileUtils.writeStringToFile(new File(filePath), featureContent, StandardCharsets.UTF_8);
            logger.info("Feature file created: {}", filePath);
        } catch (IOException e) {
            logger.error("Error converting test case to feature file", e);
        }
    }

    /**
     * Convert bulk test cases to feature files
     */
    public void convertBulkTestCases(List<JiraTestCase> testCases, String baseFeatureFileName) {
        for (int i = 0; i < testCases.size(); i++) {
            JiraTestCase testCase = testCases.get(i);
            String fileName = baseFeatureFileName + "_" + (i + 1) + "_" + 
                            sanitizeFileName(testCase.getKey());
            convertSingleTestCase(testCase, fileName);
        }
        logger.info("Converted {} test cases to feature files", testCases.size());
    }

    /**
     * Convert multiple test cases to a single feature file
     */
    public void convertToSingleFeatureFile(List<JiraTestCase> testCases, String featureFileName) {
        try {
            StringBuilder featureContent = new StringBuilder();
            featureContent.append("@JiraImport\n");
            featureContent.append("Feature: Imported Test Cases from Jira\n");
            featureContent.append("  Test cases imported from Jira\n\n");

            for (JiraTestCase testCase : testCases) {
                featureContent.append(generateScenarioContent(testCase));
                featureContent.append("\n");
            }

            String filePath = outputDirectory + File.separator + featureFileName + ".feature";
            FileUtils.writeStringToFile(new File(filePath), featureContent.toString(), StandardCharsets.UTF_8);
            logger.info("Feature file created with {} scenarios: {}", testCases.size(), filePath);
        } catch (IOException e) {
            logger.error("Error converting test cases to feature file", e);
        }
    }

    private String generateFeatureContent(JiraTestCase testCase) {
        StringBuilder content = new StringBuilder();
        content.append("@JiraImport @").append(testCase.getPriority()).append("\n");
        content.append("Feature: ").append(testCase.getSummary()).append("\n");
        content.append("  Jira Key: ").append(testCase.getKey()).append("\n");
        if (testCase.getDescription() != null && !testCase.getDescription().isEmpty()) {
            content.append("  ").append(testCase.getDescription()).append("\n");
        }
        content.append("\n");
        content.append(generateScenarioContent(testCase));
        return content.toString();
    }

    private String generateScenarioContent(JiraTestCase testCase) {
        StringBuilder scenario = new StringBuilder();
        scenario.append("  Scenario: ").append(testCase.getSummary()).append("\n");
        
        if (testCase.getTestSteps() != null && !testCase.getTestSteps().isEmpty()) {
            for (String step : testCase.getTestSteps()) {
                scenario.append("    ").append(convertToGherkinStep(step)).append("\n");
            }
        } else {
            // Default scenario if no test steps
            scenario.append("    Given I am on the application\n");
            scenario.append("    When I perform the test action\n");
            scenario.append("    Then I should see the expected result\n");
        }
        
        return scenario.toString();
    }

    private String convertToGherkinStep(String step) {
        String lowerStep = step.toLowerCase().trim();
        
        if (lowerStep.startsWith("given") || lowerStep.startsWith("when") || 
            lowerStep.startsWith("then") || lowerStep.startsWith("and") || 
            lowerStep.startsWith("but")) {
            return step;
        }
        
        // Auto-detect step type
        if (lowerStep.contains("navigate") || lowerStep.contains("open") || 
            lowerStep.contains("go to") || lowerStep.contains("visit")) {
            return "Given " + step;
        } else if (lowerStep.contains("click") || lowerStep.contains("enter") || 
                   lowerStep.contains("select") || lowerStep.contains("fill") ||
                   lowerStep.contains("submit") || lowerStep.contains("perform")) {
            return "When " + step;
        } else if (lowerStep.contains("verify") || lowerStep.contains("check") || 
                   lowerStep.contains("validate") || lowerStep.contains("should") ||
                   lowerStep.contains("assert") || lowerStep.contains("see")) {
            return "Then " + step;
        } else {
            return "Given " + step;
        }
    }

    private String sanitizeFileName(String fileName) {
        return fileName.replaceAll("[^a-zA-Z0-9_-]", "_");
    }

    private void createOutputDirectory() {
        try {
            File dir = new File(outputDirectory);
            if (!dir.exists()) {
                dir.mkdirs();
            }
        } catch (Exception e) {
            logger.error("Error creating output directory", e);
        }
    }
}

