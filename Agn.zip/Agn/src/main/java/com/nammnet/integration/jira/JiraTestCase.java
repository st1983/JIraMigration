package com.nammnet.integration.jira;

import java.util.List;

/**
 * Data model for Jira Test Case
 */
public class JiraTestCase {
    private final String key;
    private final String summary;
    private final String description;
    private final String priority;
    private final List<String> labels;
    private final List<String> testSteps;

    public JiraTestCase(String key, String summary, String description, 
                       String priority, List<String> labels, List<String> testSteps) {
        this.key = key;
        this.summary = summary;
        this.description = description;
        this.priority = priority;
        this.labels = labels;
        this.testSteps = testSteps;
    }

    public String getKey() {
        return key;
    }

    public String getSummary() {
        return summary;
    }

    public String getDescription() {
        return description;
    }

    public String getPriority() {
        return priority;
    }

    public List<String> getLabels() {
        return labels;
    }

    public List<String> getTestSteps() {
        return testSteps;
    }
}

