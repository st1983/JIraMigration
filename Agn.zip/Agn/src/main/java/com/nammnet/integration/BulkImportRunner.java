package com.nammnet.integration;

import com.nammnet.utils.IntegrationConfigReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Scanner;

/**
 * Interactive command-line runner for bulk test case import
 * Easy to use on Windows with simple prompts
 */
public class BulkImportRunner {
    private static final Logger logger = LoggerFactory.getLogger(BulkImportRunner.class);
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("==========================================");
        System.out.println("  Bulk Test Case Import Tool");
        System.out.println("==========================================");
        System.out.println();

        while (true) {
            showMenu();
            int choice = getIntInput("Enter your choice: ");

            switch (choice) {
                case 1:
                    importFromJiraSingle();
                    break;
                case 2:
                    importFromJiraBulk();
                    break;
                case 3:
                    importFromJiraProject();
                    break;
                case 4:
                    importFromADOSingle();
                    break;
                case 5:
                    importFromADOBulk();
                    break;
                case 6:
                    importFromADOTestPlan();
                    break;
                case 7:
                    importUsingConfig();
                    break;
                case 8:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            System.out.println();
        }
    }

    private static void showMenu() {
        System.out.println("Select import option:");
        System.out.println("1. Import Single Test Case from Jira");
        System.out.println("2. Import Bulk Test Cases from Jira (JQL)");
        System.out.println("3. Import Test Cases from Jira Project");
        System.out.println("4. Import Single Test Case from Azure DevOps");
        System.out.println("5. Import Bulk Test Cases from Azure DevOps (WIQL)");
        System.out.println("6. Import Test Cases from Azure DevOps Test Plan");
        System.out.println("7. Quick Import using Configuration File");
        System.out.println("8. Exit");
        System.out.println();
    }

    private static void importFromJiraSingle() {
        System.out.println("\n--- Import Single Test Case from Jira ---");
        String jiraUrl = getStringInput("Enter Jira URL (e.g., https://company.atlassian.net): ");
        String username = getStringInput("Enter Jira Username/Email: ");
        String apiToken = getStringInput("Enter Jira API Token: ");
        String issueKey = getStringInput("Enter Issue Key (e.g., TEST-123): ");
        String outputFile = getStringInput("Enter Output Filename (without .feature): ");

        System.out.println("\nImporting...");
        try {
            TestCaseImporter.importSingleTestCaseFromJira(
                jiraUrl, username, apiToken, issueKey, outputFile);
            System.out.println("✓ Successfully imported test case!");
            System.out.println("Feature file created at: src/test/resources/features/imported/" + outputFile + ".feature");
        } catch (Exception e) {
            System.out.println("✗ Error: " + e.getMessage());
            logger.error("Import failed", e);
        }
    }

    private static void importFromJiraBulk() {
        System.out.println("\n--- Import Bulk Test Cases from Jira ---");
        String jiraUrl = getStringInput("Enter Jira URL: ");
        String username = getStringInput("Enter Jira Username/Email: ");
        String apiToken = getStringInput("Enter Jira API Token: ");
        System.out.println("Enter JQL Query (e.g., project = TEST AND type = Test):");
        String jqlQuery = scanner.nextLine();
        String baseFile = getStringInput("Enter Base Filename: ");
        boolean singleFile = getYesNoInput("Create single file? (y/n): ");

        System.out.println("\nImporting...");
        try {
            TestCaseImporter.importBulkTestCasesFromJira(
                jiraUrl, username, apiToken, jqlQuery, baseFile, singleFile);
            System.out.println("✓ Successfully imported test cases!");
            System.out.println("Feature files created at: src/test/resources/features/imported/");
        } catch (Exception e) {
            System.out.println("✗ Error: " + e.getMessage());
            logger.error("Bulk import failed", e);
        }
    }

    private static void importFromJiraProject() {
        System.out.println("\n--- Import Test Cases from Jira Project ---");
        String jiraUrl = getStringInput("Enter Jira URL: ");
        String username = getStringInput("Enter Jira Username/Email: ");
        String apiToken = getStringInput("Enter Jira API Token: ");
        String projectKey = getStringInput("Enter Project Key (e.g., TEST): ");
        String baseFile = getStringInput("Enter Base Filename: ");
        boolean singleFile = getYesNoInput("Create single file? (y/n): ");

        System.out.println("\nImporting...");
        try {
            TestCaseImporter.importTestCasesFromJiraProject(
                jiraUrl, username, apiToken, projectKey, baseFile, singleFile);
            System.out.println("✓ Successfully imported test cases!");
            System.out.println("Feature files created at: src/test/resources/features/imported/");
        } catch (Exception e) {
            System.out.println("✗ Error: " + e.getMessage());
            logger.error("Project import failed", e);
        }
    }

    private static void importFromADOSingle() {
        System.out.println("\n--- Import Single Test Case from Azure DevOps ---");
        String organization = getStringInput("Enter Organization: ");
        String project = getStringInput("Enter Project: ");
        String pat = getStringInput("Enter Personal Access Token: ");
        int workItemId = getIntInput("Enter Work Item ID: ");
        String outputFile = getStringInput("Enter Output Filename (without .feature): ");

        System.out.println("\nImporting...");
        try {
            TestCaseImporter.importSingleTestCaseFromADO(
                organization, project, pat, workItemId, outputFile);
            System.out.println("✓ Successfully imported test case!");
            System.out.println("Feature file created at: src/test/resources/features/imported/" + outputFile + ".feature");
        } catch (Exception e) {
            System.out.println("✗ Error: " + e.getMessage());
            logger.error("Import failed", e);
        }
    }

    private static void importFromADOBulk() {
        System.out.println("\n--- Import Bulk Test Cases from Azure DevOps ---");
        String organization = getStringInput("Enter Organization: ");
        String project = getStringInput("Enter Project: ");
        String pat = getStringInput("Enter Personal Access Token: ");
        System.out.println("Enter WIQL Query:");
        System.out.println("Example: SELECT [System.Id] FROM WorkItems WHERE [System.WorkItemType] = 'Test Case'");
        String wiqlQuery = scanner.nextLine();
        String baseFile = getStringInput("Enter Base Filename: ");
        boolean singleFile = getYesNoInput("Create single file? (y/n): ");

        System.out.println("\nImporting...");
        try {
            TestCaseImporter.importBulkTestCasesFromADO(
                organization, project, pat, wiqlQuery, baseFile, singleFile);
            System.out.println("✓ Successfully imported test cases!");
            System.out.println("Feature files created at: src/test/resources/features/imported/");
        } catch (Exception e) {
            System.out.println("✗ Error: " + e.getMessage());
            logger.error("Bulk import failed", e);
        }
    }

    private static void importFromADOTestPlan() {
        System.out.println("\n--- Import Test Cases from Azure DevOps Test Plan ---");
        String organization = getStringInput("Enter Organization: ");
        String project = getStringInput("Enter Project: ");
        String pat = getStringInput("Enter Personal Access Token: ");
        int testPlanId = getIntInput("Enter Test Plan ID: ");
        String baseFile = getStringInput("Enter Base Filename: ");
        boolean singleFile = getYesNoInput("Create single file? (y/n): ");

        System.out.println("\nImporting...");
        try {
            TestCaseImporter.importTestCasesFromADOTestPlan(
                organization, project, pat, testPlanId, baseFile, singleFile);
            System.out.println("✓ Successfully imported test cases!");
            System.out.println("Feature files created at: src/test/resources/features/imported/");
        } catch (Exception e) {
            System.out.println("✗ Error: " + e.getMessage());
            logger.error("Test plan import failed", e);
        }
    }

    private static void importUsingConfig() {
        System.out.println("\n--- Quick Import using Configuration File ---");
        System.out.println("Make sure integration.properties is configured!");
        System.out.println();
        
        System.out.println("Select source:");
        System.out.println("1. Jira - Single Test Case");
        System.out.println("2. Jira - Bulk (JQL)");
        System.out.println("3. Jira - By Project");
        System.out.println("4. Azure DevOps - Single Test Case");
        System.out.println("5. Azure DevOps - Bulk (WIQL)");
        System.out.println("6. Azure DevOps - By Test Plan");
        
        int choice = getIntInput("Enter choice: ");
        
        try {
            switch (choice) {
                case 1:
                    String issueKey = getStringInput("Enter Issue Key: ");
                    String output1 = getStringInput("Enter Output Filename: ");
                    TestCaseImporter.importSingleTestCaseFromJira(
                        IntegrationConfigReader.getJiraUrl(),
                        IntegrationConfigReader.getJiraUsername(),
                        IntegrationConfigReader.getJiraApiToken(),
                        issueKey, output1);
                    break;
                case 2:
                    System.out.println("Enter JQL Query:");
                    String jql = scanner.nextLine();
                    String base1 = getStringInput("Enter Base Filename: ");
                    TestCaseImporter.importBulkTestCasesFromJira(
                        IntegrationConfigReader.getJiraUrl(),
                        IntegrationConfigReader.getJiraUsername(),
                        IntegrationConfigReader.getJiraApiToken(),
                        jql, base1, IntegrationConfigReader.isSingleFileImport());
                    break;
                case 3:
                    String projectKey = getStringInput("Enter Project Key: ");
                    String base2 = getStringInput("Enter Base Filename: ");
                    TestCaseImporter.importTestCasesFromJiraProject(
                        IntegrationConfigReader.getJiraUrl(),
                        IntegrationConfigReader.getJiraUsername(),
                        IntegrationConfigReader.getJiraApiToken(),
                        projectKey, base2, IntegrationConfigReader.isSingleFileImport());
                    break;
                case 4:
                    int workItemId = getIntInput("Enter Work Item ID: ");
                    String output2 = getStringInput("Enter Output Filename: ");
                    TestCaseImporter.importSingleTestCaseFromADO(
                        IntegrationConfigReader.getADOOrganization(),
                        IntegrationConfigReader.getADOProject(),
                        IntegrationConfigReader.getADOPersonalAccessToken(),
                        workItemId, output2);
                    break;
                case 5:
                    System.out.println("Enter WIQL Query:");
                    String wiql = scanner.nextLine();
                    String base3 = getStringInput("Enter Base Filename: ");
                    TestCaseImporter.importBulkTestCasesFromADO(
                        IntegrationConfigReader.getADOOrganization(),
                        IntegrationConfigReader.getADOProject(),
                        IntegrationConfigReader.getADOPersonalAccessToken(),
                        wiql, base3, IntegrationConfigReader.isSingleFileImport());
                    break;
                case 6:
                    int testPlanId = getIntInput("Enter Test Plan ID: ");
                    String base4 = getStringInput("Enter Base Filename: ");
                    TestCaseImporter.importTestCasesFromADOTestPlan(
                        IntegrationConfigReader.getADOOrganization(),
                        IntegrationConfigReader.getADOProject(),
                        IntegrationConfigReader.getADOPersonalAccessToken(),
                        testPlanId, base4, IntegrationConfigReader.isSingleFileImport());
                    break;
                default:
                    System.out.println("Invalid choice.");
                    return;
            }
            System.out.println("✓ Successfully imported!");
        } catch (Exception e) {
            System.out.println("✗ Error: " + e.getMessage());
            System.out.println("Please check your configuration file.");
        }
    }

    private static String getStringInput(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    private static int getIntInput(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static boolean getYesNoInput(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim().toLowerCase();
            if (input.equals("y") || input.equals("yes")) {
                return true;
            } else if (input.equals("n") || input.equals("no")) {
                return false;
            } else {
                System.out.println("Please enter 'y' or 'n'.");
            }
        }
    }
}

