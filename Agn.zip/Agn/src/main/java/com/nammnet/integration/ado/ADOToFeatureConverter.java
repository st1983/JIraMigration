package com.nammnet.integration.ado;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Converts Azure DevOps test cases to Cucumber feature files
 */
public class ADOToFeatureConverter {
    private static final Logger logger = LoggerFactory.getLogger(ADOToFeatureConverter.class);
    private final String outputDirectory;

    public ADOToFeatureConverter(String outputDirectory) {
        this.outputDirectory = outputDirectory;
        createOutputDirectory();
    }

    /**
     * Convert single test case to feature file
     */
    public void convertSingleTestCase(AzureDevOpsTestCase testCase, String featureFileName) {
        try {
            String featureContent = generateFeatureContent(testCase);
            String filePath = outputDirectory + File.separator + featureFileName + ".feature";
            FileUtils.writeStringToFile(new File(filePath), featureContent, StandardCharsets.UTF_8);
            logger.info("Feature file created: {}", filePath);
        } catch (IOException e) {
            logger.error("Error converting test case to feature file", e);
        }
    }

    /**
     * Convert bulk test cases to feature files
     */
    public void convertBulkTestCases(List<AzureDevOpsTestCase> testCases, String baseFeatureFileName) {
        for (AzureDevOpsTestCase testCase : testCases) {
            String fileName = baseFeatureFileName + "_" + testCase.getId() + "_" + 
                            sanitizeFileName(testCase.getTitle());
            convertSingleTestCase(testCase, fileName);
        }
        logger.info("Converted {} test cases to feature files", testCases.size());
    }

    /**
     * Convert multiple test cases to a single feature file
     */
    public void convertToSingleFeatureFile(List<AzureDevOpsTestCase> testCases, String featureFileName) {
        try {
            StringBuilder featureContent = new StringBuilder();
            featureContent.append("@ADOImport\n");
            featureContent.append("Feature: Imported Test Cases from Azure DevOps\n");
            featureContent.append("  Test cases imported from Azure DevOps\n\n");

            for (AzureDevOpsTestCase testCase : testCases) {
                featureContent.append(generateScenarioContent(testCase));
                featureContent.append("\n");
            }

            String filePath = outputDirectory + File.separator + featureFileName + ".feature";
            FileUtils.writeStringToFile(new File(filePath), featureContent.toString(), StandardCharsets.UTF_8);
            logger.info("Feature file created with {} scenarios: {}", testCases.size(), filePath);
        } catch (IOException e) {
            logger.error("Error converting test cases to feature file", e);
        }
    }

    private String generateFeatureContent(AzureDevOpsTestCase testCase) {
        StringBuilder content = new StringBuilder();
        content.append("@ADOImport @").append(testCase.getState()).append("\n");
        content.append("Feature: ").append(testCase.getTitle()).append("\n");
        content.append("  ADO Work Item ID: ").append(testCase.getId()).append("\n");
        if (testCase.getDescription() != null && !testCase.getDescription().isEmpty()) {
            content.append("  ").append(testCase.getDescription()).append("\n");
        }
        content.append("\n");
        content.append(generateScenarioContent(testCase));
        return content.toString();
    }

    private String generateScenarioContent(AzureDevOpsTestCase testCase) {
        StringBuilder scenario = new StringBuilder();
        scenario.append("  Scenario: ").append(testCase.getTitle()).append("\n");
        
        if (testCase.getTestSteps() != null && !testCase.getTestSteps().isEmpty()) {
            for (String step : testCase.getTestSteps()) {
                scenario.append("    ").append(convertToGherkinStep(step)).append("\n");
            }
        } else {
            // Default scenario if no test steps
            scenario.append("    Given I am on the application\n");
            scenario.append("    When I perform the test action\n");
            scenario.append("    Then I should see the expected result\n");
        }
        
        return scenario.toString();
    }

    private String convertToGherkinStep(String step) {
        String lowerStep = step.toLowerCase().trim();
        
        if (lowerStep.startsWith("given") || lowerStep.startsWith("when") || 
            lowerStep.startsWith("then") || lowerStep.startsWith("and") || 
            lowerStep.startsWith("but")) {
            return step;
        }
        
        // Auto-detect step type
        if (lowerStep.contains("navigate") || lowerStep.contains("open") || 
            lowerStep.contains("go to") || lowerStep.contains("visit")) {
            return "Given " + step;
        } else if (lowerStep.contains("click") || lowerStep.contains("enter") || 
                   lowerStep.contains("select") || lowerStep.contains("fill") ||
                   lowerStep.contains("submit") || lowerStep.contains("perform")) {
            return "When " + step;
        } else if (lowerStep.contains("verify") || lowerStep.contains("check") || 
                   lowerStep.contains("validate") || lowerStep.contains("should") ||
                   lowerStep.contains("assert") || lowerStep.contains("see")) {
            return "Then " + step;
        } else {
            return "Given " + step;
        }
    }

    private String sanitizeFileName(String fileName) {
        return fileName.replaceAll("[^a-zA-Z0-9_-]", "_");
    }

    private void createOutputDirectory() {
        try {
            File dir = new File(outputDirectory);
            if (!dir.exists()) {
                dir.mkdirs();
            }
        } catch (Exception e) {
            logger.error("Error creating output directory", e);
        }
    }
}

