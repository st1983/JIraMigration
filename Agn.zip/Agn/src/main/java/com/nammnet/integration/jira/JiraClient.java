package com.nammnet.integration.jira;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * Jira Client for fetching test cases from Jira
 * Supports both single and bulk test case import
 */
public class JiraClient {
    private static final Logger logger = LoggerFactory.getLogger(JiraClient.class);
    private final String jiraUrl;
    private final String username;
    private final String apiToken;
    private final CloseableHttpClient httpClient;

    public JiraClient(String jiraUrl, String username, String apiToken) {
        this.jiraUrl = jiraUrl.endsWith("/") ? jiraUrl : jiraUrl + "/";
        this.username = username;
        this.apiToken = apiToken;
        this.httpClient = HttpClients.createDefault();
    }

    /**
     * Fetch a single test case by issue key
     */
    public JiraTestCase fetchTestCase(String issueKey) {
        try {
            String url = jiraUrl + "rest/api/3/issue/" + issueKey;
            HttpGet request = new HttpGet(url);
            setAuthHeader(request);

            try (CloseableHttpResponse response = httpClient.execute(request)) {
                if (response.getStatusLine().getStatusCode() == 200) {
                    String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                    return parseTestCase(responseBody);
                } else {
                    logger.error("Failed to fetch test case: {} - Status: {}", 
                                issueKey, response.getStatusLine().getStatusCode());
                    return null;
                }
            }
        } catch (IOException e) {
            logger.error("Error fetching test case: {}", issueKey, e);
            return null;
        }
    }

    /**
     * Fetch bulk test cases using JQL query
     */
    public List<JiraTestCase> fetchBulkTestCases(String jqlQuery) {
        List<JiraTestCase> testCases = new ArrayList<>();
        try {
            String url = jiraUrl + "rest/api/3/search";
            HttpPost request = new HttpPost(url);
            setAuthHeader(request);
            request.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");

            JsonObject jqlObject = new JsonObject();
            jqlObject.addProperty("jql", jqlQuery);
            jqlObject.addProperty("maxResults", 100);
            jqlObject.addProperty("fields", "summary,description,priority,labels,customfield_10038");

            StringEntity entity = new StringEntity(jqlObject.toString(), StandardCharsets.UTF_8);
            request.setEntity(entity);

            try (CloseableHttpResponse response = httpClient.execute(request)) {
                if (response.getStatusLine().getStatusCode() == 200) {
                    String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                    JsonObject jsonResponse = JsonParser.parseString(responseBody).getAsJsonObject();
                    JsonArray issues = jsonResponse.getAsJsonArray("issues");

                    for (JsonElement issueElement : issues) {
                        JsonObject issue = issueElement.getAsJsonObject();
                        JiraTestCase testCase = parseTestCase(issue.toString());
                        if (testCase != null) {
                            testCases.add(testCase);
                        }
                    }
                } else {
                    logger.error("Failed to fetch bulk test cases - Status: {}", 
                                response.getStatusLine().getStatusCode());
                }
            }
        } catch (IOException e) {
            logger.error("Error fetching bulk test cases", e);
        }
        return testCases;
    }

    /**
     * Fetch test cases by project key
     */
    public List<JiraTestCase> fetchTestCasesByProject(String projectKey) {
        String jql = "project = " + projectKey + " AND type = Test";
        return fetchBulkTestCases(jql);
    }

    private JiraTestCase parseTestCase(String jsonResponse) {
        try {
            JsonObject jsonObject = JsonParser.parseString(jsonResponse).getAsJsonObject();
            String key = jsonObject.get("key").getAsString();
            JsonObject fields = jsonObject.getAsJsonObject("fields");
            
            String summary = fields.has("summary") ? fields.get("summary").getAsString() : "";
            String description = fields.has("description") ? 
                extractTextFromDescription(fields.get("description")) : "";
            String priority = fields.has("priority") ? 
                fields.getAsJsonObject("priority").get("name").getAsString() : "";
            
            List<String> labels = new ArrayList<>();
            if (fields.has("labels")) {
                JsonArray labelsArray = fields.getAsJsonArray("labels");
                for (JsonElement label : labelsArray) {
                    labels.add(label.getAsString());
                }
            }

            // Extract test steps if available (custom field)
            List<String> testSteps = new ArrayList<>();
            if (fields.has("customfield_10038")) {
                JsonObject testStepsObj = fields.getAsJsonObject("customfield_10038");
                if (testStepsObj.has("steps")) {
                    JsonArray steps = testStepsObj.getAsJsonArray("steps");
                    for (JsonElement step : steps) {
                        JsonObject stepObj = step.getAsJsonObject();
                        if (stepObj.has("action")) {
                            testSteps.add(stepObj.get("action").getAsString());
                        }
                    }
                }
            }

            return new JiraTestCase(key, summary, description, priority, labels, testSteps);
        } catch (Exception e) {
            logger.error("Error parsing test case", e);
            return null;
        }
    }

    private String extractTextFromDescription(JsonElement description) {
        if (description == null || description.isJsonNull()) {
            return "";
        }
        
        if (description.isJsonPrimitive()) {
            return description.getAsString();
        }
        
        JsonObject descObj = description.getAsJsonObject();
        if (descObj.has("content")) {
            JsonArray content = descObj.getAsJsonArray("content");
            StringBuilder text = new StringBuilder();
            extractTextFromContent(content, text);
            return text.toString();
        }
        
        return "";
    }

    private void extractTextFromContent(JsonArray content, StringBuilder text) {
        for (JsonElement element : content) {
            if (element.isJsonObject()) {
                JsonObject obj = element.getAsJsonObject();
                if (obj.has("text")) {
                    text.append(obj.get("text").getAsString()).append(" ");
                }
                if (obj.has("content")) {
                    extractTextFromContent(obj.getAsJsonArray("content"), text);
                }
            }
        }
    }

    private void setAuthHeader(HttpGet request) {
        String auth = username + ":" + apiToken;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));
        request.setHeader(HttpHeaders.AUTHORIZATION, "Basic " + encodedAuth);
    }

    private void setAuthHeader(HttpPost request) {
        String auth = username + ":" + apiToken;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));
        request.setHeader(HttpHeaders.AUTHORIZATION, "Basic " + encodedAuth);
    }

    public void close() {
        try {
            httpClient.close();
        } catch (IOException e) {
            logger.error("Error closing HTTP client", e);
        }
    }
}

