package com.nammnet.integration.ado;

import java.util.List;

/**
 * Data model for Azure DevOps Test Case
 */
public class AzureDevOpsTestCase {
    private final int id;
    private final String title;
    private final String description;
    private final String state;
    private final String priority;
    private final List<String> testSteps;

    public AzureDevOpsTestCase(int id, String title, String description, 
                              String state, String priority, List<String> testSteps) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.state = state;
        this.priority = priority;
        this.testSteps = testSteps;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getState() {
        return state;
    }

    public String getPriority() {
        return priority;
    }

    public List<String> getTestSteps() {
        return testSteps;
    }
}

