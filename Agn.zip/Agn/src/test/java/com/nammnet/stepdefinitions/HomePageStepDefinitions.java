package com.nammnet.stepdefinitions;

import com.nammnet.pages.HomePage;
import com.nammnet.utils.ExtentReportManager;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class HomePageStepDefinitions {
    private HomePage homePage;

    public HomePageStepDefinitions() {
        this.homePage = new HomePage();
    }

    @Then("I should be on the home page")
    public void i_should_be_on_the_home_page() {
        Assert.assertTrue("Dashboard should be displayed", 
                         homePage.isDashboardDisplayed());
        ExtentReportManager.getTest().pass("User is on the home page");
    }

    @Then("I should see the dashboard")
    public void i_should_see_the_dashboard() {
        Assert.assertTrue("Dashboard should be visible", 
                         homePage.isDashboardDisplayed());
        ExtentReportManager.getTest().info("Dashboard is displayed");
    }

    @Then("I should see the user profile")
    public void i_should_see_the_user_profile() {
        Assert.assertTrue("User profile should be visible", 
                         homePage.isUserProfileDisplayed());
        ExtentReportManager.getTest().info("User profile is displayed");
    }

    @Then("I should see the navigation menu")
    public void i_should_see_the_navigation_menu() {
        Assert.assertTrue("Navigation menu should be visible", 
                         homePage.isNavigationMenuDisplayed());
        ExtentReportManager.getTest().info("Navigation menu is displayed");
    }

    @When("I click on logout")
    public void i_click_on_logout() {
        homePage.clickLogout();
        ExtentReportManager.getTest().info("Clicked on logout");
    }

    @Then("The page title should be {string}")
    public void the_page_title_should_be(String expectedTitle) {
        String actualTitle = homePage.getPageTitle();
        Assert.assertEquals("Page title should match", 
                          expectedTitle, actualTitle);
        ExtentReportManager.getTest().info("Page title verified: " + actualTitle);
    }
}

