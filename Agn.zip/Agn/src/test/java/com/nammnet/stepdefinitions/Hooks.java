package com.nammnet.stepdefinitions;

import com.nammnet.utils.ConfigReader;
import com.nammnet.utils.DriverManager;
import com.nammnet.utils.ExtentReportManager;
import com.aventstack.extentreports.ExtentTest;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;

public class Hooks {
    private static final Logger logger = LoggerFactory.getLogger(Hooks.class);
    private ExtentTest extentTest;

    @Before
    public void setUp(Scenario scenario) {
        String browser = ConfigReader.getBrowser();
        DriverManager.initializeDriver(browser);
        
        extentTest = ExtentReportManager.getExtentReports().createTest(scenario.getName());
        ExtentReportManager.setTest(extentTest);
        
        DriverManager.getDriver().get(ConfigReader.getUrl());
    }

    @After
    public void tearDown(Scenario scenario) {
        if (scenario.isFailed()) {
            byte[] screenshot = ((TakesScreenshot) DriverManager.getDriver())
                    .getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenshot, "image/png", "Screenshot");
            
            ExtentReportManager.getTest().fail("Test Failed: " + scenario.getName());
            try {
                // For ExtentReports 4.x, save screenshot and add to report
                String screenshotPath = System.getProperty("user.dir") + File.separator + 
                                       "test-output" + File.separator + "screenshot_" + 
                                       System.currentTimeMillis() + ".png";
                java.nio.file.Files.write(
                    java.nio.file.Paths.get(screenshotPath), 
                    screenshot);
                ExtentReportManager.getTest().addScreenCaptureFromPath(screenshotPath);
            } catch (Exception e) {
                // If screenshot capture fails, continue without it
                logger.error("Failed to add screenshot to report", e);
            }
        } else {
            ExtentReportManager.getTest().pass("Test Passed: " + scenario.getName());
        }
        
        DriverManager.quitDriver();
    }

    @After("@AllTests")
    public void flushReport() {
        ExtentReportManager.flushReport();
    }
}

