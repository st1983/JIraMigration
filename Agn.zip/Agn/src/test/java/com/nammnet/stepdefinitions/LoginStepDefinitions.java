package com.nammnet.stepdefinitions;

import com.nammnet.pages.LoginPage;
import com.nammnet.utils.ExtentReportManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.junit.Assert;

public class LoginStepDefinitions {
    private LoginPage loginPage;

    public LoginStepDefinitions() {
        this.loginPage = new LoginPage();
    }

    @Given("I am on the login page")
    public void i_am_on_the_login_page() {
        Assert.assertTrue("Login page should be displayed", 
                         loginPage.isLoginPageDisplayed());
        ExtentReportManager.getTest().info("User is on the login page");
    }

    @When("I enter username {string}")
    public void i_enter_username(String username) {
        loginPage.enterUsername(username);
        ExtentReportManager.getTest().info("Entered username: " + username);
    }

    @When("I enter password {string}")
    public void i_enter_password(String password) {
        loginPage.enterPassword(password);
        ExtentReportManager.getTest().info("Entered password");
    }

    @When("I click on login button")
    public void i_click_on_login_button() {
        loginPage.clickLoginButton();
        ExtentReportManager.getTest().info("Clicked on login button");
    }

    @When("I login with username {string} and password {string}")
    public void i_login_with_username_and_password(String username, String password) {
        loginPage.login(username, password);
        ExtentReportManager.getTest().info("Logged in with username: " + username);
    }

    @Then("I should see error message {string}")
    public void i_should_see_error_message(String expectedErrorMessage) {
        Assert.assertTrue("Error message should be displayed", 
                         loginPage.isErrorMessageDisplayed());
        String actualErrorMessage = loginPage.getErrorMessage();
        Assert.assertEquals("Error message should match", 
                          expectedErrorMessage, actualErrorMessage);
        ExtentReportManager.getTest().info("Error message displayed: " + actualErrorMessage);
    }

    @Then("I should be logged in successfully")
    public void i_should_be_logged_in_successfully() {
        // This would typically navigate to home page
        // For now, we'll check if error message is not displayed
        Assert.assertFalse("Error message should not be displayed", 
                          loginPage.isErrorMessageDisplayed());
        ExtentReportManager.getTest().pass("User logged in successfully");
    }

    @Then("I should see welcome message")
    public void i_should_see_welcome_message() {
        Assert.assertTrue("Welcome message should be displayed", 
                         loginPage.isWelcomeMessageDisplayed());
        ExtentReportManager.getTest().info("Welcome message displayed");
    }
}

