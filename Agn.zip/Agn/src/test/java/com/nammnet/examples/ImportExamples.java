package com.nammnet.examples;

import com.nammnet.integration.TestCaseImporter;

/**
 * Examples of how to use the test case import functionality
 */
public class ImportExamples {

    public static void main(String[] args) {
        // Example 1: Import single test case from Jira
        importSingleJiraTestCase();
        
        // Example 2: Import bulk test cases from Jira
        importBulkJiraTestCases();
        
        // Example 3: Import test cases from Jira project
        importJiraProjectTestCases();
        
        // Example 4: Import single test case from Azure DevOps
        importSingleADOTestCase();
        
        // Example 5: Import bulk test cases from Azure DevOps
        importBulkADOTestCases();
        
        // Example 6: Import test cases from ADO test plan
        importADOTestPlanTestCases();
    }

    /**
     * Example: Import single test case from Jira
     */
    private static void importSingleJiraTestCase() {
        String jiraUrl = "https://yourcompany.atlassian.net";
        String username = "your-email@company.com";
        String apiToken = "your-jira-api-token";
        String issueKey = "TEST-123";
        String outputFileName = "JiraTestCase_TEST123";
        
        TestCaseImporter.importSingleTestCaseFromJira(
            jiraUrl, username, apiToken, issueKey, outputFileName);
    }

    /**
     * Example: Import bulk test cases from Jira using JQL
     */
    private static void importBulkJiraTestCases() {
        String jiraUrl = "https://yourcompany.atlassian.net";
        String username = "your-email@company.com";
        String apiToken = "your-jira-api-token";
        String jqlQuery = "project = TEST AND type = Test AND status = 'To Do'";
        String baseFileName = "JiraBulkImport";
        boolean singleFile = false; // Set to true for single file
        
        TestCaseImporter.importBulkTestCasesFromJira(
            jiraUrl, username, apiToken, jqlQuery, baseFileName, singleFile);
    }

    /**
     * Example: Import test cases from Jira project
     */
    private static void importJiraProjectTestCases() {
        String jiraUrl = "https://yourcompany.atlassian.net";
        String username = "your-email@company.com";
        String apiToken = "your-jira-api-token";
        String projectKey = "TEST";
        String baseFileName = "JiraProjectImport";
        boolean singleFile = true; // All in one file
        
        TestCaseImporter.importTestCasesFromJiraProject(
            jiraUrl, username, apiToken, projectKey, baseFileName, singleFile);
    }

    /**
     * Example: Import single test case from Azure DevOps
     */
    private static void importSingleADOTestCase() {
        String organization = "your-organization";
        String project = "your-project";
        String personalAccessToken = "your-ado-pat";
        int workItemId = 12345;
        String outputFileName = "ADOTestCase_12345";
        
        TestCaseImporter.importSingleTestCaseFromADO(
            organization, project, personalAccessToken, workItemId, outputFileName);
    }

    /**
     * Example: Import bulk test cases from Azure DevOps using WIQL
     */
    private static void importBulkADOTestCases() {
        String organization = "your-organization";
        String project = "your-project";
        String personalAccessToken = "your-ado-pat";
        String wiqlQuery = "SELECT [System.Id] FROM WorkItems WHERE [System.WorkItemType] = 'Test Case'";
        String baseFileName = "ADOBulkImport";
        boolean singleFile = false;
        
        TestCaseImporter.importBulkTestCasesFromADO(
            organization, project, personalAccessToken, wiqlQuery, baseFileName, singleFile);
    }

    /**
     * Example: Import test cases from Azure DevOps test plan
     */
    private static void importADOTestPlanTestCases() {
        String organization = "your-organization";
        String project = "your-project";
        String personalAccessToken = "your-ado-pat";
        int testPlanId = 123;
        String baseFileName = "ADOTestPlanImport";
        boolean singleFile = true;
        
        TestCaseImporter.importTestCasesFromADOTestPlan(
            organization, project, personalAccessToken, testPlanId, baseFileName, singleFile);
    }
}

