package com.nammnet.runner;

import com.nammnet.utils.ExtentReportManager;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"com.nammnet.stepdefinitions"},
        plugin = {
                "pretty",
                "html:target/cucumber-reports",
                "json:target/cucumber-reports/Cucumber.json",
                "junit:target/cucumber-reports/Cucumber.xml"
        },
        monochrome = true,
        tags = "@SmokeTest or @RegressionTest"
)
public class TestRunner {

    @AfterClass
    public static void tearDown() {
        ExtentReportManager.flushReport();
    }
}

