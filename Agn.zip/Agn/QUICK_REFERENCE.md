# Quick Reference Card

## 🚀 Jira Import - Single Test Case

```java
import com.nammnet.integration.TestCaseImporter;

TestCaseImporter.importSingleTestCaseFromJira(
    "https://company.atlassian.net",  // URL
    "user@company.com",                // Username
    "api-token",                        // Token
    "TEST-123",                         // Issue Key
    "MyTestCase"                        // Output file
);
```

**Or use batch**: Edit `import-jira-bulk.bat` → Run

---

## 📦 Jira Import - Bulk Test Cases

```java
String jql = "project = TEST AND type = Test";
TestCaseImporter.importBulkTestCasesFromJira(
    "https://company.atlassian.net",
    "user@company.com",
    "api-token",
    jql,
    "BulkImport",
    false  // false = separate files, true = one file
);
```

**JQL Examples**:
- `project = TEST AND type = Test`
- `project = TEST AND priority = High`
- `project = TEST AND labels = automation`

---

## 🔷 ADO Import - Single Test Case

```java
TestCaseImporter.importSingleTestCaseFromADO(
    "organization",    // Org name
    "project",        // Project name
    "pat-token",      // PAT
    12345,            // Work Item ID
    "ADOTestCase"     // Output file
);
```

---

## 📦 ADO Import - Bulk Test Cases

```java
String wiql = "SELECT [System.Id] FROM WorkItems WHERE [System.WorkItemType] = 'Test Case'";
TestCaseImporter.importBulkTestCasesFromADO(
    "organization",
    "project",
    "pat-token",
    wiql,
    "ADOBulkImport",
    false
);
```

---

## 🤖 Auto-Healing Locators

### In Page Objects (Automatic)

```java
public class LoginPage extends BasePage {
    @FindBy(id = "username")
    private WebElement usernameField;
    
    public void enterUsername(String username) {
        sendKeys(usernameField, username, "Username", 
                createAttributesMap("username", "username", "input-field", "text"));
    }
}
```

### Manual Usage

```java
LocatorHealer healer = new LocatorHealer(driver);
Map<String, String> attrs = new HashMap<>();
attrs.put("id", "username");
attrs.put("name", "username");

WebElement el = healer.findElementWithHealing(
    By.id("username"), "Username Field", attrs);
```

---

## 📁 Output Location

All feature files saved to:
```
src/test/resources/features/imported/
```

---

## 🔑 Get API Tokens

**Jira**: https://id.atlassian.com/manage-profile/security/api-tokens
**ADO**: Azure DevOps → User Settings → Personal Access Tokens

---

## ⚡ Quick Commands

```batch
# Run interactive import menu
run-bulk-import.bat

# Run Jira example
run-jira-example.bat

# Run tests
mvn clean test

# Run specific tags
mvn test -Dcucumber.filter.tags="@SmokeTest"
```

---

## 📝 File Locations

- **Simple Example**: `src/main/java/com/nammnet/examples/SimpleJiraImport.java`
- **Complete Example**: `src/main/java/com/nammnet/examples/JiraImportExample.java`
- **Batch Scripts**: `import-jira-bulk.bat`, `import-ado-bulk.bat`
- **Config**: `src/test/resources/config/config.properties`

---

## 🎯 Common Use Cases

### Import all test cases from Jira project
```java
TestCaseImporter.importTestCasesFromJiraProject(
    url, user, token, "TEST", "ProjectImport", true);
```

### Import from ADO test plan
```java
TestCaseImporter.importTestCasesFromADOTestPlan(
    org, project, pat, 123, "TestPlan", true);
```

### Use auto-healing in page object
```java
// Just add metadata - healing is automatic!
click(button, "Login Button", createAttributesMap("id", "name", "class", "type"));
```

