# Simple Jira Import Example

## 🎯 Quick Start - 3 Steps

### Step 1: Get Your Jira API Token

1. Go to: https://id.atlassian.com/manage-profile/security/api-tokens
2. Click "Create API token"
3. Copy the token

### Step 2: Edit the Example File

Open: `src/main/java/com/nammnet/examples/SimpleJiraImport.java`

Edit these lines:
```java
String jiraUrl = "https://yourcompany.atlassian.net";      // Your Jira URL
String username = "your-email@company.com";                  // Your email
String apiToken = "ATATT3xFfGF0...";                          // Paste your token here
String issueKey = "TEST-123";                                // Your test case key
String outputFileName = "ImportedTestCase";                  // Output filename
```

### Step 3: Run It

**Option A: Double-click** `run-jira-example.bat`

**Option B: Command line**
```batch
mvn clean compile
mvn exec:java -Dexec.mainClass="com.nammnet.examples.SimpleJiraImport"
```

**Option C: Run from IDE**
- Right-click `SimpleJiraImport.java`
- Select "Run main method"

## ✅ Result

Feature file will be created at:
```
src/test/resources/features/imported/ImportedTestCase.feature
```

## 📄 Example Output

```gherkin
@JiraImport @High
Feature: Login with Valid Credentials
  Jira Key: TEST-123
  Test case description here

  Scenario: Login with Valid Credentials
    Given I am on the login page
    When I enter username "admin"
    And I enter password "password123"
    And I click on login button
    Then I should be logged in successfully
```

## 🔍 Find Your Test Case Key

1. Open your Jira project
2. Find a test case
3. Look at the issue key (e.g., `TEST-123`, `QA-456`)
4. Copy that key

## 🐛 Common Issues

### "Please edit this file"
- You haven't updated the credentials yet
- Edit the file and add your actual values

### "401 Unauthorized"
- Check your API token is correct
- Verify token hasn't expired
- Check username is correct

### "404 Not Found"
- Verify the issue key exists
- Check you have access to the project
- Verify it's a "Test" type issue

## 📚 More Examples

- **Complete example**: `JiraImportExample.java`
- **Bulk import**: `import-jira-bulk.bat`
- **Documentation**: `JIRA_IMPORT_EXAMPLE.md`

