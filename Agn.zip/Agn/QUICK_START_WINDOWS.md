# Quick Start Guide - Bulk Import on Windows

## 🚀 Fastest Way to Import Bulk Test Cases

### For Jira Import

1. **Open** `import-jira-bulk.bat` in Notepad
2. **Edit** these lines with your credentials:
   ```batch
   set JIRA_URL=https://yourcompany.atlassian.net
   set JIRA_USERNAME=your-email@company.com
   set JIRA_API_TOKEN=your-jira-api-token-here
   set JQL_QUERY=project = TEST AND type = Test
   set OUTPUT_FILE=JiraBulkImport
   set SINGLE_FILE=false
   ```
3. **Save** the file
4. **Double-click** `import-jira-bulk.bat`
5. **Wait** for import to complete
6. **Check** `src\test\resources\features\imported\` for feature files

### For Azure DevOps Import

1. **Open** `import-ado-bulk.bat` in Notepad
2. **Edit** these lines with your credentials:
   ```batch
   set ADO_ORGANIZATION=your-organization
   set ADO_PROJECT=your-project
   set ADO_PAT=your-personal-access-token-here
   set WIQL_QUERY=SELECT [System.Id] FROM WorkItems WHERE [System.WorkItemType] = 'Test Case'
   set OUTPUT_FILE=ADOBulkImport
   set SINGLE_FILE=false
   ```
3. **Save** the file
4. **Double-click** `import-ado-bulk.bat`
5. **Wait** for import to complete
6. **Check** `src\test\resources\features\imported\` for feature files

## 📋 Prerequisites

- ✅ Java 1.8+ installed (`java -version`)
- ✅ Maven 3.6+ installed (`mvn -version`)
- ✅ Jira API Token (for Jira) or ADO PAT (for Azure DevOps)

## 🔑 Getting API Tokens

### Jira API Token
1. Go to: https://id.atlassian.com/manage-profile/security/api-tokens
2. Click "Create API token"
3. Copy the token

### Azure DevOps PAT
1. Go to Azure DevOps → User Settings → Personal Access Tokens
2. Create new token with "Work Items (Read)" permission
3. Copy the token

## 📝 JQL Query Examples

### All test cases from a project
```
project = TEST AND type = Test
```

### Test cases with specific status
```
project = TEST AND type = Test AND status = 'To Do'
```

### Test cases with high priority
```
project = TEST AND type = Test AND priority = High
```

### Test cases with automation label
```
project = TEST AND type = Test AND labels = automation
```

## 📝 WIQL Query Examples

### All test cases
```
SELECT [System.Id] FROM WorkItems WHERE [System.WorkItemType] = 'Test Case'
```

### Test cases from specific area
```
SELECT [System.Id] FROM WorkItems 
WHERE [System.WorkItemType] = 'Test Case' 
AND [System.AreaPath] = 'Project\\Area'
```

### Active test cases
```
SELECT [System.Id] FROM WorkItems 
WHERE [System.WorkItemType] = 'Test Case' 
AND [System.State] = 'Active'
```

## 🎯 Output Options

### Separate Files (`SINGLE_FILE=false`)
Creates individual feature files:
- `JiraBulkImport_1_TEST-123.feature`
- `JiraBulkImport_2_TEST-124.feature`
- etc.

### Single File (`SINGLE_FILE=true`)
Creates one feature file with all scenarios:
- `JiraBulkImport.feature`

## 🔧 Alternative: Interactive Menu

If you prefer an interactive menu:

1. **Double-click** `run-bulk-import.bat`
2. Follow the prompts
3. Select your import option
4. Enter credentials when asked

## 📁 Output Location

All feature files are saved to:
```
src\test\resources\features\imported\
```

## ✅ After Import

1. Review generated feature files
2. Move to `src\test\resources\features\` if needed
3. Run tests: `mvn test`

## 🐛 Troubleshooting

### "Maven not found"
- Install Maven: https://maven.apache.org/download.cgi
- Add to PATH: `C:\Program Files\Apache\maven\bin`

### "Java not found"
- Install Java: https://www.oracle.com/java/technologies/downloads/
- Add to PATH: `C:\Program Files\Java\jdk1.8.0_xxx\bin`

### "401 Unauthorized"
- Check your API token/PAT is correct
- Verify token hasn't expired
- Check username/organization name

### "404 Not Found"
- Verify Jira URL is correct
- Check project key exists
- For ADO: Verify organization and project names

## 📚 More Information

- Detailed guide: [WINDOWS_IMPORT_GUIDE.md](WINDOWS_IMPORT_GUIDE.md)
- Import documentation: [IMPORT_GUIDE.md](IMPORT_GUIDE.md)
- Feature summary: [FEATURES_SUMMARY.md](FEATURES_SUMMARY.md)

