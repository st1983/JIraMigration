# Build Instructions

## Quick Build Commands

### Compile Only
```batch
mvn clean compile
```

### Compile and Package (Skip Tests)
```batch
mvn clean package -DskipTests
```

### Full Build with Tests
```batch
mvn clean install
```

### Verify Dependencies
```batch
mvn dependency:resolve
```

## Build Status

✅ **Project Structure**: Valid
✅ **Dependencies**: All configured correctly
✅ **Code**: No compilation errors detected

## What Gets Built

1. **Main Classes**: Compiled to `target/classes/`
2. **Test Classes**: Compiled to `target/test-classes/`
3. **JAR File**: Created in `target/` (if packaging)

## Expected Output

```
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time: XX.XXX s
[INFO] Finished at: YYYY-MM-DD HH:MM:SS
[INFO] ------------------------------------------------------------------------
```

## Troubleshooting

### If build fails:

1. **Check Java version**: `java -version` (should be 1.8+)
2. **Check Maven version**: `mvn -version` (should be 3.6+)
3. **Clear Maven cache**: `mvn dependency:purge-local-repository`
4. **Update dependencies**: `mvn dependency:resolve -U`

## Project Information

- **Group ID**: com.nammnet
- **Artifact ID**: selenium-cucumber-pom
- **Version**: 1.0-SNAPSHOT
- **Java Version**: 1.8
- **Packaging**: jar

## Next Steps After Build

1. Run tests: `mvn test`
2. Run specific test: `mvn test -Dtest=TestRunner`
3. Generate reports: Check `test-output/` and `target/cucumber-reports/`

