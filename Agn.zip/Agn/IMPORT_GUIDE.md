# Test Case Import Guide

This guide explains how to import test cases from Jira and Azure DevOps and convert them to Cucumber feature files.

## Table of Contents
1. [Jira Integration](#jira-integration)
2. [Azure DevOps Integration](#azure-devops-integration)
3. [Auto-Healing Locators](#auto-healing-locators)
4. [Usage Examples](#usage-examples)

## Jira Integration

### Prerequisites
1. Jira URL (e.g., https://yourcompany.atlassian.net)
2. Jira username/email
3. Jira API Token (Generate from: Account Settings > Security > API tokens)

### Import Single Test Case

```java
import com.nammnet.integration.TestCaseImporter;

// Import single test case
TestCaseImporter.importSingleTestCaseFromJira(
    "https://yourcompany.atlassian.net",  // Jira URL
    "your-email@company.com",              // Username
    "your-api-token",                      // API Token
    "TEST-123",                            // Issue Key
    "JiraTestCase_TEST123"                 // Output filename
);
```

### Import Bulk Test Cases (JQL Query)

```java
// Import multiple test cases using JQL
String jqlQuery = "project = TEST AND type = Test AND status = 'To Do'";
TestCaseImporter.importBulkTestCasesFromJira(
    "https://yourcompany.atlassian.net",
    "your-email@company.com",
    "your-api-token",
    jqlQuery,
    "JiraBulkImport",                      // Base filename
    false                                  // false = separate files, true = single file
);
```

### Import by Project

```java
// Import all test cases from a project
TestCaseImporter.importTestCasesFromJiraProject(
    "https://yourcompany.atlassian.net",
    "your-email@company.com",
    "your-api-token",
    "TEST",                                // Project key
    "JiraProjectImport",
    true                                   // Single file with all scenarios
);
```

## Azure DevOps Integration

### Prerequisites
1. Organization name
2. Project name
3. Personal Access Token (PAT) with Work Items Read permission

### Import Single Test Case

```java
import com.nammnet.integration.TestCaseImporter;

// Import single test case
TestCaseImporter.importSingleTestCaseFromADO(
    "your-organization",                  // Organization
    "your-project",                       // Project
    "your-pat-token",                     // Personal Access Token
    12345,                                // Work Item ID
    "ADOTestCase_12345"                   // Output filename
);
```

### Import Bulk Test Cases (WIQL Query)

```java
// Import multiple test cases using WIQL
String wiqlQuery = "SELECT [System.Id] FROM WorkItems WHERE [System.WorkItemType] = 'Test Case'";
TestCaseImporter.importBulkTestCasesFromADO(
    "your-organization",
    "your-project",
    "your-pat-token",
    wiqlQuery,
    "ADOBulkImport",
    false                                  // false = separate files, true = single file
);
```

### Import by Test Plan

```java
// Import test cases from a test plan
TestCaseImporter.importTestCasesFromADOTestPlan(
    "your-organization",
    "your-project",
    "your-pat-token",
    123,                                   // Test Plan ID
    "ADOTestPlanImport",
    true                                   // Single file with all scenarios
);
```

## Auto-Healing Locators

The framework includes an auto-healing locator system that automatically finds alternative locators when the original fails.

### Features
- **Similarity Matching**: Uses Levenshtein distance algorithm
- **Multiple Strategies**: Tries ID, name, class, XPath, partial text, etc.
- **No Database Required**: Pure Java implementation
- **No Docker Required**: Runs in-process

### Usage in Page Objects

```java
public class LoginPage extends BasePage {
    @FindBy(id = "username")
    private WebElement usernameField;

    public void enterUsername(String username) {
        // Auto-healing is built into BasePage methods
        sendKeys(usernameField, username, "Username", 
                createAttributesMap("username", "username", "input-field", "text"));
    }
}
```

### Manual Usage

```java
import com.nammnet.healing.LocatorHealer;

LocatorHealer healer = new LocatorHealer(driver);

// Find element with healing
Map<String, String> attributes = new HashMap<>();
attributes.put("id", "username");
attributes.put("name", "username");

WebElement element = healer.findElementWithHealing(
    By.id("username"), 
    "Username Field", 
    attributes
);

// Wait for element with healing
WebElement element = healer.waitForElementWithHealing(
    By.id("username"),
    "Username Field",
    attributes,
    10  // timeout in seconds
);
```

### How It Works

1. **Original Locator Fails**: When a locator fails, the healer is triggered
2. **Generate Alternatives**: Creates multiple alternative locator strategies
3. **Similarity Matching**: Uses string similarity to find matching elements
4. **Validation**: Verifies found elements match expected criteria
5. **Return Best Match**: Returns the best matching element

### Locator Strategies Used

1. Partial text match
2. XPath with text contains
3. Attribute-based locators (exact and partial)
4. Similarity-based element search
5. Common patterns (ID, name, class)

## Output

All imported feature files are saved to:
```
src/test/resources/features/imported/
```

### File Naming Convention

- **Single Import**: `{filename}.feature`
- **Bulk Import (separate)**: `{baseFileName}_{index}_{key}.feature`
- **Bulk Import (single file)**: `{baseFileName}.feature`

### Feature File Format

```gherkin
@JiraImport @High
Feature: Test Case Title
  Jira Key: TEST-123
  Test case description

  Scenario: Test Case Title
    Given I am on the application
    When I perform the test action
    Then I should see the expected result
```

## Best Practices

1. **API Tokens**: Store credentials securely (use environment variables or config files)
2. **Error Handling**: Always check return values and handle null cases
3. **Batch Size**: For large imports, consider importing in batches
4. **Review**: Always review generated feature files before running tests
5. **Customization**: Modify converters to match your specific test case format

## Troubleshooting

### Jira Issues
- **401 Unauthorized**: Check API token and username
- **404 Not Found**: Verify Jira URL and issue key
- **403 Forbidden**: Check project permissions

### Azure DevOps Issues
- **401 Unauthorized**: Verify PAT has correct permissions
- **404 Not Found**: Check organization and project names
- **Invalid WIQL**: Verify WIQL query syntax

### Auto-Healing Issues
- **No Element Found**: Increase similarity threshold or add more attributes
- **Wrong Element**: Refine element text or attributes for better matching
- **Performance**: Limit similarity search scope for better performance

