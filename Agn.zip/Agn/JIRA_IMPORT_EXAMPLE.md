# Jira Import Example - Complete Guide

This guide shows you exactly how to import a test case from Jira and convert it to a Cucumber feature file.

## 📋 Example Overview

### What This Example Does

1. **Connects to Jira** using your credentials
2. **Fetches a test case** by issue key (e.g., TEST-123)
3. **Converts it automatically** to a Cucumber feature file
4. **Saves it** to `src/test/resources/features/imported/`

## 🚀 Quick Start

### Step 1: Get Your Jira Credentials

1. **Jira URL**: Your Jira instance URL
   - Example: `https://yourcompany.atlassian.net`

2. **Username**: Your Jira email/username
   - Example: `your-email@company.com`

3. **API Token**: Create one at https://id.atlassian.com/manage-profile/security/api-tokens
   - Click "Create API token"
   - Copy the token (you'll only see it once!)

### Step 2: Find a Test Case

1. Go to your Jira project
2. Find a test case (issue type = Test)
3. Note the issue key (e.g., `TEST-123`)

### Step 3: Run the Import

#### Option A: Using Batch Script (Windows)

1. Open `run-jira-example.bat` in Notepad
2. Edit the example code in `JiraImportExample.java` with your credentials
3. Double-click `run-jira-example.bat`

#### Option B: Using Maven Command

```batch
mvn clean compile
mvn exec:java -Dexec.mainClass="com.nammnet.examples.JiraImportExample"
```

#### Option C: Edit and Run Directly

1. Open `src/main/java/com/nammnet/examples/JiraImportExample.java`
2. Edit these lines:
   ```java
   String jiraUrl = "https://yourcompany.atlassian.net";
   String username = "your-email@company.com";
   String apiToken = "your-jira-api-token";
   String issueKey = "TEST-123";
   ```
3. Run the main method

## 📝 Complete Code Example

```java
package com.nammnet.examples;

import com.nammnet.integration.TestCaseImporter;

public class JiraImportExample {
    public static void main(String[] args) {
        // Your Jira credentials
        String jiraUrl = "https://yourcompany.atlassian.net";
        String username = "your-email@company.com";
        String apiToken = "your-jira-api-token";
        
        // Test case to import
        String issueKey = "TEST-123";
        String outputFileName = "MyImportedTestCase";
        
        // Import the test case
        TestCaseImporter.importSingleTestCaseFromJira(
            jiraUrl,
            username,
            apiToken,
            issueKey,
            outputFileName
        );
        
        System.out.println("Feature file created at:");
        System.out.println("src/test/resources/features/imported/" + 
                          outputFileName + ".feature");
    }
}
```

## 📄 Example Output

### Input: Jira Test Case

**Jira Issue**: TEST-123
- **Summary**: Login with Valid Credentials
- **Description**: Test case for validating user login functionality
- **Priority**: High
- **Labels**: automation, smoke-test
- **Test Steps**:
  1. Navigate to login page
  2. Enter username "admin"
  3. Enter password "password123"
  4. Click login button
  5. Verify successful login
  6. Verify welcome message displayed

### Output: Cucumber Feature File

**File**: `src/test/resources/features/imported/MyImportedTestCase.feature`

```gherkin
@JiraImport @High
Feature: Login with Valid Credentials
  Jira Key: TEST-123
  Test case for validating user login functionality

  Scenario: Login with Valid Credentials
    Given I am on the login page
    When I enter username "admin"
    And I enter password "password123"
    And I click on login button
    Then I should be logged in successfully
    And I should see welcome message
```

## 🔄 Bulk Import Example

### Import Multiple Test Cases

```java
// JQL Query to find test cases
String jqlQuery = "project = TEST AND type = Test AND status = 'To Do'";

// Import all matching test cases
TestCaseImporter.importBulkTestCasesFromJira(
    jiraUrl,
    username,
    apiToken,
    jqlQuery,
    "BulkImport",      // Base filename
    false              // false = separate files, true = one file
);
```

### Output for Bulk Import

If `singleFile = false`:
- `BulkImport_1_TEST-123.feature`
- `BulkImport_2_TEST-124.feature`
- `BulkImport_3_TEST-125.feature`

If `singleFile = true`:
- `BulkImport.feature` (contains all scenarios)

## 📋 JQL Query Examples

### All test cases from a project
```jql
project = TEST AND type = Test
```

### Test cases with specific status
```jql
project = TEST AND type = Test AND status = 'To Do'
```

### Test cases with high priority
```jql
project = TEST AND type = Test AND priority = High
```

### Test cases with automation label
```jql
project = TEST AND type = Test AND labels = automation
```

### Test cases created in last 30 days
```jql
project = TEST AND type = Test AND created >= -30d
```

## 🎯 Step-by-Step Walkthrough

### 1. Prepare Your Environment

```batch
# Verify Java is installed
java -version

# Verify Maven is installed
mvn -version
```

### 2. Get Jira API Token

1. Go to: https://id.atlassian.com/manage-profile/security/api-tokens
2. Click "Create API token"
3. Give it a name (e.g., "Test Automation")
4. Copy the token immediately (you won't see it again!)

### 3. Find Test Case Key

1. Open your Jira project
2. Find a test case
3. Copy the issue key (e.g., `TEST-123`)

### 4. Edit the Example

Open `src/main/java/com/nammnet/examples/JiraImportExample.java`:

```java
// Replace these values
String jiraUrl = "https://yourcompany.atlassian.net";  // Your Jira URL
String username = "your-email@company.com";              // Your email
String apiToken = "ATATT3xFfGF0...";                    // Your API token
String issueKey = "TEST-123";                           // Test case key
```

### 5. Run the Import

```batch
# Compile
mvn clean compile

# Run
mvn exec:java -Dexec.mainClass="com.nammnet.examples.JiraImportExample"
```

### 6. Check the Output

Open: `src/test/resources/features/imported/MyImportedTestCase.feature`

## ✅ Verification

After import, verify:

1. ✅ Feature file exists in `src/test/resources/features/imported/`
2. ✅ File contains correct scenario steps
3. ✅ Tags are included (@JiraImport, @Priority)
4. ✅ Jira key is in the feature description

## 🔧 Troubleshooting

### Error: 401 Unauthorized
- **Cause**: Invalid credentials
- **Solution**: 
  - Verify username is correct
  - Verify API token is valid (not expired)
  - Check token has correct permissions

### Error: 404 Not Found
- **Cause**: Issue key doesn't exist
- **Solution**: 
  - Verify issue key is correct
  - Check you have access to the project
  - Verify the issue is a "Test" type

### Error: Connection Timeout
- **Cause**: Network/firewall issue
- **Solution**: 
  - Check internet connection
  - Verify Jira URL is correct
  - Check firewall settings

### No Feature File Created
- **Cause**: Import failed silently
- **Solution**: 
  - Check console for error messages
  - Verify output directory exists
  - Check file permissions

## 📚 Next Steps

After importing:

1. **Review the feature file** - Make sure steps are correct
2. **Update step definitions** - If needed, add missing step definitions
3. **Run the test** - Execute with `mvn test`
4. **Customize** - Modify the converter to match your test case format

## 💡 Tips

1. **Start with one test case** - Test the import process first
2. **Use specific JQL queries** - Narrow down what you import
3. **Review generated files** - Always check the output
4. **Use tags** - Generated files include tags for filtering
5. **Backup existing files** - Imported files may overwrite existing ones

## 📖 Related Documentation

- [WINDOWS_IMPORT_GUIDE.md](WINDOWS_IMPORT_GUIDE.md) - Detailed Windows guide
- [IMPORT_GUIDE.md](IMPORT_GUIDE.md) - Complete import documentation
- [QUICK_START_WINDOWS.md](QUICK_START_WINDOWS.md) - Quick start guide

## 🎉 Example Files Included

1. **JiraImportExample.java** - Complete working example
2. **EXAMPLE_JiraTestCase.feature** - Sample output for single import
3. **EXAMPLE_JiraBulkImport.feature** - Sample output for bulk import
4. **run-jira-example.bat** - Windows batch script to run example

## 🔐 Security Note

⚠️ **Never commit credentials to version control!**

- Use environment variables for credentials
- Use `.gitignore` to exclude config files
- Store API tokens securely
- Rotate tokens regularly

