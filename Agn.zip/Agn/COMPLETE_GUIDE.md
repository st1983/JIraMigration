# Complete Guide: Jira/ADO Import & Auto-Healing Locators

This comprehensive guide covers all features: importing test cases from Jira/ADO and auto-healing locators.

## 📋 Table of Contents

1. [Jira Test Case Import](#jira-test-case-import)
2. [Azure DevOps Test Case Import](#azure-devops-test-case-import)
3. [Auto-Healing Locators](#auto-healing-locators)
4. [Production-Ready Code](#production-ready-code)

---

## 🔵 Jira Test Case Import

### Prerequisites

1. **Jira URL**: Your Jira instance (e.g., `https://yourcompany.atlassian.net`)
2. **Username**: Your Jira email
3. **API Token**: Create at https://id.atlassian.com/manage-profile/security/api-tokens

### Method 1: Import Single Test Case

#### Option A: Using Simple Example (Easiest)

1. **Open**: `src/main/java/com/nammnet/examples/SimpleJiraImport.java`
2. **Edit** these lines:
   ```java
   String jiraUrl = "https://yourcompany.atlassian.net";
   String username = "your-email@company.com";
   String apiToken = "your-jira-api-token";
   String issueKey = "TEST-123";  // Your test case key
   String outputFileName = "ImportedTestCase";
   ```
3. **Run**: Double-click `run-jira-example.bat` or run from IDE

#### Option B: Using Batch Script

1. **Open**: `import-jira-bulk.bat`
2. **Edit** configuration section:
   ```batch
   set JIRA_URL=https://yourcompany.atlassian.net
   set JIRA_USERNAME=your-email@company.com
   set JIRA_API_TOKEN=your-jira-api-token-here
   set JQL_QUERY=project = TEST AND type = Test
   set OUTPUT_FILE=JiraBulkImport
   set SINGLE_FILE=false
   ```
3. **Double-click** the `.bat` file

#### Option C: Using Code Directly

```java
import com.nammnet.integration.TestCaseImporter;

// Import single test case
TestCaseImporter.importSingleTestCaseFromJira(
    "https://yourcompany.atlassian.net",  // Jira URL
    "your-email@company.com",              // Username
    "your-api-token",                       // API Token
    "TEST-123",                             // Issue Key
    "MyImportedTestCase"                    // Output filename
);
```

**Output**: `src/test/resources/features/imported/MyImportedTestCase.feature`

### Method 2: Import Bulk Test Cases

#### Using JQL Query

```java
import com.nammnet.integration.TestCaseImporter;

// Import bulk test cases
String jqlQuery = "project = TEST AND type = Test AND status = 'To Do'";
TestCaseImporter.importBulkTestCasesFromJira(
    "https://yourcompany.atlassian.net",
    "your-email@company.com",
    "your-api-token",
    jqlQuery,
    "BulkImport",      // Base filename
    false              // false = separate files, true = one file
);
```

#### Using Batch Script

1. Edit `import-jira-bulk.bat`
2. Set `SINGLE_FILE=false` for separate files
3. Set `SINGLE_FILE=true` for one consolidated file
4. Run the script

### Method 3: Import by Project

```java
// Import all test cases from a project
TestCaseImporter.importTestCasesFromJiraProject(
    "https://yourcompany.atlassian.net",
    "your-email@company.com",
    "your-api-token",
    "TEST",            // Project key
    "ProjectImport",
    true               // Single file with all scenarios
);
```

### JQL Query Examples

```jql
# All test cases from a project
project = TEST AND type = Test

# Test cases with specific status
project = TEST AND type = Test AND status = 'To Do'

# High priority test cases
project = TEST AND type = Test AND priority = High

# Test cases with automation label
project = TEST AND type = Test AND labels = automation

# Test cases created in last 30 days
project = TEST AND type = Test AND created >= -30d

# Test cases assigned to specific user
project = TEST AND type = Test AND assignee = currentUser()
```

### Output Examples

**Single File** (`SINGLE_FILE=true`):
- `BulkImport.feature` (contains all scenarios)

**Separate Files** (`SINGLE_FILE=false`):
- `BulkImport_1_TEST-123.feature`
- `BulkImport_2_TEST-124.feature`
- `BulkImport_3_TEST-125.feature`

---

## 🔷 Azure DevOps Test Case Import

### Prerequisites

1. **Organization**: Your Azure DevOps organization name
2. **Project**: Your project name
3. **Personal Access Token (PAT)**: Create with "Work Items (Read)" permission

### Method 1: Import Single Test Case

#### Using Code

```java
import com.nammnet.integration.TestCaseImporter;

// Import single test case
TestCaseImporter.importSingleTestCaseFromADO(
    "your-organization",    // Organization
    "your-project",         // Project
    "your-pat-token",       // Personal Access Token
    12345,                  // Work Item ID
    "ADOTestCase"           // Output filename
);
```

#### Using Batch Script

1. **Open**: `import-ado-bulk.bat`
2. **Edit** configuration:
   ```batch
   set ADO_ORGANIZATION=your-organization
   set ADO_PROJECT=your-project
   set ADO_PAT=your-personal-access-token-here
   set WIQL_QUERY=SELECT [System.Id] FROM WorkItems WHERE [System.WorkItemType] = 'Test Case'
   set OUTPUT_FILE=ADOBulkImport
   set SINGLE_FILE=false
   ```
3. **Run** the script

### Method 2: Import Bulk Test Cases

#### Using WIQL Query

```java
// Import bulk test cases
String wiqlQuery = "SELECT [System.Id] FROM WorkItems WHERE [System.WorkItemType] = 'Test Case'";
TestCaseImporter.importBulkTestCasesFromADO(
    "your-organization",
    "your-project",
    "your-pat-token",
    wiqlQuery,
    "ADOBulkImport",
    false  // false = separate files, true = one file
);
```

### Method 3: Import by Test Plan

```java
// Import test cases from a test plan
TestCaseImporter.importTestCasesFromADOTestPlan(
    "your-organization",
    "your-project",
    "your-pat-token",
    123,                   // Test Plan ID
    "TestPlanImport",
    true                   // Single file
);
```

### WIQL Query Examples

```sql
# All test cases
SELECT [System.Id] FROM WorkItems 
WHERE [System.WorkItemType] = 'Test Case'

# Active test cases
SELECT [System.Id] FROM WorkItems 
WHERE [System.WorkItemType] = 'Test Case' 
AND [System.State] = 'Active'

# Test cases from specific area
SELECT [System.Id] FROM WorkItems 
WHERE [System.WorkItemType] = 'Test Case' 
AND [System.AreaPath] = 'Project\\Area'

# Test cases with specific priority
SELECT [System.Id] FROM WorkItems 
WHERE [System.WorkItemType] = 'Test Case' 
AND [Microsoft.VSTS.Common.Priority] = '1'

# Test cases assigned to user
SELECT [System.Id] FROM WorkItems 
WHERE [System.WorkItemType] = 'Test Case' 
AND [System.AssignedTo] = 'user@company.com'
```

---

## 🤖 Auto-Healing Locators

### Overview

The framework includes an intelligent auto-healing system that automatically finds alternative locators when the original fails. **Pure Java implementation - no database or Docker required.**

### How It Works

1. **Original locator fails** → Healing system activates
2. **Generates alternative strategies** → Multiple locator approaches
3. **Similarity matching** → Uses Levenshtein distance algorithm
4. **Validates elements** → Ensures found element matches criteria
5. **Returns best match** → Element found and ready to use

### Locator Strategies

1. **Partial text match** - Finds elements by partial text
2. **XPath with text contains** - Flexible XPath matching
3. **Attribute-based** - ID, name, class (exact and partial)
4. **Similarity-based search** - String similarity matching
5. **Common patterns** - Standard Selenium locators

### Usage in Page Objects

#### Basic Usage (Auto-healing built-in)

```java
public class LoginPage extends BasePage {
    @FindBy(id = "username")
    private WebElement usernameField;

    public void enterUsername(String username) {
        // Auto-healing is automatic when element metadata is provided
        sendKeys(usernameField, username, "Username", 
                createAttributesMap("username", "username", "input-field", "text"));
    }
}
```

#### Advanced Usage with Metadata

```java
public void clickLoginButton() {
    Map<String, String> attributes = createAttributesMap(
        "loginButton",      // id
        "loginBtn",         // name
        "btn-primary",      // class
        "button"            // type
    );
    
    click(loginButton, "Login Button", attributes);
}
```

### Manual Usage

```java
import com.nammnet.healing.LocatorHealer;
import org.openqa.selenium.By;
import java.util.HashMap;
import java.util.Map;

// Create healer instance
LocatorHealer healer = new LocatorHealer(driver);

// Prepare element metadata
Map<String, String> attributes = new HashMap<>();
attributes.put("id", "username");
attributes.put("name", "username");
attributes.put("class", "input-field");

// Find element with healing
WebElement element = healer.findElementWithHealing(
    By.id("username"),        // Original locator
    "Username Field",          // Element text/description
    attributes                 // Element attributes
);

// Wait for element with healing
WebElement element = healer.waitForElementWithHealing(
    By.id("username"),
    "Username Field",
    attributes,
    10  // timeout in seconds
);
```

### Finding Similar Elements

```java
// Find all elements similar to search text
List<WebElement> similarElements = healer.findSimilarElements(
    "Login Button",    // Search text
    0.7                // Minimum similarity (0.0 to 1.0)
);
```

### Configuration

The similarity threshold can be adjusted in `LocatorHealer.java`:

```java
private final double similarityThreshold = 0.7;  // Adjust as needed
```

**Threshold values**:
- `0.9` - Very strict (almost exact match)
- `0.7` - Balanced (default)
- `0.5` - More lenient (finds more matches)

### Example: Complete Page Object with Auto-Healing

```java
package com.nammnet.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import java.util.Map;

public class LoginPage extends BasePage {
    
    @FindBy(id = "username")
    private WebElement usernameField;
    
    @FindBy(id = "password")
    private WebElement passwordField;
    
    @FindBy(id = "loginButton")
    private WebElement loginButton;
    
    public void enterUsername(String username) {
        Map<String, String> attrs = createAttributesMap(
            "username", "username", "form-control", "text");
        sendKeys(usernameField, username, "Username", attrs);
    }
    
    public void enterPassword(String password) {
        Map<String, String> attrs = createAttributesMap(
            "password", "password", "form-control", "password");
        sendKeys(passwordField, password, "Password", attrs);
    }
    
    public void clickLogin() {
        Map<String, String> attrs = createAttributesMap(
            "loginButton", "loginBtn", "btn-primary", "button");
        click(loginButton, "Login Button", attrs);
    }
    
    public void login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLogin();
    }
}
```

---

## 🏗️ Production-Ready Code

### Code Quality Features

✅ **Clean Architecture**
- Separation of concerns
- Single Responsibility Principle
- Dependency Injection ready

✅ **Error Handling**
- Comprehensive exception handling
- Meaningful error messages
- Proper logging

✅ **Thread Safety**
- ThreadLocal for WebDriver
- Safe for parallel execution

✅ **Resource Management**
- Proper cleanup of HTTP clients
- WebDriver quit on completion
- File stream handling

✅ **Configuration Management**
- Externalized configuration
- Environment variable support
- Default values

✅ **Logging**
- SLF4J throughout
- Appropriate log levels
- Structured logging

### Best Practices Implemented

1. **Page Object Model** - Clean separation of page logic
2. **Base Classes** - Reusable common functionality
3. **Utility Classes** - Helper methods organized
4. **Constants** - Magic numbers/strings eliminated
5. **Documentation** - JavaDoc comments
6. **Naming Conventions** - Clear, descriptive names

### Project Structure

```
src/main/java/com/nammnet/
├── pages/              # Page Object Model
│   ├── BasePage.java  # Base class with auto-healing
│   ├── LoginPage.java
│   └── HomePage.java
├── utils/              # Utility classes
│   ├── DriverManager.java
│   ├── ExtentReportManager.java
│   ├── ConfigReader.java
│   └── Assertions.java
├── integration/        # Test case import
│   ├── jira/
│   ├── ado/
│   └── TestCaseImporter.java
└── healing/            # Auto-healing
    └── LocatorHealer.java
```

### Configuration Files

**config.properties**:
```properties
url=https://argon.nammnet.com/netscaler
browser=chrome
implicit.wait=10
explicit.wait=15
page.load.timeout=30
```

**integration.properties** (optional):
```properties
jira.url=https://yourcompany.atlassian.net
jira.username=your-email@company.com
jira.api.token=your-token
ado.organization=your-org
ado.project=your-project
ado.personal.access.token=your-pat
```

### Running Tests

```batch
# Run all tests
mvn clean test

# Run specific tags
mvn test -Dcucumber.filter.tags="@SmokeTest"

# Run with specific browser
# Edit config.properties: browser=firefox
mvn test
```

### Reports

**ExtentReports**: `test-output/ExtentReport_[timestamp].html`
**Cucumber Reports**: `target/cucumber-reports/index.html`

---

## 📚 Quick Reference

### Import Single Test Case

**Jira**:
```java
TestCaseImporter.importSingleTestCaseFromJira(url, user, token, "TEST-123", "output");
```

**ADO**:
```java
TestCaseImporter.importSingleTestCaseFromADO(org, project, pat, 12345, "output");
```

### Import Bulk Test Cases

**Jira**:
```java
TestCaseImporter.importBulkTestCasesFromJira(url, user, token, jql, "base", false);
```

**ADO**:
```java
TestCaseImporter.importBulkTestCasesFromADO(org, project, pat, wiql, "base", false);
```

### Use Auto-Healing

```java
// In page objects - automatic
sendKeys(element, text, "Description", createAttributesMap(id, name, class, type));

// Manual usage
LocatorHealer healer = new LocatorHealer(driver);
WebElement el = healer.findElementWithHealing(By.id("x"), "Text", attributes);
```

---

## 🐛 Troubleshooting

### Import Issues

**401 Unauthorized**:
- Check API token/PAT is valid
- Verify username/organization
- Check token hasn't expired

**404 Not Found**:
- Verify issue key/work item ID exists
- Check project access permissions
- Verify query syntax

### Auto-Healing Issues

**No element found**:
- Increase similarity threshold
- Add more attributes to metadata
- Check element is actually on page

**Wrong element found**:
- Decrease similarity threshold
- Refine element text/description
- Add more specific attributes

---

## 📖 Additional Resources

- **Quick Start**: [QUICK_START_WINDOWS.md](QUICK_START_WINDOWS.md)
- **Windows Guide**: [WINDOWS_IMPORT_GUIDE.md](WINDOWS_IMPORT_GUIDE.md)
- **Jira Example**: [JIRA_IMPORT_EXAMPLE.md](JIRA_IMPORT_EXAMPLE.md)
- **Features Summary**: [FEATURES_SUMMARY.md](FEATURES_SUMMARY.md)

---

## ✅ Summary

This framework provides:

1. ✅ **Jira Integration** - Single and bulk import
2. ✅ **ADO Integration** - Single and bulk import  
3. ✅ **Auto-Healing Locators** - Pure Java, no DB/Docker
4. ✅ **Production-Ready Code** - Clean, maintainable, well-documented

All features are ready to use with comprehensive examples and documentation!

