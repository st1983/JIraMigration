# Selenium Cucumber Java Page Object Model Project

This is a comprehensive Selenium automation framework using Cucumber BDD, Page Object Model pattern, and ExtentReports for reporting.

## Project Structure

```
selenium-cucumber-pom/
├── src/
│   ├── main/
│   │   └── java/
│   │       └── com/
│   │           └── nammnet/
│   │               ├── pages/
│   │               │   ├── BasePage.java
│   │               │   ├── LoginPage.java
│   │               │   └── HomePage.java
│   │               └── utils/
│   │                   ├── DriverManager.java
│   │                   ├── ExtentReportManager.java
│   │                   └── ConfigReader.java
│   └── test/
│       ├── java/
│       │   └── com/
│       │       └── nammnet/
│       │           ├── runner/
│       │           │   └── TestRunner.java
│       │           └── stepdefinitions/
│       │               ├── Hooks.java
│       │               ├── LoginStepDefinitions.java
│       │               └── HomePageStepDefinitions.java
│       └── resources/
│           ├── features/
│           │   ├── Login.feature
│           │   └── HomePage.feature
│           └── config/
│               └── config.properties
├── pom.xml
└── README.md
```

## Prerequisites

- Java 1.8 or higher
- Maven 3.6 or higher
- Chrome browser (latest version)
- Internet connection (for WebDriverManager to download drivers)

## Technologies Used

- **Selenium WebDriver**: 4.15.0 (Latest)
- **Cucumber**: 7.14.0
- **JUnit**: 4.13.2
- **ExtentReports**: 5.1.1
- **WebDriverManager**: 5.6.2 (Auto-updates ChromeDriver)
- **Java**: 1.8
- **Apache HttpClient**: 4.5.14 (For API integration)
- **Gson**: 2.10.1 (JSON parsing)
- **Java String Similarity**: 2.0.0 (For auto-healing locators)
- **Apache Commons**: 3.12.0 (Utilities)

## Features

1. **Page Object Model (POM)**: Clean separation of page logic and test code
2. **Cucumber BDD**: Behavior-driven development with Gherkin syntax
3. **ExtentReports**: Beautiful HTML reports with screenshots
4. **Auto ChromeDriver Management**: WebDriverManager automatically downloads and manages ChromeDriver
5. **Multiple Browser Support**: Chrome, Firefox, Edge
6. **Assertions**: JUnit assertions for test validation
7. **Screenshot on Failure**: Automatic screenshots for failed tests
8. **Thread-Safe**: ThreadLocal for parallel execution support
9. **Jira Integration**: Import test cases from Jira (single or bulk) and convert to feature files
10. **Azure DevOps Integration**: Import test cases from ADO (single or bulk) and convert to feature files
11. **Auto-Healing Locators**: Automatically find alternative locators when original fails (pure Java, no DB/Docker)
12. **Production-Ready**: Clean code architecture with proper error handling and logging

## Setup Instructions

1. **Clone or download the project**

2. **Install Maven** (if not already installed)
   - Download from https://maven.apache.org/download.cgi
   - Add to PATH environment variable

3. **Verify Java Installation**
   ```bash
   java -version
   ```
   Should show Java 1.8 or higher

4. **Update Configuration**
   - Edit `src/test/resources/config/config.properties`
   - Update URL if needed (default: https://argon.nammnet.com/netscaler)
   - Change browser if needed (chrome, firefox, edge)

## Running Tests

### Run All Tests
```bash
mvn clean test
```

### Run Specific Feature
```bash
mvn test -Dcucumber.filter.tags="@SmokeTest"
```

### Run with Specific Browser
Update `config.properties` file to change browser, or modify TestRunner.java

### Run Specific Scenario
```bash
mvn test -Dcucumber.filter.tags="@Positive"
```

## Test Reports

### Cucumber Reports
- HTML Report: `target/cucumber-reports/index.html`
- JSON Report: `target/cucumber-reports/Cucumber.json`
- XML Report: `target/cucumber-reports/Cucumber.xml`

### ExtentReports
- Location: `test-output/ExtentReport_[timestamp].html`
- Includes screenshots for failed tests
- Detailed test execution information

## Page Object Model Structure

### BasePage
- Contains common methods for all pages
- Handles waits, clicks, sends keys, etc.
- Uses PageFactory for element initialization

### Page Classes
- `LoginPage.java`: Login functionality
- `HomePage.java`: Home page functionality
- Each page extends BasePage

## Step Definitions

- `LoginStepDefinitions.java`: Login-related steps
- `HomePageStepDefinitions.java`: Home page-related steps
- `Hooks.java`: Before and After hooks for setup/teardown

## Configuration

### config.properties
```properties
url=https://argon.nammnet.com/netscaler
browser=chrome
implicit.wait=10
explicit.wait=15
page.load.timeout=30
```

## Adding New Tests

1. **Create Feature File**: Add `.feature` file in `src/test/resources/features/`
2. **Create Page Object**: Add page class in `src/main/java/com/nammnet/pages/`
3. **Create Step Definitions**: Add step definitions in `src/test/java/com/nammnet/stepdefinitions/`
4. **Run Tests**: Execute via Maven or TestRunner

## Assertions

The framework uses JUnit assertions:
- `Assert.assertTrue()`: Verify condition is true
- `Assert.assertEquals()`: Verify expected equals actual
- `Assert.assertFalse()`: Verify condition is false
- `Assert.assertNotNull()`: Verify object is not null

## WebDriverManager

WebDriverManager automatically:
- Downloads the correct ChromeDriver version
- Manages driver binaries
- Updates drivers when needed
- No manual driver management required

## Troubleshooting

1. **ChromeDriver Issues**: WebDriverManager handles this automatically
2. **Tests Not Running**: Check Maven and Java versions
3. **Element Not Found**: Verify selectors in page objects
4. **Report Not Generated**: Check `test-output` folder permissions

## Best Practices

1. Use Page Object Model for maintainability
2. Keep step definitions thin, logic in page objects
3. Use meaningful scenario names
4. Add tags for test organization
5. Use assertions for validation
6. Take screenshots on failures

## Advanced Features

### Jira Test Case Import

Import test cases from Jira and automatically convert them to Cucumber feature files.

```java
import com.nammnet.integration.TestCaseImporter;

// Import single test case
TestCaseImporter.importSingleTestCaseFromJira(
    "https://yourcompany.atlassian.net",
    "username",
    "api-token",
    "TEST-123",
    "output-filename"
);

// Import bulk test cases
String jql = "project = TEST AND type = Test";
TestCaseImporter.importBulkTestCasesFromJira(
    "https://yourcompany.atlassian.net",
    "username",
    "api-token",
    jql,
    "base-filename",
    false  // false = separate files, true = single file
);
```

See [IMPORT_GUIDE.md](IMPORT_GUIDE.md) for detailed documentation.

### Azure DevOps Test Case Import

Import test cases from Azure DevOps and convert to feature files.

```java
// Import single test case
TestCaseImporter.importSingleTestCaseFromADO(
    "organization",
    "project",
    "pat-token",
    12345,  // Work Item ID
    "output-filename"
);

// Import by test plan
TestCaseImporter.importTestCasesFromADOTestPlan(
    "organization",
    "project",
    "pat-token",
    123,  // Test Plan ID
    "base-filename",
    true  // Single file
);
```

### Auto-Healing Locators

The framework includes intelligent locator healing that automatically finds alternative locators when the original fails.

**Features:**
- Pure Java implementation (no database or Docker required)
- Multiple locator strategies (ID, name, class, XPath, text, similarity)
- String similarity matching using Levenshtein distance
- Automatic fallback mechanisms

**Usage:**
```java
// Auto-healing is built into BasePage methods
public void enterUsername(String username) {
    sendKeys(usernameField, username, "Username", 
            createAttributesMap("username", "username", "input-field", "text"));
}
```

The healing system automatically tries multiple strategies when a locator fails, ensuring test stability.

## Project Structure (Updated)

```
selenium-cucumber-pom/
├── src/
│   ├── main/
│   │   └── java/
│   │       └── com/
│   │           └── nammnet/
│   │               ├── pages/
│   │               │   ├── BasePage.java (with auto-healing)
│   │               │   ├── LoginPage.java
│   │               │   └── HomePage.java
│   │               ├── utils/
│   │               │   ├── DriverManager.java
│   │               │   ├── ExtentReportManager.java
│   │               │   ├── ConfigReader.java
│   │               │   └── Assertions.java
│   │               ├── integration/
│   │               │   ├── jira/
│   │               │   │   ├── JiraClient.java
│   │               │   │   ├── JiraTestCase.java
│   │               │   │   └── JiraToFeatureConverter.java
│   │               │   ├── ado/
│   │               │   │   ├── AzureDevOpsClient.java
│   │               │   │   ├── AzureDevOpsTestCase.java
│   │               │   │   └── ADOToFeatureConverter.java
│   │               │   └── TestCaseImporter.java
│   │               └── healing/
│   │                   └── LocatorHealer.java
│   └── test/
│       ├── java/
│       │   └── com/
│       │       └── nammnet/
│       │           ├── runner/
│       │           │   └── TestRunner.java
│       │           ├── stepdefinitions/
│       │           │   ├── Hooks.java
│       │           │   ├── LoginStepDefinitions.java
│       │           │   └── HomePageStepDefinitions.java
│       │           └── examples/
│       │               └── ImportExamples.java
│       └── resources/
│           ├── features/
│           │   ├── Login.feature
│           │   ├── HomePage.feature
│           │   └── imported/  (generated feature files)
│           └── config/
│               └── config.properties
├── pom.xml
├── README.md
└── IMPORT_GUIDE.md
```

## Contact

For issues or questions, please refer to the project documentation.
See [IMPORT_GUIDE.md](IMPORT_GUIDE.md) for detailed import and auto-healing documentation.

