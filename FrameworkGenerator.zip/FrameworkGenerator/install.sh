#!/bin/bash

# Automation Framework Generator - Installation Script for Linux/macOS
# Make executable with: chmod +x install.sh

echo "============================================"
echo "  Automation Framework Generator"
echo "  Installation Script v1.0"
echo "============================================"
echo ""

# Check if .NET is installed
echo "Checking for .NET SDK..."
if ! command -v dotnet &> /dev/null; then
    echo "✗ .NET SDK not found!"
    echo "Please install .NET 8.0 SDK from: https://dotnet.microsoft.com/download"
    exit 1
fi

DOTNET_VERSION=$(dotnet --version)
echo "✓ .NET SDK $DOTNET_VERSION found"
echo ""

# Build the project
echo "Building the project..."
dotnet build

if [ $? -ne 0 ]; then
    echo "✗ Build failed!"
    exit 1
fi

echo "✓ Build successful"
echo ""

# Pack as tool
echo "Packing as tool..."
dotnet pack

if [ $? -ne 0 ]; then
    echo "✗ Pack failed!"
    exit 1
fi

echo "✓ Pack successful"
echo ""

# Uninstall old version if exists
echo "Checking for existing installation..."
if dotnet tool list -g | grep -q "AutomationFrameworkGenerator"; then
    echo "Uninstalling previous version..."
    dotnet tool uninstall -g AutomationFrameworkGenerator
    echo "✓ Previous version uninstalled"
fi

echo ""
echo "Installing as global tool..."
dotnet tool install --global --add-source ./nupkg AutomationFrameworkGenerator

if [ $? -ne 0 ]; then
    echo "✗ Installation failed!"
    echo "Try running with sudo: sudo ./install.sh"
    exit 1
fi

echo ""
echo "============================================"
echo "  ✓ Installation Successful!"
echo "============================================"
echo ""
echo "Usage:"
echo "  framework-gen generate --name MyProject"
echo ""
echo "Examples:"
echo "  framework-gen generate --name MyTests --framework nunit --browser chrome"
echo "  framework-gen generate --name MyTests --framework xunit --browser firefox"
echo "  framework-gen generate --name MyTests --path ~/Projects"
echo ""
echo "For help:"
echo "  framework-gen --help"
echo ""
echo "Happy Testing! 🧪"
