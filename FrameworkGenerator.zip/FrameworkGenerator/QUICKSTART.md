# 🚀 Quick Start Guide

Get up and running in 5 minutes!

## Prerequisites
- .NET 8.0 SDK installed ([Download here](https://dotnet.microsoft.com/download))

## Installation (Choose Your OS)

### 🪟 Windows

1. **Extract the zip file** to `C:\Tools\FrameworkGenerator`

2. **Open PowerShell as Administrator** and run:
   ```powershell
   cd C:\Tools\FrameworkGenerator
   .\install.ps1
   ```

### 🍎 macOS

1. **Extract the zip file** to `~/Tools/FrameworkGenerator`

2. **Open Terminal** and run:
   ```bash
   cd ~/Tools/FrameworkGenerator
   chmod +x install.sh
   ./install.sh
   ```

### 🐧 Linux

1. **Extract the zip file** to `~/Tools/FrameworkGenerator`

2. **Open Terminal** and run:
   ```bash
   cd ~/Tools/FrameworkGenerator
   chmod +x install.sh
   sudo ./install.sh
   ```

## Generate Your First Project

```bash
# Generate a project
framework-gen generate --name MyFirstProject

# Navigate to it
cd MyFirstProject

# Build it
dotnet build

# Run the sample tests
dotnet test
```

## What Just Happened?

You now have a complete test automation framework with:
- ✅ Selenium WebDriver setup
- ✅ Reqnroll (BDD) integration
- ✅ Page Object Model structure
- ✅ Sample login tests
- ✅ Configuration management
- ✅ Logging and screenshots
- ✅ Ready to customize!

## Customize Your Framework

### 1. Configure Browser and URL

Edit `MyFirstProject.Tests/appsettings.json`:

```json
{
  "Browser": "chrome",
  "BaseUrl": "https://your-app.com",
  "Timeout": 30
}
```

### 2. Add Your First Feature

Create `Features/YourFeature.feature`:

```gherkin
Feature: Your Feature Name
  
  Scenario: Your test scenario
    Given I do something
    When I do something else
    Then I should see results
```

### 3. Add Step Definitions

Create `StepDefinitions/YourSteps.cs`:

```csharp
using Reqnroll;

[Binding]
public class YourSteps
{
    [Given(@"I do something")]
    public void GivenIDoSomething()
    {
        // Your code here
    }
}
```

### 4. Add Page Objects

Create `PageObjects/YourPage.cs`:

```csharp
using OpenQA.Selenium;

public class YourPage : BasePage
{
    public YourPage(IWebDriver driver) : base(driver) { }
    
    private By ElementLocator => By.Id("element-id");
    
    public void DoAction()
    {
        Click(ElementLocator);
    }
}
```

## Run Tests

```bash
# Run all tests
dotnet test

# Run specific feature
dotnet test --filter "FullyQualifiedName~YourFeature"

# Run with detailed output
dotnet test --logger "console;verbosity=detailed"
```

## Common Commands

```bash
# Generate project with specific framework
framework-gen generate --name MyProject --framework xunit

# Generate with specific browser
framework-gen generate --name MyProject --browser firefox

# Generate in specific location
framework-gen generate --name MyProject --path C:/Projects

# Get help
framework-gen --help
```

## Project Structure

```
MyFirstProject/
├── MyFirstProject.Tests/
│   ├── Features/           # Your .feature files go here
│   ├── StepDefinitions/    # Your step implementations
│   ├── PageObjects/        # Your page object classes
│   ├── Hooks/              # Setup and teardown
│   ├── Helpers/            # Utility classes
│   └── appsettings.json    # Configuration
└── README.md               # Full documentation
```

## Next Steps

1. ✅ Read the generated `README.md` for detailed documentation
2. ✅ Modify `appsettings.json` with your application URL
3. ✅ Create your feature files in `Features/`
4. ✅ Implement step definitions
5. ✅ Create page objects for your pages
6. ✅ Run tests with `dotnet test`

## Troubleshooting

### Tool not found after installation
```bash
# Restart your terminal
# Or verify installation:
dotnet tool list -g
```

### Build errors
```bash
cd MyFirstProject
dotnet clean
dotnet restore
dotnet build
```

### Tests not running
```bash
# Make sure you're in the project directory
cd MyFirstProject

# Build first
dotnet build

# Then run
dotnet test
```

## Getting Help

- 📖 Check `INSTALLATION.md` for detailed installation instructions
- 📖 Check `README.md` in FrameworkGenerator folder
- 📖 Check `README.md` in your generated project
- 🌐 Visit [Reqnroll Documentation](https://docs.reqnroll.net/)
- 🌐 Visit [Selenium Documentation](https://www.selenium.dev/documentation/)

## Example: Complete Workflow

```bash
# 1. Generate
framework-gen generate --name ShoppingCartTests --browser chrome

# 2. Navigate
cd ShoppingCartTests

# 3. Configure
# Edit ShoppingCartTests.Tests/appsettings.json

# 4. Build
dotnet build

# 5. Run sample tests
dotnet test

# 6. Open in IDE
code .  # VS Code
# or
rider .  # JetBrains Rider
# or double-click ShoppingCartTests.sln for Visual Studio

# 7. Start writing your tests!
```

## Tips

💡 **Use Page Object Model** - Keep selectors and actions in page objects

💡 **Use Explicit Waits** - The BasePage class has helpful wait methods

💡 **Configure Logging** - Check `Logs/` folder for test execution logs

💡 **Screenshots on Failure** - Auto-captured in `Screenshots/` folder

💡 **Organize Features** - Group related scenarios in feature files

💡 **Reuse Steps** - Common steps can be shared across features

---

**Happy Testing! 🧪**

*You're now ready to create robust, maintainable test automation!*
