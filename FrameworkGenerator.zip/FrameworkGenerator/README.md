# Automation Framework Generator

A command-line tool to quickly generate Selenium C# test automation frameworks with Reqnroll (SpecFlow successor).

## 🚀 Quick Start

### Installation

#### Option 1: Install as Global Tool (Recommended)

```bash
# Navigate to the project directory
cd FrameworkGenerator

# Build the project
dotnet build

# Pack as a tool
dotnet pack

# Install globally
dotnet tool install --global --add-source ./nupkg AutomationFrameworkGenerator
```

#### Option 2: Run Directly

```bash
cd FrameworkGenerator
dotnet run -- generate --name MyProject --framework nunit --browser chrome
```

## 📖 Usage

### Generate a New Framework

```bash
framework-gen generate --name MyTestProject --framework nunit --browser chrome --path C:/Projects
```

### Parameters

| Parameter | Description | Default | Options |
|-----------|-------------|---------|---------|
| `--name` | Project name | MyAutomationFramework | Any valid project name |
| `--framework` | Test framework | nunit | nunit, xunit, mstest |
| `--browser` | Default browser | chrome | chrome, firefox, edge |
| `--path` | Output directory | Current directory | Any valid path |

### Examples

#### Generate with NUnit and Chrome (default)
```bash
framework-gen generate --name EcommerceTests
```

#### Generate with xUnit and Firefox
```bash
framework-gen generate --name MyTests --framework xunit --browser firefox
```

#### Generate in specific directory
```bash
framework-gen generate --name BankingTests --path D:/AutomationProjects
```

#### Generate with MSTest and Edge
```bash
framework-gen generate --name PortalTests --framework mstest --browser edge
```

## 📦 What Gets Generated

The tool creates a complete test automation framework with:

```
MyProject/
├── MyProject.Tests/
│   ├── Features/
│   │   └── Login.feature                 # Sample Gherkin feature
│   ├── StepDefinitions/
│   │   └── LoginSteps.cs                 # Sample step definitions
│   ├── PageObjects/
│   │   ├── BasePage.cs                   # Base page with reusable methods
│   │   └── LoginPage.cs                  # Sample page object
│   ├── Hooks/
│   │   └── Hooks.cs                      # WebDriver setup/teardown
│   ├── Helpers/
│   │   ├── ConfigHelper.cs               # Configuration reader
│   │   ├── LogHelper.cs                  # Logging utility
│   │   ├── ScreenshotHelper.cs           # Screenshot utility
│   │   └── WaitHelper.cs                 # Wait utility
│   ├── Screenshots/                      # Failure screenshots
│   ├── Logs/                             # Test logs
│   ├── Reports/                          # Test reports
│   ├── appsettings.json                  # Configuration
│   ├── reqnroll.json                     # Reqnroll config
│   └── MyProject.Tests.csproj
├── MyProject.sln
├── .gitignore
└── README.md                             # Project documentation
```

## 🔧 Included Packages

The generated framework includes:

- **Reqnroll** - BDD framework (SpecFlow successor)
- **Reqnroll.NUnit/xUnit/MSTest** - Test framework integration
- **Selenium.WebDriver** - Browser automation
- **Selenium.Support** - Additional Selenium utilities
- **WebDriverManager** - Automatic driver management
- **Serilog** - Logging framework
- **ExtentReports** - Test reporting
- **DotNetSeleniumExtras.WaitHelpers** - Wait helpers

## ✨ Features

### ✅ What You Get

- **Complete project structure** - Ready to use
- **Page Object Model** - Best practice implementation
- **Configuration management** - appsettings.json support
- **Logging** - Serilog integration
- **Screenshot on failure** - Automatic screenshot capture
- **Cross-browser support** - Chrome, Firefox, Edge
- **Sample tests** - Login feature example
- **Helper utilities** - Config, Log, Screenshot, Wait helpers
- **Documentation** - Comprehensive README

### 🎯 Best Practices Included

- Page Object Model (POM) pattern
- Explicit waits over implicit waits
- Centralized configuration
- Logging and reporting
- Screenshot on test failure
- Separation of concerns
- Reusable base page class

## 🔨 Development

### Build the Tool

```bash
dotnet build
```

### Run Tests (if you add them)

```bash
dotnet test
```

### Pack as NuGet Package

```bash
dotnet pack
```

### Modify Templates

Edit `FrameworkGeneratorService.cs` to customize:
- Project structure
- Generated files
- Default configurations
- Package versions

## 🐛 Troubleshooting

### Tool not found after installation

```bash
# Verify installation
dotnet tool list -g

# Reinstall if needed
dotnet tool uninstall -g AutomationFrameworkGenerator
dotnet tool install --global --add-source ./nupkg AutomationFrameworkGenerator
```

### Permission errors

```bash
# Run as administrator (Windows) or with sudo (Linux/Mac)
sudo dotnet tool install --global --add-source ./nupkg AutomationFrameworkGenerator
```

### Build errors

```bash
# Clean and rebuild
dotnet clean
dotnet build
```

## 🚀 After Generation

Once you generate a framework:

```bash
# Navigate to generated project
cd MyTestProject

# Build the project
dotnet build

# Run tests
dotnet test

# Modify configuration
# Edit MyTestProject.Tests/appsettings.json

# Add new features
# Create .feature files in Features/
```

## 📝 Configuration

The generated `appsettings.json` allows you to configure:

```json
{
  "Browser": "chrome",              // Browser to use
  "BaseUrl": "https://example.com", // Application URL
  "Timeout": 30,                    // Default timeout
  "ImplicitWait": 10,               // Implicit wait
  "PageLoadTimeout": 30,            // Page load timeout
  "HeadlessMode": false,            // Headless browser
  "ScreenshotOnFailure": true       // Screenshot on fail
}
```

## 🤝 Contributing

To contribute to this generator tool:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test the generated frameworks
5. Submit a pull request

## 📄 License

MIT License

## 🙋 Support

For issues or questions:
- Check the generated README.md
- Review the code in FrameworkGeneratorService.cs
- Create an issue on GitHub

## 🎉 Version History

### v1.0.0
- Initial release
- Support for NUnit, xUnit, MSTest
- Chrome, Firefox, Edge browser support
- Complete framework scaffolding
- Sample feature and page objects
- Configuration management
- Logging and reporting setup

---

**Happy Test Automation! 🧪**
