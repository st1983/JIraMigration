# Automation Framework Generator - Installation Script for Windows
# Run this script as Administrator

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Automation Framework Generator" -ForegroundColor Cyan
Write-Host "  Installation Script v1.0" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# Check if .NET is installed
Write-Host "Checking for .NET SDK..." -ForegroundColor Yellow
try {
    $dotnetVersion = dotnet --version
    Write-Host "✓ .NET SDK $dotnetVersion found" -ForegroundColor Green
} catch {
    Write-Host "✗ .NET SDK not found!" -ForegroundColor Red
    Write-Host "Please install .NET 8.0 SDK from: https://dotnet.microsoft.com/download" -ForegroundColor Yellow
    exit 1
}

Write-Host ""
Write-Host "Building the project..." -ForegroundColor Yellow
dotnet build

if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ Build failed!" -ForegroundColor Red
    exit 1
}

Write-Host "✓ Build successful" -ForegroundColor Green
Write-Host ""

Write-Host "Packing as tool..." -ForegroundColor Yellow
dotnet pack

if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ Pack failed!" -ForegroundColor Red
    exit 1
}

Write-Host "✓ Pack successful" -ForegroundColor Green
Write-Host ""

# Uninstall old version if exists
Write-Host "Checking for existing installation..." -ForegroundColor Yellow
$existingTool = dotnet tool list -g | Select-String "AutomationFrameworkGenerator"

if ($existingTool) {
    Write-Host "Uninstalling previous version..." -ForegroundColor Yellow
    dotnet tool uninstall -g AutomationFrameworkGenerator
    Write-Host "✓ Previous version uninstalled" -ForegroundColor Green
}

Write-Host ""
Write-Host "Installing as global tool..." -ForegroundColor Yellow
dotnet tool install --global --add-source ./nupkg AutomationFrameworkGenerator

if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ Installation failed!" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  ✓ Installation Successful!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "Usage:" -ForegroundColor Cyan
Write-Host "  framework-gen generate --name MyProject" -ForegroundColor White
Write-Host ""
Write-Host "Examples:" -ForegroundColor Cyan
Write-Host "  framework-gen generate --name MyTests --framework nunit --browser chrome" -ForegroundColor White
Write-Host "  framework-gen generate --name MyTests --framework xunit --browser firefox" -ForegroundColor White
Write-Host "  framework-gen generate --name MyTests --path C:\Projects" -ForegroundColor White
Write-Host ""
Write-Host "For help:" -ForegroundColor Cyan
Write-Host "  framework-gen --help" -ForegroundColor White
Write-Host ""
Write-Host "Happy Testing! 🧪" -ForegroundColor Green
