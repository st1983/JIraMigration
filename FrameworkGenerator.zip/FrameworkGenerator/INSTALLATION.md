# Installation & Usage Guide

## Quick Installation (3 Steps)

### Step 1: Extract the Files
```bash
# Extract the zip file to a directory
# For example: C:\Tools\FrameworkGenerator
```

### Step 2: Build and Install
```bash
# Open terminal/command prompt in the extracted directory
cd FrameworkGenerator

# Build the project
dotnet build

# Pack as a tool
dotnet pack

# Install globally
dotnet tool install --global --add-source ./nupkg AutomationFrameworkGenerator
```

### Step 3: Use the Tool
```bash
# Generate your first framework
framework-gen generate --name MyFirstProject

# Navigate to the generated project
cd MyFirstProject

# Build and run tests
dotnet build
dotnet test
```

## Detailed Installation Instructions

### Prerequisites
- .NET 8.0 SDK or later installed
- Download from: https://dotnet.microsoft.com/download

### Verify .NET Installation
```bash
dotnet --version
```

You should see version 8.0.0 or higher.

### Installation Steps

#### Windows

1. **Extract the zip file**
   ```cmd
   # Extract to C:\Tools\FrameworkGenerator
   ```

2. **Open PowerShell or Command Prompt as Administrator**

3. **Navigate to the directory**
   ```cmd
   cd C:\Tools\FrameworkGenerator
   ```

4. **Build the project**
   ```cmd
   dotnet build
   ```

5. **Pack the tool**
   ```cmd
   dotnet pack
   ```

6. **Install globally**
   ```cmd
   dotnet tool install --global --add-source ./nupkg AutomationFrameworkGenerator
   ```

7. **Verify installation**
   ```cmd
   framework-gen --help
   ```

#### macOS/Linux

1. **Extract the zip file**
   ```bash
   unzip FrameworkGenerator.zip -d ~/Tools/
   ```

2. **Open Terminal**

3. **Navigate to the directory**
   ```bash
   cd ~/Tools/FrameworkGenerator
   ```

4. **Build the project**
   ```bash
   dotnet build
   ```

5. **Pack the tool**
   ```bash
   dotnet pack
   ```

6. **Install globally**
   ```bash
   dotnet tool install --global --add-source ./nupkg AutomationFrameworkGenerator
   ```

7. **Verify installation**
   ```bash
   framework-gen --help
   ```

## Using the Generator

### Basic Usage

```bash
framework-gen generate --name ProjectName
```

### Advanced Usage

```bash
# Specify all parameters
framework-gen generate \
  --name MyTestProject \
  --framework nunit \
  --browser chrome \
  --path C:\Projects
```

### Parameter Examples

**Different Test Frameworks:**
```bash
# NUnit (default)
framework-gen generate --name MyProject --framework nunit

# xUnit
framework-gen generate --name MyProject --framework xunit

# MSTest
framework-gen generate --name MyProject --framework mstest
```

**Different Browsers:**
```bash
# Chrome (default)
framework-gen generate --name MyProject --browser chrome

# Firefox
framework-gen generate --name MyProject --browser firefox

# Edge
framework-gen generate --name MyProject --browser edge
```

**Custom Output Path:**
```bash
# Windows
framework-gen generate --name MyProject --path C:\Projects\Automation

# macOS/Linux
framework-gen generate --name MyProject --path ~/Projects/Automation
```

## After Generation

### Step 1: Navigate to Project
```bash
cd MyTestProject
```

### Step 2: Build
```bash
dotnet build
```

### Step 3: Run Tests
```bash
dotnet test
```

### Step 4: Configure
Edit `MyTestProject.Tests/appsettings.json`:

```json
{
  "Browser": "chrome",
  "BaseUrl": "https://your-app-url.com",
  "Timeout": 30
}
```

### Step 5: Write Your Tests

1. **Create Feature File** in `Features/YourFeature.feature`
2. **Create Step Definitions** in `StepDefinitions/YourSteps.cs`
3. **Create Page Objects** in `PageObjects/YourPage.cs`

## Troubleshooting

### Issue: "dotnet command not found"
**Solution:** Install .NET SDK from https://dotnet.microsoft.com/download

### Issue: "framework-gen command not found"
**Solution:** 
```bash
# Check if tool is installed
dotnet tool list -g

# If not listed, reinstall
dotnet tool install --global --add-source ./nupkg AutomationFrameworkGenerator

# You may need to restart your terminal
```

### Issue: Permission denied (Linux/Mac)
**Solution:**
```bash
# Run with sudo
sudo dotnet tool install --global --add-source ./nupkg AutomationFrameworkGenerator
```

### Issue: Build errors in generated project
**Solution:**
```bash
# Clean and rebuild
cd MyTestProject
dotnet clean
dotnet restore
dotnet build
```

### Issue: WebDriver not found
**Solution:** 
The generated framework uses WebDriverManager which automatically downloads drivers. Ensure your browser is up to date.

## Uninstalling

```bash
# Uninstall the global tool
dotnet tool uninstall -g AutomationFrameworkGenerator
```

## Updating

```bash
# Uninstall old version
dotnet tool uninstall -g AutomationFrameworkGenerator

# Reinstall new version
cd FrameworkGenerator
dotnet build
dotnet pack
dotnet tool install --global --add-source ./nupkg AutomationFrameworkGenerator
```

## IDE Setup

### Visual Studio 2022
1. Open the generated `.sln` file
2. Install Reqnroll extension from Extensions > Manage Extensions
3. Build and run tests from Test Explorer

### Visual Studio Code
1. Install C# extension
2. Install .NET Test Explorer extension
3. Open the generated folder
4. Run tests from Testing panel

### Rider
1. Open the generated `.sln` file
2. Install SpecFlow/Reqnroll plugin
3. Run tests from Unit Tests panel

## Example Workflow

```bash
# 1. Generate framework
framework-gen generate --name EcommerceTests --browser chrome

# 2. Navigate to project
cd EcommerceTests

# 3. Open in your IDE
code .  # VS Code
# or
rider .  # Rider
# or double-click EcommerceTests.sln for Visual Studio

# 4. Build
dotnet build

# 5. Run sample tests
dotnet test

# 6. Edit configuration
# Modify EcommerceTests.Tests/appsettings.json

# 7. Start writing your tests!
```

## Getting Help

### Command Help
```bash
framework-gen --help
framework-gen generate --help
```

### Resources
- Generated README.md in each project
- Reqnroll docs: https://docs.reqnroll.net/
- Selenium docs: https://www.selenium.dev/documentation/

## Success Indicators

After installation, you should see:
✅ Tool installed successfully
✅ `framework-gen --help` shows usage info
✅ Can generate new projects
✅ Generated projects build without errors
✅ Sample tests run successfully

---

**Need more help? Check README.md in the FrameworkGenerator folder or the generated project's README.md**
