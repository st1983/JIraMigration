using System.Diagnostics;

namespace FrameworkGenerator;

public class FrameworkGeneratorService
{
    public async Task GenerateFramework(string projectName, string framework, string browser, string outputPath)
    {
        Console.WriteLine("╔════════════════════════════════════════════════════════════╗");
        Console.WriteLine("║   Automation Framework Generator v1.0                     ║");
        Console.WriteLine("╚════════════════════════════════════════════════════════════╝");
        Console.WriteLine();
        Console.WriteLine($"📦 Project Name: {projectName}");
        Console.WriteLine($"🧪 Test Framework: {framework}");
        Console.WriteLine($"🌐 Browser: {browser}");
        Console.WriteLine($"📁 Output Path: {outputPath}");
        Console.WriteLine();
        
        var projectPath = Path.Combine(outputPath, projectName);
        
        if (Directory.Exists(projectPath))
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"❌ Error: Directory '{projectPath}' already exists!");
            Console.ResetColor();
            return;
        }
        
        Directory.CreateDirectory(projectPath);

        try
        {
            // Create solution
            Console.WriteLine("⏳ Creating solution...");
            await RunCommand("dotnet", $"new sln -n {projectName}", projectPath);

            // Create test project
            Console.WriteLine("⏳ Creating test project...");
            var testProjectName = $"{projectName}.Tests";
            var testProjectPath = Path.Combine(projectPath, testProjectName);
            await RunCommand("dotnet", $"new {framework} -n {testProjectName}", projectPath);
            await RunCommand("dotnet", $"sln add {testProjectName}/{testProjectName}.csproj", projectPath);

            // Install packages
            Console.WriteLine("⏳ Installing NuGet packages (this may take a moment)...");
            await InstallPackages(testProjectPath, framework);

            // Generate folder structure
            Console.WriteLine("⏳ Creating folder structure...");
            CreateFolderStructure(testProjectPath);

            // Generate files
            Console.WriteLine("⏳ Generating configuration files...");
            GenerateConfigFiles(testProjectPath, projectName);
            
            Console.WriteLine("⏳ Generating hooks...");
            GenerateHooksFile(testProjectPath, browser, framework);
            
            Console.WriteLine("⏳ Generating base page class...");
            GenerateBasePageFile(testProjectPath);
            
            Console.WriteLine("⏳ Generating sample feature...");
            GenerateSampleFeature(testProjectPath);
            
            Console.WriteLine("⏳ Generating step definitions...");
            GenerateSampleSteps(testProjectPath, framework);
            
            Console.WriteLine("⏳ Generating page objects...");
            GenerateSamplePageObject(testProjectPath);
            
            Console.WriteLine("⏳ Generating helper classes...");
            GenerateHelperClasses(testProjectPath);
            
            Console.WriteLine("⏳ Generating app settings...");
            GenerateAppSettings(testProjectPath);
            
            Console.WriteLine("⏳ Generating README...");
            GenerateReadme(projectPath, projectName);
            
            Console.WriteLine("⏳ Generating .gitignore...");
            GenerateGitignore(projectPath);

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("╔════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║  ✅ Framework generated successfully!                     ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════╝");
            Console.ResetColor();
            Console.WriteLine();
            Console.WriteLine("📂 Project Structure:");
            Console.WriteLine($"   {projectName}/");
            Console.WriteLine($"   ├── {testProjectName}/");
            Console.WriteLine("   │   ├── Features/");
            Console.WriteLine("   │   ├── StepDefinitions/");
            Console.WriteLine("   │   ├── PageObjects/");
            Console.WriteLine("   │   ├── Hooks/");
            Console.WriteLine("   │   ├── Helpers/");
            Console.WriteLine("   │   └── Config/");
            Console.WriteLine("   └── README.md");
            Console.WriteLine();
            Console.WriteLine("🚀 Next steps:");
            Console.WriteLine($"   1. cd {projectName}");
            Console.WriteLine("   2. dotnet build");
            Console.WriteLine("   3. dotnet test");
            Console.WriteLine();
            Console.WriteLine("📝 Edit appsettings.json to configure browser and base URL");
            Console.WriteLine("📖 Check README.md for detailed documentation");
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"❌ Error generating framework: {ex.Message}");
            Console.ResetColor();
            throw;
        }
    }

    private void CreateFolderStructure(string testProjectPath)
    {
        var folders = new[]
        {
            "Features",
            "StepDefinitions",
            "PageObjects",
            "Hooks",
            "Helpers",
            "Config",
            "Reports",
            "Screenshots",
            "Logs"
        };

        foreach (var folder in folders)
        {
            Directory.CreateDirectory(Path.Combine(testProjectPath, folder));
        }
    }

    private async Task InstallPackages(string projectPath, string framework)
    {
        var packages = new[]
        {
            "Reqnroll",
            $"Reqnroll.{FirstCharToUpper(framework)}",
            "Selenium.WebDriver",
            "Selenium.Support",
            "WebDriverManager",
            "Serilog",
            "Serilog.Sinks.File",
            "Microsoft.Extensions.Configuration",
            "Microsoft.Extensions.Configuration.Json",
            "ExtentReports",
            "DotNetSeleniumExtras.WaitHelpers"
        };

        foreach (var package in packages)
        {
            await RunCommand("dotnet", $"add package {package}", projectPath);
        }
    }

    private void GenerateHooksFile(string projectPath, string browser, string framework)
    {
        var content = $@"using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Edge;
using Reqnroll;
using WebDriverManager;
using WebDriverManager.DriverConfigs.Impl;
using {Path.GetFileName(projectPath)}.Helpers;

namespace {Path.GetFileName(projectPath)}.Hooks;

[Binding]
public class Hooks
{{
    private IWebDriver _driver;
    private readonly ScenarioContext _scenarioContext;

    public Hooks(ScenarioContext scenarioContext)
    {{
        _scenarioContext = scenarioContext;
    }}

    [BeforeScenario]
    public void BeforeScenario()
    {{
        var browser = ConfigHelper.GetBrowser();
        
        switch (browser.ToLower())
        {{
            case ""chrome"":
                new DriverManager().SetUpDriver(new ChromeConfig());
                _driver = new ChromeDriver();
                break;
            case ""firefox"":
                new DriverManager().SetUpDriver(new FirefoxConfig());
                _driver = new FirefoxDriver();
                break;
            case ""edge"":
                new DriverManager().SetUpDriver(new EdgeConfig());
                _driver = new EdgeDriver();
                break;
            default:
                new DriverManager().SetUpDriver(new ChromeConfig());
                _driver = new ChromeDriver();
                break;
        }}

        _driver.Manage().Window.Maximize();
        _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(ConfigHelper.GetImplicitWait());
        _driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(ConfigHelper.GetPageLoadTimeout());
        
        _scenarioContext[""WebDriver""] = _driver;
        LogHelper.Info(""WebDriver initialized successfully"");
    }}

    [AfterScenario]
    public void AfterScenario()
    {{
        if (_scenarioContext.TestError != null)
        {{
            LogHelper.Error($""Test failed: {{_scenarioContext.TestError.Message}}"");
            ScreenshotHelper.TakeScreenshot(_driver, _scenarioContext.ScenarioInfo.Title);
        }}
        
        _driver?.Quit();
        _driver?.Dispose();
        LogHelper.Info(""WebDriver closed"");
    }}
}}";

        File.WriteAllText(Path.Combine(projectPath, "Hooks", "Hooks.cs"), content);
    }

    private void GenerateBasePageFile(string projectPath)
    {
        var content = $@"using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace {Path.GetFileName(projectPath)}.PageObjects;

public class BasePage
{{
    protected readonly IWebDriver Driver;
    protected readonly WebDriverWait Wait;

    public BasePage(IWebDriver driver)
    {{
        Driver = driver;
        Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
    }}

    protected void Click(By locator)
    {{
        Wait.Until(ExpectedConditions.ElementToBeClickable(locator)).Click();
    }}

    protected void SendKeys(By locator, string text)
    {{
        var element = Wait.Until(ExpectedConditions.ElementIsVisible(locator));
        element.Clear();
        element.SendKeys(text);
    }}

    protected string GetText(By locator)
    {{
        return Wait.Until(ExpectedConditions.ElementIsVisible(locator)).Text;
    }}

    protected bool IsElementDisplayed(By locator)
    {{
        try
        {{
            return Wait.Until(ExpectedConditions.ElementIsVisible(locator)).Displayed;
        }}
        catch
        {{
            return false;
        }}
    }}

    protected void WaitForUrl(string url)
    {{
        Wait.Until(ExpectedConditions.UrlContains(url));
    }}

    protected void WaitForElement(By locator, int timeoutSeconds = 10)
    {{
        var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(timeoutSeconds));
        wait.Until(ExpectedConditions.ElementIsVisible(locator));
    }}

    protected void ScrollToElement(By locator)
    {{
        var element = Wait.Until(ExpectedConditions.ElementExists(locator));
        ((IJavaScriptExecutor)Driver).ExecuteScript(""arguments[0].scrollIntoView(true);"", element);
    }}

    protected void SelectDropdownByText(By locator, string text)
    {{
        var element = Wait.Until(ExpectedConditions.ElementIsVisible(locator));
        var select = new SelectElement(element);
        select.SelectByText(text);
    }}

    protected void SelectDropdownByValue(By locator, string value)
    {{
        var element = Wait.Until(ExpectedConditions.ElementIsVisible(locator));
        var select = new SelectElement(element);
        select.SelectByValue(value);
    }}
}}";

        File.WriteAllText(Path.Combine(projectPath, "PageObjects", "BasePage.cs"), content);
    }

    private void GenerateSampleFeature(string projectPath)
    {
        var content = @"Feature: Sample Login Feature
  As a user
  I want to login to the application
  So that I can access my account

  Background:
    Given I navigate to the login page

  Scenario: Successful login with valid credentials
    When I enter username ""testuser"" and password ""testpass""
    And I click the login button
    Then I should see the dashboard page

  Scenario: Failed login with invalid credentials
    When I enter username ""invalid"" and password ""invalid""
    And I click the login button
    Then I should see an error message

  Scenario Outline: Login with multiple users
    When I enter username ""<username>"" and password ""<password>""
    And I click the login button
    Then I should see the <result>

    Examples:
      | username  | password  | result          |
      | admin     | admin123  | dashboard page  |
      | testuser  | test123   | dashboard page  |
      | invalid   | wrong     | error message   |";

        File.WriteAllText(Path.Combine(projectPath, "Features", "Login.feature"), content);
    }

    private void GenerateSampleSteps(string projectPath, string framework)
    {
        var assertNamespace = framework.ToLower() switch
        {
            "nunit" => "NUnit.Framework",
            "xunit" => "Xunit",
            "mstest" => "Microsoft.VisualStudio.TestTools.UnitTesting",
            _ => "NUnit.Framework"
        };

        var content = $@"using OpenQA.Selenium;
using Reqnroll;
using {assertNamespace};
using {Path.GetFileName(projectPath)}.PageObjects;
using {Path.GetFileName(projectPath)}.Helpers;

namespace {Path.GetFileName(projectPath)}.StepDefinitions;

[Binding]
public class LoginSteps
{{
    private readonly IWebDriver _driver;
    private readonly ScenarioContext _scenarioContext;
    private LoginPage _loginPage;

    public LoginSteps(ScenarioContext scenarioContext)
    {{
        _scenarioContext = scenarioContext;
        _driver = (IWebDriver)scenarioContext[""WebDriver""];
        _loginPage = new LoginPage(_driver);
    }}

    [Given(@""I navigate to the login page"")]
    public void GivenINavigateToTheLoginPage()
    {{
        var baseUrl = ConfigHelper.GetBaseUrl();
        _driver.Navigate().GoToUrl($""{{baseUrl}}/login"");
        LogHelper.Info(""Navigated to login page"");
    }}

    [When(@""I enter username ""(.*)"" and password ""(.*)"""")]
    public void WhenIEnterUsernameAndPassword(string username, string password)
    {{
        _loginPage.EnterCredentials(username, password);
        LogHelper.Info($""Entered credentials for user: {{username}}"");
    }}

    [When(@""I click the login button"")]
    public void WhenIClickTheLoginButton()
    {{
        _loginPage.ClickLogin();
        LogHelper.Info(""Clicked login button"");
    }}

    [Then(@""I should see the dashboard page"")]
    public void ThenIShouldSeeTheDashboardPage()
    {{
        {GetAssertStatement(framework, "_driver.Url", "dashboard")}
        LogHelper.Info(""Dashboard page verified"");
    }}

    [Then(@""I should see an error message"")]
    public void ThenIShouldSeeAnErrorMessage()
    {{
        {GetBoolAssertStatement(framework, "_loginPage.IsErrorDisplayed()")}
        LogHelper.Info(""Error message verified"");
    }}
}}";

        File.WriteAllText(Path.Combine(projectPath, "StepDefinitions", "LoginSteps.cs"), content);
    }

    private void GenerateSamplePageObject(string projectPath)
    {
        var content = $@"using OpenQA.Selenium;

namespace {Path.GetFileName(projectPath)}.PageObjects;

public class LoginPage : BasePage
{{
    public LoginPage(IWebDriver driver) : base(driver) {{ }}

    // Locators
    private By UsernameField => By.Id(""username"");
    private By PasswordField => By.Id(""password"");
    private By LoginButton => By.Id(""loginBtn"");
    private By ErrorMessage => By.CssSelector("".error-message"");
    private By RememberMeCheckbox => By.Id(""rememberMe"");
    private By ForgotPasswordLink => By.LinkText(""Forgot Password?"");

    // Actions
    public void EnterCredentials(string username, string password)
    {{
        SendKeys(UsernameField, username);
        SendKeys(PasswordField, password);
    }}

    public void EnterUsername(string username)
    {{
        SendKeys(UsernameField, username);
    }}

    public void EnterPassword(string password)
    {{
        SendKeys(PasswordField, password);
    }}

    public void ClickLogin()
    {{
        Click(LoginButton);
    }}

    public void ClickRememberMe()
    {{
        Click(RememberMeCheckbox);
    }}

    public void ClickForgotPassword()
    {{
        Click(ForgotPasswordLink);
    }}

    // Verifications
    public bool IsErrorDisplayed()
    {{
        return IsElementDisplayed(ErrorMessage);
    }}

    public string GetErrorMessage()
    {{
        return GetText(ErrorMessage);
    }}

    public bool IsLoginButtonEnabled()
    {{
        return Driver.FindElement(LoginButton).Enabled;
    }}
}}";

        File.WriteAllText(Path.Combine(projectPath, "PageObjects", "LoginPage.cs"), content);
    }

    private void GenerateHelperClasses(string projectPath)
    {
        // ConfigHelper
        var configHelper = $@"using Microsoft.Extensions.Configuration;

namespace {Path.GetFileName(projectPath)}.Helpers;

public static class ConfigHelper
{{
    private static IConfiguration _configuration;

    static ConfigHelper()
    {{
        _configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile(""appsettings.json"", optional: false, reloadOnChange: true)
            .Build();
    }}

    public static string GetBrowser() => _configuration[""Browser""] ?? ""chrome"";
    public static string GetBaseUrl() => _configuration[""BaseUrl""] ?? ""https://example.com"";
    public static int GetTimeout() => int.Parse(_configuration[""Timeout""] ?? ""30"");
    public static int GetImplicitWait() => int.Parse(_configuration[""ImplicitWait""] ?? ""10"");
    public static int GetPageLoadTimeout() => int.Parse(_configuration[""PageLoadTimeout""] ?? ""30"");
    public static bool GetHeadlessMode() => bool.Parse(_configuration[""HeadlessMode""] ?? ""false"");
}}";

        File.WriteAllText(Path.Combine(projectPath, "Helpers", "ConfigHelper.cs"), configHelper);

        // LogHelper
        var logHelper = $@"using Serilog;

namespace {Path.GetFileName(projectPath)}.Helpers;

public static class LogHelper
{{
    static LogHelper()
    {{
        Log.Logger = new LoggerConfiguration()
            .WriteTo.File(""Logs/test-.log"", rollingInterval: RollingInterval.Day)
            .WriteTo.Console()
            .CreateLogger();
    }}

    public static void Info(string message) => Log.Information(message);
    public static void Error(string message) => Log.Error(message);
    public static void Warning(string message) => Log.Warning(message);
    public static void Debug(string message) => Log.Debug(message);
}}";

        File.WriteAllText(Path.Combine(projectPath, "Helpers", "LogHelper.cs"), logHelper);

        // ScreenshotHelper
        var screenshotHelper = $@"using OpenQA.Selenium;

namespace {Path.GetFileName(projectPath)}.Helpers;

public static class ScreenshotHelper
{{
    public static void TakeScreenshot(IWebDriver driver, string scenarioName)
    {{
        try
        {{
            var screenshot = ((ITakesScreenshot)driver).GetScreenshot();
            var sanitizedName = string.Join(""_"", scenarioName.Split(Path.GetInvalidFileNameChars()));
            var filename = $""Screenshots/{{sanitizedName}}_{{DateTime.Now:yyyyMMdd_HHmmss}}.png"";
            screenshot.SaveAsFile(filename);
            LogHelper.Info($""Screenshot saved: {{filename}}"");
        }}
        catch (Exception ex)
        {{
            LogHelper.Error($""Failed to take screenshot: {{ex.Message}}"");
        }}
    }}

    public static void TakeScreenshot(IWebDriver driver, string scenarioName, string stepName)
    {{
        try
        {{
            var screenshot = ((ITakesScreenshot)driver).GetScreenshot();
            var sanitizedScenario = string.Join(""_"", scenarioName.Split(Path.GetInvalidFileNameChars()));
            var sanitizedStep = string.Join(""_"", stepName.Split(Path.GetInvalidFileNameChars()));
            var filename = $""Screenshots/{{sanitizedScenario}}_{{sanitizedStep}}_{{DateTime.Now:yyyyMMdd_HHmmss}}.png"";
            screenshot.SaveAsFile(filename);
            LogHelper.Info($""Screenshot saved: {{filename}}"");
        }}
        catch (Exception ex)
        {{
            LogHelper.Error($""Failed to take screenshot: {{ex.Message}}"");
        }}
    }}
}}";

        File.WriteAllText(Path.Combine(projectPath, "Helpers", "ScreenshotHelper.cs"), screenshotHelper);

        // WaitHelper
        var waitHelper = $@"using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace {Path.GetFileName(projectPath)}.Helpers;

public static class WaitHelper
{{
    public static void WaitForElement(IWebDriver driver, By locator, int timeoutSeconds = 10)
    {{
        var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutSeconds));
        wait.Until(ExpectedConditions.ElementIsVisible(locator));
    }}

    public static void WaitForElementToBeClickable(IWebDriver driver, By locator, int timeoutSeconds = 10)
    {{
        var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutSeconds));
        wait.Until(ExpectedConditions.ElementToBeClickable(locator));
    }}

    public static void WaitForElementToDisappear(IWebDriver driver, By locator, int timeoutSeconds = 10)
    {{
        var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutSeconds));
        wait.Until(ExpectedConditions.InvisibilityOfElementLocated(locator));
    }}

    public static void WaitForUrl(IWebDriver driver, string url, int timeoutSeconds = 10)
    {{
        var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutSeconds));
        wait.Until(ExpectedConditions.UrlContains(url));
    }}
}}";

        File.WriteAllText(Path.Combine(projectPath, "Helpers", "WaitHelper.cs"), waitHelper);
    }

    private void GenerateAppSettings(string projectPath)
    {
        var content = @"{
  ""Browser"": ""chrome"",
  ""BaseUrl"": ""https://example.com"",
  ""Timeout"": 30,
  ""ImplicitWait"": 10,
  ""PageLoadTimeout"": 30,
  ""HeadlessMode"": false,
  ""ScreenshotOnFailure"": true
}";

        File.WriteAllText(Path.Combine(projectPath, "appsettings.json"), content);
    }

    private void GenerateConfigFiles(string projectPath, string projectName)
    {
        var reqnrollJson = @"{
  ""$schema"": ""https://schemas.reqnroll.net/reqnroll-config.json"",
  ""language"": {
    ""feature"": ""en""
  },
  ""bindingCulture"": {
    ""name"": ""en-US""
  },
  ""trace"": {
    ""traceSuccessfulSteps"": false,
    ""traceTimings"": true,
    ""minTracedDuration"": ""0:0:0.1""
  }
}";

        File.WriteAllText(Path.Combine(projectPath, "reqnroll.json"), reqnrollJson);
    }

    private void GenerateReadme(string projectPath, string projectName)
    {
        var content = $@"# {projectName}

Automated test framework using Selenium WebDriver, Reqnroll (SpecFlow successor), and C#.

## 📋 Prerequisites

- .NET 8.0 SDK or later
- Chrome/Firefox/Edge browser installed
- Visual Studio 2022 or VS Code (optional)

## 🚀 Getting Started

### 1. Build the project

```bash
dotnet build
```

### 2. Run all tests

```bash
dotnet test
```

### 3. Run specific feature

```bash
dotnet test --filter ""FullyQualifiedName~Login""
```

### 4. Run with specific browser

Edit `appsettings.json` and change the `Browser` value to `chrome`, `firefox`, or `edge`.

## 📁 Project Structure

```
{projectName}/
├── {projectName}.Tests/
│   ├── Features/              # Gherkin feature files (.feature)
│   ├── StepDefinitions/       # Step definition implementations
│   ├── PageObjects/           # Page Object Model classes
│   ├── Hooks/                 # Test hooks (BeforeScenario, AfterScenario)
│   ├── Helpers/               # Utility classes
│   │   ├── ConfigHelper.cs    # Configuration reader
│   │   ├── LogHelper.cs       # Logging utility
│   │   ├── ScreenshotHelper.cs # Screenshot utility
│   │   └── WaitHelper.cs      # Wait utility
│   ├── Screenshots/           # Test failure screenshots
│   ├── Logs/                  # Test execution logs
│   ├── Reports/               # Test reports
│   ├── appsettings.json       # Configuration file
│   └── reqnroll.json          # Reqnroll configuration
└── README.md
```

## ⚙️ Configuration

Edit `appsettings.json` to configure:

```json
{{
  ""Browser"": ""chrome"",           // chrome, firefox, edge
  ""BaseUrl"": ""https://example.com"",
  ""Timeout"": 30,                  // Default timeout in seconds
  ""ImplicitWait"": 10,             // Implicit wait in seconds
  ""PageLoadTimeout"": 30,          // Page load timeout in seconds
  ""HeadlessMode"": false,          // Run browser in headless mode
  ""ScreenshotOnFailure"": true     // Take screenshot on test failure
}}
```

## 📝 Writing Tests

### 1. Create a Feature File

Create a new `.feature` file in the `Features` folder:

```gherkin
Feature: User Registration
  As a new user
  I want to register an account
  So that I can access the application

  Scenario: Successful registration
    Given I navigate to the registration page
    When I fill in the registration form with valid data
    And I submit the form
    Then I should see a success message
```

### 2. Create Step Definitions

Create a new step definition class in `StepDefinitions`:

```csharp
[Binding]
public class RegistrationSteps
{{
    private readonly IWebDriver _driver;
    
    public RegistrationSteps(ScenarioContext scenarioContext)
    {{
        _driver = (IWebDriver)scenarioContext[""WebDriver""];
    }}
    
    [Given(@""I navigate to the registration page"")]
    public void GivenINavigateToTheRegistrationPage()
    {{
        // Implementation
    }}
}}
```

### 3. Create Page Objects

Create page object classes in `PageObjects`:

```csharp
public class RegistrationPage : BasePage
{{
    public RegistrationPage(IWebDriver driver) : base(driver) {{ }}
    
    private By EmailField => By.Id(""email"");
    private By SubmitButton => By.Id(""submit"");
    
    public void EnterEmail(string email)
    {{
        SendKeys(EmailField, email);
    }}
}}
```

## 🧪 Running Tests

### Run all tests
```bash
dotnet test
```

### Run specific feature
```bash
dotnet test --filter ""FullyQualifiedName~FeatureName""
```

### Run with specific tag
```bash
dotnet test --filter ""Category=smoke""
```

### Generate test report
```bash
dotnet test --logger ""html;logfilename=testResults.html""
```

## 📊 Test Reports

Test results and logs are generated in:
- **Screenshots**: `Screenshots/` folder (on test failure)
- **Logs**: `Logs/` folder
- **Reports**: `Reports/` folder

## 🔧 Best Practices

1. **Page Object Model**: Keep page-specific logic in PageObjects
2. **DRY Principle**: Reuse common methods in BasePage
3. **Wait Strategies**: Use explicit waits instead of Thread.Sleep
4. **Logging**: Use LogHelper for consistent logging
5. **Screenshots**: Automatically captured on test failure
6. **Configuration**: Keep environment-specific settings in appsettings.json

## 🐛 Troubleshooting

### WebDriver not found
- Ensure your browser is up to date
- WebDriverManager automatically downloads drivers

### Tests failing randomly
- Increase timeout values in appsettings.json
- Add explicit waits for dynamic elements

### Screenshots not saving
- Check write permissions for Screenshots folder
- Verify driver is not null when taking screenshots

## 📚 Additional Resources

- [Reqnroll Documentation](https://docs.reqnroll.net/)
- [Selenium Documentation](https://www.selenium.dev/documentation/)
- [C# Selenium Guide](https://www.selenium.dev/documentation/webdriver/getting_started/)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 👥 Support

For issues and questions:
- Create an issue in the repository
- Check existing documentation
- Review test logs in the Logs folder

---

**Generated by Automation Framework Generator v1.0**
";

        File.WriteAllText(Path.Combine(projectPath, "README.md"), content);
    }

    private void GenerateGitignore(string projectPath)
    {
        var content = @"## Ignore Visual Studio temporary files, build results, and files generated by popular Visual Studio add-ons.

# User-specific files
*.suo
*.user
*.userosscache
*.sln.docstates

# Build results
[Dd]ebug/
[Dd]ebugPublic/
[Rr]elease/
[Rr]eleases/
x64/
x86/
build/
bld/
[Bb]in/
[Oo]bj/

# Test Results
[Tt]est[Rr]esult*/
[Bb]uild[Ll]og.*

# NuGet Packages
*.nupkg
**/packages/*
!**/packages/build/

# Screenshots and Logs
Screenshots/
Logs/
Reports/

# VS Code
.vscode/

# Rider
.idea/

# User-specific files
*.userprefs

# Build results
[Dd]ebug/
[Rr]elease/

# Others
*.pidb
*.log
*.scc

# Backup & report files
*.bak
*.cache
*.ilk
*.log
*.lib
*.sbr

# Visual Studio profiler
*.psess
*.vsp
*.vspx

# ReSharper
_ReSharper*/
*.[Rr]e[Ss]harper

# TeamCity
_TeamCity*

# DotCover
*.dotCover

# Test output
TestResults/
";

        File.WriteAllText(Path.Combine(projectPath, ".gitignore"), content);
    }

    private async Task RunCommand(string command, string arguments, string workingDirectory)
    {
        var processInfo = new ProcessStartInfo
        {
            FileName = command,
            Arguments = arguments,
            WorkingDirectory = workingDirectory,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        using var process = Process.Start(processInfo);
        if (process != null)
        {
            await process.WaitForExitAsync();
        }
    }

    private string FirstCharToUpper(string input)
    {
        return string.IsNullOrEmpty(input) ? input : char.ToUpper(input[0]) + input.Substring(1);
    }

    private string GetAssertStatement(string framework, string actual, string expected)
    {
        return framework.ToLower() switch
        {
            "nunit" => $"Assert.That({actual}, Does.Contain(\"{expected}\"));",
            "xunit" => $"Assert.Contains(\"{expected}\", {actual});",
            "mstest" => $"Assert.IsTrue({actual}.Contains(\"{expected}\"));",
            _ => $"Assert.That({actual}, Does.Contain(\"{expected}\"));"
        };
    }

    private string GetBoolAssertStatement(string framework, string condition)
    {
        return framework.ToLower() switch
        {
            "nunit" => $"Assert.That({condition}, Is.True);",
            "xunit" => $"Assert.True({condition});",
            "mstest" => $"Assert.IsTrue({condition});",
            _ => $"Assert.That({condition}, Is.True);"
        };
    }
}
