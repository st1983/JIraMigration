using System.CommandLine;
using FrameworkGenerator;

var rootCommand = new RootCommand("Automation Framework Generator - Generate Selenium C# test frameworks with Reqnroll");

var generateCommand = new Command("generate", "Generate a new test automation framework");

var nameOption = new Option<string>(
    "--name",
    description: "Project name",
    getDefaultValue: () => "MyAutomationFramework");

var frameworkOption = new Option<string>(
    "--framework",
    description: "Test framework (nunit, xunit, mstest)",
    getDefaultValue: () => "nunit");

var browserOption = new Option<string>(
    "--browser",
    description: "Default browser (chrome, firefox, edge)",
    getDefaultValue: () => "chrome");

var pathOption = new Option<string>(
    "--path",
    description: "Output path",
    getDefaultValue: () => Directory.GetCurrentDirectory());

generateCommand.AddOption(nameOption);
generateCommand.AddOption(frameworkOption);
generateCommand.AddOption(browserOption);
generateCommand.AddOption(pathOption);

generateCommand.SetHandler(async (name, framework, browser, path) =>
{
    var generator = new FrameworkGeneratorService();
    await generator.GenerateFramework(name, framework, browser, path);
}, nameOption, frameworkOption, browserOption, pathOption);

rootCommand.AddCommand(generateCommand);

return await rootCommand.InvokeAsync(args);
